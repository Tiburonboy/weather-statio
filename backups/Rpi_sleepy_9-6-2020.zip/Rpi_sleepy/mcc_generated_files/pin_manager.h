/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.4
        Device            :  PIC16F18323
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.20 and above
        MPLAB 	          :  MPLAB X 5.40	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set Vbat aliases
#define Vbat_TRIS                 TRISAbits.TRISA2
#define Vbat_LAT                  LATAbits.LATA2
#define Vbat_PORT                 PORTAbits.RA2
#define Vbat_WPU                  WPUAbits.WPUA2
#define Vbat_OD                   ODCONAbits.ODCA2
#define Vbat_ANS                  ANSELAbits.ANSA2
#define Vbat_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define Vbat_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define Vbat_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define Vbat_GetValue()           PORTAbits.RA2
#define Vbat_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define Vbat_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define Vbat_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define Vbat_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define Vbat_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define Vbat_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define Vbat_SetAnalogMode()      do { ANSELAbits.ANSA2 = 1; } while(0)
#define Vbat_SetDigitalMode()     do { ANSELAbits.ANSA2 = 0; } while(0)

// get/set SCL aliases
#define SCL_TRIS                 TRISAbits.TRISA4
#define SCL_LAT                  LATAbits.LATA4
#define SCL_PORT                 PORTAbits.RA4
#define SCL_WPU                  WPUAbits.WPUA4
#define SCL_OD                   ODCONAbits.ODCA4
#define SCL_ANS                  ANSELAbits.ANSA4
#define SCL_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define SCL_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define SCL_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define SCL_GetValue()           PORTAbits.RA4
#define SCL_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define SCL_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define SCL_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define SCL_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define SCL_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define SCL_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define SCL_SetAnalogMode()      do { ANSELAbits.ANSA4 = 1; } while(0)
#define SCL_SetDigitalMode()     do { ANSELAbits.ANSA4 = 0; } while(0)

// get/set SDA aliases
#define SDA_TRIS                 TRISAbits.TRISA5
#define SDA_LAT                  LATAbits.LATA5
#define SDA_PORT                 PORTAbits.RA5
#define SDA_WPU                  WPUAbits.WPUA5
#define SDA_OD                   ODCONAbits.ODCA5
#define SDA_ANS                  ANSELAbits.ANSA5
#define SDA_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define SDA_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define SDA_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define SDA_GetValue()           PORTAbits.RA5
#define SDA_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define SDA_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define SDA_SetPullup()          do { WPUAbits.WPUA5 = 1; } while(0)
#define SDA_ResetPullup()        do { WPUAbits.WPUA5 = 0; } while(0)
#define SDA_SetPushPull()        do { ODCONAbits.ODCA5 = 0; } while(0)
#define SDA_SetOpenDrain()       do { ODCONAbits.ODCA5 = 1; } while(0)
#define SDA_SetAnalogMode()      do { ANSELAbits.ANSA5 = 1; } while(0)
#define SDA_SetDigitalMode()     do { ANSELAbits.ANSA5 = 0; } while(0)

// get/set Shut_dwn aliases
#define Shut_dwn_TRIS                 TRISCbits.TRISC0
#define Shut_dwn_LAT                  LATCbits.LATC0
#define Shut_dwn_PORT                 PORTCbits.RC0
#define Shut_dwn_WPU                  WPUCbits.WPUC0
#define Shut_dwn_OD                   ODCONCbits.ODCC0
#define Shut_dwn_ANS                  ANSELCbits.ANSC0
#define Shut_dwn_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define Shut_dwn_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define Shut_dwn_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define Shut_dwn_GetValue()           PORTCbits.RC0
#define Shut_dwn_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define Shut_dwn_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define Shut_dwn_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define Shut_dwn_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define Shut_dwn_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define Shut_dwn_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define Shut_dwn_SetAnalogMode()      do { ANSELCbits.ANSC0 = 1; } while(0)
#define Shut_dwn_SetDigitalMode()     do { ANSELCbits.ANSC0 = 0; } while(0)

// get/set TEPT4400 aliases
#define TEPT4400_TRIS                 TRISCbits.TRISC1
#define TEPT4400_LAT                  LATCbits.LATC1
#define TEPT4400_PORT                 PORTCbits.RC1
#define TEPT4400_WPU                  WPUCbits.WPUC1
#define TEPT4400_OD                   ODCONCbits.ODCC1
#define TEPT4400_ANS                  ANSELCbits.ANSC1
#define TEPT4400_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define TEPT4400_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define TEPT4400_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define TEPT4400_GetValue()           PORTCbits.RC1
#define TEPT4400_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define TEPT4400_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define TEPT4400_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define TEPT4400_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define TEPT4400_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define TEPT4400_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define TEPT4400_SetAnalogMode()      do { ANSELCbits.ANSC1 = 1; } while(0)
#define TEPT4400_SetDigitalMode()     do { ANSELCbits.ANSC1 = 0; } while(0)

// get/set SQW aliases
#define SQW_TRIS                 TRISCbits.TRISC2
#define SQW_LAT                  LATCbits.LATC2
#define SQW_PORT                 PORTCbits.RC2
#define SQW_WPU                  WPUCbits.WPUC2
#define SQW_OD                   ODCONCbits.ODCC2
#define SQW_ANS                  ANSELCbits.ANSC2
#define SQW_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define SQW_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define SQW_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define SQW_GetValue()           PORTCbits.RC2
#define SQW_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define SQW_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define SQW_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define SQW_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define SQW_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define SQW_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define SQW_SetAnalogMode()      do { ANSELCbits.ANSC2 = 1; } while(0)
#define SQW_SetDigitalMode()     do { ANSELCbits.ANSC2 = 0; } while(0)

// get/set LED aliases
#define LED_TRIS                 TRISCbits.TRISC3
#define LED_LAT                  LATCbits.LATC3
#define LED_PORT                 PORTCbits.RC3
#define LED_WPU                  WPUCbits.WPUC3
#define LED_OD                   ODCONCbits.ODCC3
#define LED_ANS                  ANSELCbits.ANSC3
#define LED_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define LED_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define LED_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define LED_GetValue()           PORTCbits.RC3
#define LED_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define LED_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define LED_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define LED_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define LED_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define LED_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define LED_SetAnalogMode()      do { ANSELCbits.ANSC3 = 1; } while(0)
#define LED_SetDigitalMode()     do { ANSELCbits.ANSC3 = 0; } while(0)

// get/set Boost_EN aliases
#define Boost_EN_TRIS                 TRISCbits.TRISC4
#define Boost_EN_LAT                  LATCbits.LATC4
#define Boost_EN_PORT                 PORTCbits.RC4
#define Boost_EN_WPU                  WPUCbits.WPUC4
#define Boost_EN_OD                   ODCONCbits.ODCC4
#define Boost_EN_ANS                  ANSELCbits.ANSC4
#define Boost_EN_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define Boost_EN_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define Boost_EN_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define Boost_EN_GetValue()           PORTCbits.RC4
#define Boost_EN_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define Boost_EN_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define Boost_EN_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define Boost_EN_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define Boost_EN_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define Boost_EN_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define Boost_EN_SetAnalogMode()      do { ANSELCbits.ANSC4 = 1; } while(0)
#define Boost_EN_SetDigitalMode()     do { ANSELCbits.ANSC4 = 0; } while(0)

// get/set LCD_BL aliases
#define LCD_BL_TRIS                 TRISCbits.TRISC5
#define LCD_BL_LAT                  LATCbits.LATC5
#define LCD_BL_PORT                 PORTCbits.RC5
#define LCD_BL_WPU                  WPUCbits.WPUC5
#define LCD_BL_OD                   ODCONCbits.ODCC5
#define LCD_BL_ANS                  ANSELCbits.ANSC5
#define LCD_BL_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define LCD_BL_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define LCD_BL_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define LCD_BL_GetValue()           PORTCbits.RC5
#define LCD_BL_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define LCD_BL_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define LCD_BL_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define LCD_BL_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define LCD_BL_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define LCD_BL_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define LCD_BL_SetAnalogMode()      do { ANSELCbits.ANSC5 = 1; } while(0)
#define LCD_BL_SetDigitalMode()     do { ANSELCbits.ANSC5 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/