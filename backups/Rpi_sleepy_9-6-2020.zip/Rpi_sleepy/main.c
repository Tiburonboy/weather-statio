/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.4
        Device            :  PIC16F18323
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/
#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include "i2c.h"
#include "rtc.h"

void wake_up_pi(void);
void pi_test(void);

/*
                         Main application


write a diesciption
reads RTC, keeps track of seconds and minutes
wakes the Rpi0w every 15 minutes, gets sensor data

For dubugging and prototype MCU runs continioulys.  Later add code
to put the MCU in standby and wakeup via some signal like SQW.

See Rpi Sleepy notes for description and plans for project

8/11/2020: removed software i2c from pi_sleepy, going to use
PIC hardware i2c.  Also removed RTC code.  pi_sleepy will only use sqw
to count down seconds.

8/12/2020: Adding software i2c back to sleepy_pi.  PIC harware slave i2c looks
too complicated to get running quickly.  Save this task for later.
Revert back to software i2c inorder to read RTC.  Test if Pi can still set the
RTC and have PIC read it when Pi is powered off.  Sleepy_pi will control the
power to the Rpi0w and when it wakes, it will run WiFi server code, then
poweroff.  PIC will monitor TX line for shut down, then power off Rpi0w.
Need to change system clock so that i2c delays are correct.
Fosc = 4MHz, div=1

On the weather station, change connect to 15 minutes, and LCD update to 1 min.

Rpi0w runs boot up script
1) delays until linux fully loads
2) waits for connection or time out
3) signals active connection to pi_sleepy by asserting the shut_dwn line
3) de-asserting the shut_dwn line signals that the connection is finished
4) Rpi0w shuts down, does this lower the shut_dwn line?
5) pi_sleepy reads the RTC, shuts off the power and counts the minutes until
wakeup time.

sleepy_pi
shut_dwn is now an input.  Low means completet and ready for power off.
Then the sleepy_pi reads the RTC to get accurate min and sec, then waits for
wakeup time.
steps
1) powerup Rpi0w
2) wait for shut_dwn to high, then low
3) delay until Rpi0w is fully down
3) read RTC and update min and sec values.
4) wait wakeup time.

 */

uint16_t TEPT4400_value; //TEPT4400 external ambient light sensor
uint16_t Vbat_value; // battery voltage
uint16_t Vchrg_value; // charging voltage

uint16_t ml_tmr; // main loop timer, 1ms increment by TMR0
uint16_t to_tmr; // time out timer, 1ms increment by TMR0
uint8_t LED_flg;

uint8_t r_flg, s_flg;  // used to keep track of the phase of the SQW 1Hz signal
uint16_t sec_cnt;
uint16_t min_cnt;
uint8_t wake_up_flg;  // used to keep from running againg within the same minute

//uint8_t sleepy_wdata[10];  // holds i2c write data
//uint8_t sleepy_en_flg;  // true if sleepy operations are enabled, otherwise don't sleep

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    LED_flg = 0;
    LED_SetHigh(); // turn off LED
    LCD_BL_SetHigh(); // turn off LCD back light
    Shut_dwn_SetDigitalInput();

    //sleepy_en_flg = 0;
    Boost_EN_SetHigh();  // enable +5v power to Rpi0w

    // initalize i2c lines on sleepy_pi end
    SDA_SetDigitalInput();  //SDA is Hi Z
    SCL_SetDigitalInput();  //SCL is Hi Z

    //pi_test();  // use this code for debugging, never returns

    sec_cnt = 0;
    min_cnt = 13;
    wake_up_flg = 1;
    
    while (1)
    {
        // check for a new 1Hz rising edge
        if(SQW_GetValue() && !s_flg)
            r_flg = 1;
        if(!SQW_GetValue() && !r_flg)
            s_flg = 0;

        // once per second run these items
        if(r_flg){
            // toggel set and reset flags
            s_flg = 1;
            r_flg = 0;

            ml_tmr = 0;  // used to turnoff the LED 50 ms later
            LED_flg = 1;
            LED_SetLow();

            sec_cnt++;
            if(sec_cnt > 59){
                sec_cnt = 0;
                min_cnt++;
                if(min_cnt > 59)
                    min_cnt = 0;
            }

            // check for wakeup time
            //wakeup time: 14, 29, 44, 59 minutes past the hour
            if((min_cnt == 13 || min_cnt == 28 || min_cnt == 43 || min_cnt == 58) && wake_up_flg)
                wake_up_pi();

            if((min_cnt == 25 || min_cnt == 40 || min_cnt == 55 || min_cnt == 10) && !wake_up_flg)
                wake_up_flg = 1;  // arm for next time

             // control LCD backlight
             TEPT4400_value = ADC_GetConversion(TEPT4400);
             if(TEPT4400_value > 256)
                LCD_BL_SetHigh(); // turn off LCD back light
             else
                LCD_BL_SetLow();  // turn on LCD back light
        }

        // control if on, turn off after 50 ms
        if((ml_tmr > 50) && LED_flg){
            LED_SetHigh();
            LED_flg = 0;
        }

    }
}

/************************************
*          wake_up                  *
************************************/
/*
Name: wake_up
Synopsis: Powers up Rpi0w
Description:

Rpi0w will normally assert Shut_dwn signal.
If Rpi0w keeps Shut_dwn signal false, this means in debug mode
and keep power on.

Revision History:
*/
void wake_up_pi(void)
{
uint16_t up_time;
uint8_t val;

    LED_SetHigh();  // turn off LED
    Boost_EN_SetHigh();  // power up +5V supply
    to_tmr = 0;
    up_time = 0;
    wake_up_flg = 0;

    val = Shut_dwn_GetValue();

    // Loop untill time out or Shut_dwn goes high
    while((up_time < 420) && !Shut_dwn_GetValue()){ // 420 sec = 7 min
        if(to_tmr > 1000){
            to_tmr = 0;
            up_time++;
        }
    }

    LED_SetLow();  // signal end of 1st while loop
    if(up_time >= 420)
        // must have timed out, with no signal from Rpi0w
        return;  // return without doing anything or pwr down?

    // now wait for Shut_dwn to go low
    while((up_time < 420) && Shut_dwn_GetValue()){
        if(to_tmr > 1000){
          to_tmr = 0;
          up_time++;
        }
    }

    LED_SetHigh();  // signal end of 2nd while loop
    if(up_time >= 420)
        // must have timed out, with no signal from Rpi0w
        return;  // return without doing anything or pwr down?

    // at this point, received falling Shut_dwn signal
    // give Rpi0w time to finish shut down
    to_tmr = 0;  // reset timer count
    while(to_tmr < 30000); // wait 30 sec

    //I2C initialization
    // set the SDA line low and use TRIS to control the state
    SDA_SetLow();
    SDA_SetDigitalInput();  //SDA is Hi Z

    // set the SCL line as an output
    SCL_SetDigitalOutput();
    SCL_SetHigh();

    // Create a start condition followed by a stop condition
    i2c_start();
    i2c_stop();

    // read RTC
    get_time_date();
    sec_cnt = second;
    min_cnt = minute;

    // release i2c on sleepy_pi's end of line
    SDA_SetDigitalInput();  //SDA is Hi Z
    SCL_SetDigitalInput();  //SCL is Hi Z

    Boost_EN_SetLow();  // power down +5V supply

}

/************************************
*          pi_test                  *
************************************/
/*
Name: pi_test
Synopsis: Powers up Rpi0w
Description: for testing

Revision History:
*/
void pi_test(void)
{
    while (1){
        // check for a new 1Hz rising edge
        if(SQW_GetValue() && !s_flg)
            r_flg = 1;
        if(!SQW_GetValue() && !r_flg)
            s_flg = 0;

        // once per second run these items
        if(r_flg){
            // toggel set and reset flags
            s_flg = 1;
            r_flg = 0;

            ml_tmr = 0;  // used to turnoff the LED 50 ms later
            LED_flg = 1;
            LED_SetLow();

            // control LCD backlight
            TEPT4400_value = ADC_GetConversion(TEPT4400);
            if(TEPT4400_value > 200)
                LCD_BL_SetHigh(); // turn off LCD back light
            else
                LCD_BL_SetLow();  // turn on LCD back light
        }

        // control if on, turn off after 50 ms
        if((ml_tmr > 50) && LED_flg){
            LED_SetHigh();
            LED_flg = 0;
        }
    }
}

 // End of File
