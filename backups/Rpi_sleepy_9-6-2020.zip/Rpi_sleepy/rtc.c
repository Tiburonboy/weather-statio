// Real Time Clock
//#include rtc.h

#include "mcc_generated_files/mcc.h"
#include <string.h>
#include <stdio.h>
#include "i2c.h"
#include "rtc.h"


#define DS1307_ADDRESS 0x68

extern uint8_t update_rtc_flg;

extern struct network_timedate network_timedate;

// I/O pins used in the design
//uint8_t r_flg, s_flg;  // used to keep track of the phase of the SQW 1Hz signal

uint8_t second;
uint8_t minute;
uint8_t hour; 		// 24 hour time
uint8_t weekDay; 	// 1-7 = Sunday - Saturday
uint8_t monthDay;
uint8_t month;
uint8_t year;
uint8_t rtc_config;
uint8_t pData[10]; //actually only 56 bytes in the DS1307 address space

/************************************
*       get time and date           *
************************************/
/*
Name: get time and date
Synopsis:
Requires: na
Description:
Author: Tony Cirineo
Date:
Revision History:
*/
void get_time_date(void)
{
uint8_t dev_addrs;
uint8_t i;

  read_ds1307(0, pData, 8);

  second = bcdToDec(pData[0]);
  minute = bcdToDec(pData[1]);
  hour = bcdToDec(pData[2] & 0b111111); //24 hour time
  weekDay = bcdToDec(pData[3]); //1-7 -> Sunday - Saturday
  monthDay = bcdToDec(pData[4]);
  month = bcdToDec(pData[5]);
  year = bcdToDec(pData[6]);
  rtc_config = pData[7];
}


/************************************
*       set time and date           *
************************************/
/*
Name: get time and date
Synopsis:
Requires: na
Description:
Author: Tony Cirineo
Date:
Revision History:

*/
void set_time_date(void)
{
uint8_t dev_addrs;
uint8_t i;

    // manually set values for clock
    second =      0; //0-59, this also sets the CH bit to zero = osc runs
    minute =      9; //0-59
    hour =        17; //0-23
    weekDay =     2; //1-7, Sunday = 1
    monthDay =    18; //1-31
    month =       5; //1-12
    year  =       20; //0-99
    rtc_config = 0x10; //turn on SQW 1Hz

    // put formated data into array for sending
    pData[0] = decToBcd(second);
    pData[1] = decToBcd(minute);
    pData[2] = decToBcd(hour);
    pData[3] = decToBcd(weekDay);
    pData[4] = decToBcd(monthDay);
    pData[5] = decToBcd(month);
    pData[6] = decToBcd(year);
    pData[7] = rtc_config;

    write_ds1307(0, pData, 8);
}


/************************************
*      Dec & BCD Conversions        *
************************************/
/*
Name:
Synopsis:
Requires:
Description:
Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/
uint8_t decToBcd(uint8_t val){
// Convert normal decimal numbers to binary coded decimal
  return ( (val/10*16) + (val%10) );
}

uint8_t bcdToDec(uint8_t val)  {
// Convert binary coded decimal to normal decimal numbers
  return ( (val/16*10) + (val%16) );
}

/************************************
*       write ds1307                *
************************************/
/*
Name: write ds1307
Synopsis: writes data to the DS1307 real time clock
Requires:
wrd_addrs:  word address or register pointer
*ptr: pointer to list of data
len: length of data list to send
pointer to data and number of bytes to write
Description:
Author: Tony Cirineo
Date:
Revision History:
*/
void write_ds1307(uint8_t wrd_addrs, uint8_t *ptr, uint8_t len)
{
uint8_t dev_addrs;
uint8_t i;

	// build device address
	dev_addrs = DS1307_ADDRESS << 1;    // leave R/W bit as a zero

	// write device address, word address, then len bytes of data
	i2c_start();
	i2c_write(dev_addrs);	// device address
	i2c_write(wrd_addrs);	// word address
	for(i = 0;i < len;i++)
		i2c_write(*ptr++);
	i2c_stop();	// create a stop condition
}

/************************************
*       read ds1307                 *
************************************/
/*
Name: data read ds1307
Synopsis:
Data Read (Write Pointer, Then Read)—Slave Receive and Transmit

Requires:
wrd_addrs:  word address or register pointer
*ptr: pointer to list of data
len: length of data list to send
pointer to data and number of bytes to write
Description:
Author: Tony Cirineo
Date:
Revision History:
*/
void read_ds1307(uint8_t wdr_addrs, uint8_t *ptr, uint8_t len)
{
uint8_t dev_addrs;
uint8_t i,j,input_data;

	// write device address, then word address followed by repeated start
	dev_addrs = DS1307_ADDRESS << 1;    //leave w/r set to 0
	i2c_start();
	i2c_write(dev_addrs);	// device address
	i2c_write(wdr_addrs);	// word address
	i2c_start();	// send start condition

    // read the data from the device
	dev_addrs |= 0x01;      //set the w/r bit to 1 for read
	i2c_write(dev_addrs);	// device address

    // read len-1 bytes of data followed by ACK
    SDA_SetDigitalInput();        	// set SDA pin as input
    delay_10us();
    for(i = 0;i < len-1;i++){
        input_data = 0x00;
        for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
            input_data <<= 1;   // Shift the byte by one bit
            SCL_SetHigh();         // Clock the data into the I2C Bus
            delay_10us();
            input_data |= SDA_GetValue();  // Input the data from the I2C Bus
            delay_10us();
            SCL_SetLow();
            delay_10us();
        }
        // send ACK
        SDA_SetLow();    	// send ACK valid
        SDA_SetDigitalOutput();   // Put port pin to output
        delay_10us();
        SCL_SetHigh();		// Clock the ACK from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
        SDA_SetDigitalInput(); //return SDA to Hi Z
        *ptr++ = input_data;        //save received data
    }

    // now read last byte of data followed by NACK
    input_data = 0x00;
    for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
        input_data <<= 1;   // Shift the byte by one bit
        SCL_SetHigh();         // Clock the data into the I2C Bus
        delay_10us();
        input_data |= SDA_GetValue();  // Input the data from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
    }
    // send NACK
    SDA_SetHigh();    	// send NACK valid
    SDA_SetDigitalOutput();   // Put port pin to output
    delay_10us();
    SCL_SetHigh();		// Clock the ACK from the I2C Bus
    delay_10us();
    SCL_SetLow();
    delay_10us();
    SDA_SetDigitalInput(); //return SDA to Hi Z

    *ptr = input_data;        //save last received data

	i2c_stop();	// create a stop condition
}


// end of file
