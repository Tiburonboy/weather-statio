/************************************
*       esp8266.h                   *
************************************/
/*
Name:  esp8266.h
Synopsis: function declarations for esp8266
Revision History:
*/

int8_t esp8266_init(void);
int8_t esp8266_ConfigServer(void);
int8_t esp8266_GetResponse(uint8_t *rsp, uint16_t timeout);
int8_t esp8266_connect(void);
uint8_t esp8266_read(uint8_t *string);
void esp8266_write(uint8_t *string);
void esp8266_write_TxBuf(void);
int8_t esp8266_GetDataFromServer(uint16_t timeout);
void connect2network(void);
void esp8266_rssi(void);

void clear_esp8266_RxBuf(void);
void clear_esp8266_TxBuf(void);

struct network_timedate{
  int hour;
  int minute;
  int second;
  int month;
  int day;
  int year;
};


//end
