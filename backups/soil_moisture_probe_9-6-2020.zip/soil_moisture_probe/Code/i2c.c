

#include "mcc_generated_files/mcc.h"
#include "i2c.h"

extern uint16_t to_tmr;

//bit i2c_ack;
uint8_t i2c_ack;

/************************************
*           delay_???us             *
************************************/
/*
Name: delay_???us
Synopsis: various fixed delays, based on a 4 MHz clock
Requires: na
Description: delays are fixed to 4MHz system clock, div=1
 *  * Internal OSC: HFINTOSC
HF Internal Clock:  set to 4MHz (1, 2, 4, 8, 12, 16 and 32MHz)
Clock Divider:  1 (1, 2, 4, 8, 16, 32, 64, 128, 256 and 512)
 * This was changed from 4 to 1 because of the 15 us read time
 * requirement for the DS18B20, 1-Wire Digital Thermometer.
 *
 *
 * Delay used to allow data lines to stabilize.
count vs delay
_nop(); 10us
1       20  us
14		100 us
Author: Tony Cirineo
Date:
Revision History:
5 May 2020: having trouble getting the I2C on the LCD working.
trying a lower frequency.  Problem was wrong I2C address.
*/
// measured 16 to 20 us
void delay_10us(void)
{
    //NOP();
//unsigned int i;
//    for(i = 0;i < 14;i++);	// loop for a small delay, 100 us
}
// fixed, now about 100us
void delay_100us(void)
{
uint16_t i;
    for(i = 0;i < 6;i++);	// loop for a small delay, 100 us
}

#if 0
void delay_30us(void)
{
uint16_t i;
    for(i = 0;i < 5;i++);
}
#endif
// measured, about 480us
void delay_480us(void)
{
uint16_t i;
    for(i = 0;i < 37;i++);
}

// measured, about 1ms
void delay_1ms(void)
{
uint16_t i;
    for(i = 0;i < 71;i++);
}

// measured, 25ms
void delay_25ms(void)
{
uint16_t i;
    for(i = 0;i < 1864;i++);
}

#if 0
// 750ms/100us * 14 = 105000
void delay_750ms(void)
{
uint16_t i;
    for(i = 0;i < 52500;i++);
    for(i = 0;i < 52500;i++);
}
#endif
// use tmr0 to delay for 1 sec
void delay_1sec(void)
{
    to_tmr = 0;
    while(to_tmr < 999);
}


/************************************
*            i2c_start              *
************************************/
/*
Name: i2c_start
Synopsis: Sends I2C start condition.
Requires: na
Description: This function toggles the scl and sda
lines initiate the start condition
Author: Copied from the Keil Software web page with some changes
Date:  7/22/03
Revision History:
5/5/2015: updated
*/
void i2c_start(void)
{
    //SDA_SetHigh();     // Set data line high
    SDA_SetDigitalInput(); // let the pull up control the line
    delay_10us();
    SCL_SetHigh();     // Set clock line high
	  delay_10us();
    //SDA_SetLow();      // Set data line low (START SIGNAL)
    SDA_SetDigitalOutput();
	  delay_10us();
    SCL_SetLow();      // Set clock line low
    delay_10us();
}

/************************************
*            i2c_stop               *
************************************/
/*
Name: i2c_stop
Synopsis: Sends I2C Stop condition
Requires: na
Description: This function toggles the scl and sda
lines initiate the stop condition
Author: Copied from the Keil Software web page with some changes
Date:  7/22/03
Revision History:
5/5/2015: updated
*/
void i2c_stop(void)
{
uint8_t input_var;

    SCL_SetLow();          // Set clock line low
    delay_10us();
    SDA_SetLow();          // Set data line low
    SDA_SetDigitalOutput(); // set SDA to output
    delay_10us();
    SCL_SetHigh();         // Set clock line high
    delay_10us();
    SDA_SetDigitalInput(); //release the line
    delay_10us();
}

/************************************
*            i2c_write              *
************************************/
/*
Name: i2c_write
Synopsis: Writes data over the I2C bus
Requires: na
Description: This function toggles the scl and sda
lines to write a byte of data. Clocks acknowledge (ACK)
but ignores it.  i2c_ack is used by some devices to signal completion
of operation.
Author: Copied from the Keil Software web page with some changes
Date:  7/22/03
Revision History:
*/
void i2c_write(uint8_t output_data)
{
uint8_t i;
    SDA_SetHigh();      //SDA line is normally pulled high
    SDA_SetDigitalOutput();  //set as output
    delay_10us();
    for(i = 0; i < 8; i++){	// Send 8 bits to the I2C Bus
        // Output the data bit to the I2C Bus
        SDA_LAT = ((output_data & 0x80) ? 1 : 0);
        delay_10us();
        output_data  <<= 1; // Shift the byte by one bit
        SCL_SetHigh();         // Clock the data into the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
    }
    // get the ACK & save
    SDA_SetDigitalInput();  	// release pin (open drain output)
    delay_10us();
    SCL_SetHigh();     // Clock the ACK from the I2C Bus
    delay_10us();
    i2c_ack = SDA_GetValue();  // Input the ack from the I2C Bus
    SCL_SetLow();
    delay_10us();
    SDA_SetLow();   // leave SDA LAT as low and Hi Z
}

/************************************
*            i2c_read               *
************************************/
/*
Name: i2c_read
Synopsis: Reads data from the I2C bus
Requires: na
Description: This function toggles the scl and sda
lines to read data from the bus. Clocks acknowledge (ACK)
but ignores it.
Author: Copied from the Keil Software web page with some changes
Date:  7/22/03
Revision History:
5/5/2015: updated
*/
uint8_t i2c_read(void)
{
uint8_t i, input_data;

    SDA_SetDigitalInput();        	// set pin as input
    delay_10us();

    input_data = 0x00;
    for(i = 0; i < 8; i++){	// read 8 bits from the I2C Bus
        input_data <<= 1;   // Shift the byte by one bit
        SCL_SetHigh();         // Clock the data into the I2C Bus
		delay_10us();
        input_data |= SDA_GetValue();  // Input the data from the I2C Bus
		delay_10us();
        SCL_SetLow();
		delay_10us();
    }
    // send ACK
    SDA_SetLow();    	// send ACK valid
    SDA_SetDigitalOutput();   // Put port pin to output
    delay_10us();
    SCL_SetHigh();		// Clock the ACK from the I2C Bus
    delay_10us();
    SCL_SetLow();
    delay_10us();
    SDA_SetDigitalInput(); //return SDA to Hi Z
    return input_data;
}

// end of file
