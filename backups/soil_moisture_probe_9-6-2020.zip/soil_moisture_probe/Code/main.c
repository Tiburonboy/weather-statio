// soil moisture probe v1
/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.4
        Device            :  PIC16F18855
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/
/*

Two programming goals to start with:
1) get esp8266 working
2) measure smp frequency


data string:
station_time,smp_value,solar_cell_adc_value,battery_adc_value,rssi,channel

*/

#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include <string.h>
#include <stdio.h>

#include "esp8266.h"
#include "DS1337.h"
#include "i2c.h"

void read_smp(void);
void test_smp(void);
void test_DS1337(void);

uint16_t run_tmr1(void);

// variables
uint8_t LED_flg;
int8_t retVal;  // returned value from varius functions.
//extern bit i2c_ack;
uint8_t update_rtc_flg;  // true if RTC update is needed

// WiFi radio info reported by esp8266
int8_t esp_rssi;  // rssi value from AT+CWJAP_CUR?, usually -59
uint8_t esp_channel;  // channel value from AT+CWJAP_CUR?, usually 4

uint16_t ml_tmr; // main loop timer
uint16_t to_tmr; // time out timer

uint8_t sec_cnt;  // used to count seconds
uint8_t min_cnt;  // used to count minutes
uint8_t hour_cnt;  // used to count hours

uint16_t V_sol_value; // voltage on solar cell, adc counts
uint16_t V_bat_value; // voltage on battery, adc counts
uint16_t smp_value; // soil moisture probe reading

extern uint8_t wifi_connect_flg;  // used to flag if time to connect
extern int8_t wifi_connect_status;  // used to signal WiFi connect status

/*
 * use LED to signal esp8266 status
 * 1*blink = OK
 * 2*blink = can't connect to network
 * 3*blink = can't connect as client
 *
esp8266/WiFi status, two digits on LCD display
0 = esp8266 not present
1 = esp8266 test OK
2 = WiFi Tx/Rx OK

-1 = wakeup test fail
-2 = can't connect to network
-3 = can't connect as client
-4 = RX data error
-5 = RX time error
*/

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();

    // for testing
    I555_reset_SetLow();  // keeps 555 timer IC in reset
    RB5_SetDigitalInput();  // T1G, this is the 555 timer output pin

    LED_flg = 0;
    LED_SetHigh(); // turn off LED

    //I2C initialization
    // set the SDA line low and use TRIS to control the state
    SDA_SetLow();
    SDA_SetDigitalInput();  //SDA is Hi Z

    // set the SCL line as an output
    SCL_SetDigitalOutput();
    SCL_SetHigh();

    // Create a start condition followed by a stop condition
    i2c_start();
    i2c_stop();
    
    // manually set RTC, do only when needed
    update_rtc_flg = 0;
    set_time_date();
    DS1337_init();

    test_DS1337();


    // controll the esp8266 reset pin
    //ESP_RESET_SetHigh(); // bring pin high so spe8266 can run
    esp8266_init(); // put esp8266 into known state, leaves esp8266 in deep sleep

    // esp8266 doesn't like reset being toggeled off then on immediately
    // delay added to end of esp8266_init
    //to_tmr = 0;  // reset timer count
    //while(to_tmr < 2000); // wait 2 sec

    // testing
    V_sol_value = ADCC_GetSingleConversion(V_sol);
    V_bat_value = ADCC_GetSingleConversion(V_bat);

    test_smp();

    read_smp();
    esp_rssi = -127;
    esp_channel = 0;
    connect2network();  // called here for testing


    //  need to delay a bit
    ESP_RESET_SetLow(); // put esp8266 in reset

    // read sensors once after power up
    V_sol_value = ADCC_GetSingleConversion(V_sol);
    V_bat_value = ADCC_GetSingleConversion(V_bat);

    while (1)
    {
        // Add your application code
        // check millis and update seconds & minutes
        if(ml_tmr > 999){
            sec_cnt++;
            ml_tmr = 0;
            LED_SetLow();  // turn on blue LED
            LED_flg = 1;

            if(sec_cnt > 59){
                min_cnt++;
                sec_cnt = 0;
            }
            if(min_cnt > 59){
                hour_cnt++;
                min_cnt = 0;
            }

        }

        // control LED, if on, turn off after 50 ms
        if((ml_tmr > 50) && LED_flg){
            LED_SetHigh();
            LED_flg = 0;
        }

       // connect to the newtork if time
       // for debugging connect every 2 min otherwise every 15 min
       // set for min = 30 so rtc can sync
       if((min_cnt%2 == 0) && wifi_connect_flg){
         // get fresh data
         V_sol_value = ADCC_GetSingleConversion(V_sol);
         V_bat_value = ADCC_GetSingleConversion(V_bat);
         read_smp();
           connect2network();            // wake up esp8266 and connectto server
           wifi_connect_flg = 0;
       }

      if(!(min_cnt%2 == 0))
           wifi_connect_flg = 1; // set flag for next time

    }
}

/************************************
*            test_smp        *
************************************/
/*
Name: test_DS1337
Description: 

Revision History:
*/
void test_DS1337(void)
{
    get_time_date();

    while(1){
        DS1337_init();  // set alarms, control and status
        // set break point to monitor change on INTA pin
        _nop();
    }
}

/************************************
*            test_smp        *
************************************/
/*
Name: test_smp
Description: read soil moisture probe

Revision History:
*/
void test_smp(void)
{
    while(1){
        read_smp();
        _nop();
    }

}


/************************************
*            read_smp        *
************************************/
/*
Name: read_smp
Description: read soil moisture probe

Revision History:
*/
void read_smp(void)
{
uint32_t tmr1_cnt;
uint8_t i;

    // enable 555 timer and delay to allow stabilation
    I555_reset_SetHigh();
    to_tmr = 0;  // reset timer count
    while(to_tmr < 2000); // wait 2 sec

    // average 4 measurements
    tmr1_cnt = 0;
    for(i=0;i<=3;i++)
        tmr1_cnt += (uint32_t) run_tmr1();

    smp_value = tmr1_cnt >> 2;

    I555_reset_SetLow();
}

/************************************
*            run_tmr1        *
************************************/
/*
Name: run_tmr1
Description: Timer 1 capertutes periode of signal

Timer1 Gate is the classical approach to measuring the
pulse width of a periodic and non-periodic signal. It is
recommended that this method be given preference,
since it is very accurate and simple to configure. The
entire capture is performed in hardware. It is also
widely available on most PIC devices.

Timer1 Gate controls when Timer1 increments based
on external triggers. The trigger can either be a rising
or falling edge on the Timer1 gate input.

1.Setup Timer1 Gate for Single-Pulse mode on
rising/falling edge

2.Choose an appropriate Timer1 clock source and
prescale for the pulse

3.Clear TMR1H and TMR1L

4.Enable the module and set T1GG0 bit

5.(pulse occurs)
6.TMR1GIF is set


7. Read pulse width out of TMR1H:L
8. Clear TMR1GIF

Fosc/4 is selected as the Timer1 clock source
with a 1:8 prescale value for the best resolution for signal being measured.

There is uncertainty of plus or minus one clock period.
The worst case will be when the pulse goes Low just
before the rising edge of the clock, or when the pulse
goes High just after the clock. Timer1 has a maximum
count of 65535. On the 65536th period the timer count
overflows to 0. You can accommodate pulses longer
than 65535 Timer1 periods by counting the number of
Timer1 overflows. The TMR1IF bit is set at each over-
flow event. Count the number of overflow events and
add 65536 times that number to the Timer1 count.

Revision History:
*/
// sets ups and captures one period value
uint16_t run_tmr1(void)
{
uint16_t readVal;
uint8_t readValHigh, readValLow;

    // Clear TMR1H and TMR1L
    TMR1H = 0;
    TMR1L = 0;

    // Clearing peripheral flags
    PIR5bits.TMR1GIF = 0;
    PIR4bits.TMR1IF = 0;  // Timer1 Overflow Interrupt Flag bit

    // Enable the module and set T1GG0 bit
    //T1GCONbits.T1GGO = 1;

    // Start the Timer
    T1CONbits.TMR1ON = 1;  // need both of these?
    T1GCONbits.T1GGO = 1;

    // wait for second rising edge when TMR1GIF is set by hardware or timeout
    to_tmr = 0;  // reset time out timer
    while(!PIR5bits.TMR1GIF && (to_tmr < 2000)); // wait 2 sec max
    if(to_tmr >= 2000){
        // timer timed out
        readVal = 0xffff; // timed out, return max value
    }
    // read overflow flag
    else if(PIR4bits.TMR1IF){
        readVal = 0xffff; // overflowed, return max value
    }
    else{
        // Read pulse width out of TMR1H:L
        T1CONbits.T1RD16 = 1;
        readValLow = TMR1L;
        readValHigh = TMR1H;
        readVal = ((uint16_t)readValHigh << 8) | readValLow;
    }

    // Clear TMR1GIF
    PIR5bits.TMR1GIF = 0;

    // Stop the Timer
    T1CONbits.TMR1ON = 0;

    return readVal;
}

/*
 End of File
*/
