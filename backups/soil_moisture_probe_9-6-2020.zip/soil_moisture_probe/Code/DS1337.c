/************************************
*              DS1337.c                *
************************************/
/*
Name: DS1337.c
Synopsis: functions to read and control the Real-Time Clock.
Requires: DS1337 I2C Serial Real-Time Clock
Description:

The DS1337 serial real-time clock is a low-power clock/calendar with two
programmable time-of-day alarms and a programmable square-wave output.
Address and data are transferred serially through an i2c bus.
The clock/calendar provides seconds, minutes, hours, day, date, month, and year
information. The date at the end of the month is automatically adjusted for
months with fewer than 31 days, including corrections for leap year. The clock
operates in either the 24-hour or 12-hour format with AM/PM indicator.

The device is fully accessible through the serial i2c interface while Vcc is
between 1.8V and 5.5V. Operation is not guaranteed below 1.8V.
Timekeeping operation is maintained with Vcc as low as 1.3V.

Programmable square-wave or interrupt output signal. It is an open-drain
output and requires an external pullup resistor. The pull up voltage may
be up to 5.5V, regardless of the voltage on Vcc. If not used, this pin
may be left floating.

When enabled, INTA is asserted low when the time/day/date matches the
values set in the alarm registers. This pin is an open-drain output and
requires an external pullup resistor. The pull up voltage may be up to 5.5V,
regardless of the voltage on Vcc . If not used, this pin may be left floating.

The DS1337 uses an external 32.768kHz crystal. The oscillator circuit does
not require any external resistors or capacitors to operate. The startup time
is usually less than 1 second when using a crystal with the specified
characteristics.

The accuracy of the clock is dependent upon the accuracy of the crystal and
the accuracy of the match between the capacitive load of the oscillator
circuit and the capacitive load for which the crystal was trimmed. Crystal
frequency drift caused by temperature shifts creates additional error.
External circuit noise coupled into the oscillator circuit can result in
the clock running fast. Figure 1 shows a typical PC board layout for
isolating the crystal and oscillator from noise.

ADDRESS MAP
During a multibyte access, when the address pointer reaches the end of the
register space (0Fh) it wraps around to location 00h.
On an i2c START, STOP, or address pointer incrementing to location 00h,
the current time is transferred to a second set of registers. The time
information is read from these secondary registers, while the clock may
continue to run. This eliminates the need to re-read the registers
in case of an update of the main registers during a read.

ADDRESS
00H	Seconds
01H	Minutes
02H	Hours
03H	Day
04H	Date
05H	Month/Century
06H	Year
07H	Alarm 1 Seconds
08H	Alarm 1 Minutes
09H	Alarm 1 Hours
0AH	Alarm 1 Day  Date
0BH	Alarm 2 Minutes
0CH	Alarm 2 Hours
0DH	Alarm 2 Day Date
0EH	Control
0FH	Status

The time and calendar information is obtained by reading the appropriate
register bytes. The RTC registers are illustrated in Table 2. The time and
calendar are set or initialized by writing the appropriate register bytes. The
contents of the time and calendar registers are in the binary-coded
decimal (BCD) format.

The day-of-week register increments at midnight. Values that correspond
to the day of week are user-defined but must be sequential (i.e., if 1
equals Sunday, then 2 equals Monday, and so on.). Illogical time and date
entries result in undefined operation.

When reading or writing the time and date registers, secondary (user)
buffers are used to prevent errors when the internal registers update.
When reading the time and date registers, the user buffers are
synchronized to the internal registers on any start or stop and when
the register pointer rolls over to zero. The countdown chain is reset
whenever the seconds register is written. Write transfers occur on the
acknowledge pulse from the device. To avoid rollover issues, once the
countdown chain is reset, the remaining time and date registers must be
written within 1 second. The 1Hz square-wave output, if enable,
transitions high 500ms after the seconds data transfer, provided
the oscillator is already running.

The DS1337 can be run in either 12-hour or 24-hour mode. Bit 6 of the
hours register is defined as the 12- or 24-hour mode-select bit. When high,
the 12-hour mode is selected. In the 12-hour mode, bit 5 is the AM/PM bit
with logic high being PM. In the 24-hour mode, bit 5 is the second
10-hour bit (20–23 hours). All hours values, including the alarms,
must be reinitialized whenever the 12/24-hour mode bit is changed.
The century bit (bit 7 of the month register) is toggled when the years
register overflows from 99–00.

ALARMS
The DS1337 contains two time-of-day/date alarms. Alarm 1 can be set by writing
to registers 07h–0Ah. Alarm 2 can be set by writing to registers 0Bh–0Dh.

The alarms can be programmed (by the INTCN bit of the control register)
to operate in two different modes—each alarm can drive its own separate
interrupt output or both alarms can drive a common interrupt output.
Bit 7 of each of the time-of-day/date alarm registers are mask bits (Table 2).

When all of the mask bits for each alarm are logic 0, an alarm only
occurs when the values in the timekeeping registers 00h–06h match the
values stored in the time-of-day/date alarm registers. The alarms can also be
programmed to repeat every second, minute, hour, day, or date.

The DY/DT bits (bit 6 of the alarm day/date registers) control whether
the alarm value stored in bits 0–5 of that register reflects the day
of the week or the date of the month. If DY/DT is written to logic 0,
the alarm is the result of a match with date of the month. If DY/DT is
written to logic 1, the alarm is the result of a match with day of the
week.

When the RTC register values match alarm register settings, the corresponding
alarm flag (A1F or A2F) bit is set to logic 1. The bit(s) will remain at a
logic 1 until written to a logic 0 by the user. If the corresponding alarm
interrupt enable (A1IE or A2IE) is also set to logic 1, the alarm condition
activates one of the interrupt output (INTA or SQW/INTB) signals.
The match is tested on the once-per-second update of the time and
date registers.


Revision History:
9/4/2020:  Old code for DS1307 rewritten for DS1337

*/

#include "mcc_generated_files/mcc.h"
#include <string.h>
#include <stdio.h>
#include "i2c.h"
#include "DS1337.h"
#include "esp8266.h"

// 8 bit write address
#define DS1337_ADDRESS 0xc0

extern uint8_t update_rtc_flg;

extern struct network_timedate network_timedate;
struct DS1337_regs DS1337;

/************************************
*       DS1337_init           *
************************************/
/*
Name: DS1337_init
Description: initialize DS1337

could rename to set_alarm

Alarm #1 is set for minutes and seconds match
A1M1 = 0
A1M2 = 1  alarm when seconds match, used for testing, later set to 30 min match
A1M3 = 1
A1M4 = 1
DY/DT = X

Alarm #2 not used because SWQ is used.

Control Register
Enable Oscillator = 0, which makes oscillator run
Rate Select (RS2=0 and RS1=0) SWQ = 1Hz
INTCN = 0 to allow SWQ output
A2IE = X when INTCN is low
A2IE = 1, allows INTA to be asserted by AF1

Status Register (0Fh)
Bit 7: Oscillator Stop Flag (OSF). A logic 1 in this bit indicates that the oscillator either is stopped or was stopped
for some period of time and may be used to judge the validity of the clock and calendar data. This bit is set to logic
1 anytime that the oscillator stops. The following are examples of conditions that can cause the OSF bit to be set:
1) The first time power is applied.
2) The voltage present on Vcc is insufficient to support oscillation.
3) The EOSC bit is turned off.
4) External influences on the crystal (e.g., noise, leakage, etc.).
This bit remains at logic 1 until written to logic 0.

Bit 1: Alarm 2 Flag (A2F).
Bit 0: Alarm 1 Flag (A1F).
A1F is cleared when written to logic 0.

Revision History:
*/
void DS1337_init(void)
{
uint8_t temp[9];

    // set the alarms
    DS1337.A1_second = 30;  // set when seconds = 30
    DS1337.A1_minute = 0;
    DS1337.A1_hour = 0;
    DS1337.A1_DayDate = 0;
    // alarm 2 not used, since SQW is enabled
    DS1337.A2_minute = 0;
    DS1337.A2_hour = 0;
    DS1337.A2_DayDate = 0;

    // set status and control
    DS1337.rtc_control = 0x01; // enable 1Hz, alarm 1 interrupt
    DS1337.rtc_status = 0;  // clears alarm status flags

    temp[0] = decToBcd(DS1337.A1_second) & 0x7f; // clear A1M1, alarm when seconds match
    temp[1] = decToBcd(DS1337.A1_minute) & 0xff; // set A1M2
    temp[2] = decToBcd(DS1337.A1_hour) & 0xbf; // set A1M3, clear 12/*24
    temp[3] = decToBcd(DS1337.A1_DayDate) & 0xbf; // set A1M4, clear DY/*DT
    temp[4] = 0; //decToBcd(DS1337.A2_minute);
    temp[5] = 0; //decToBcd(DS1337.A2_hour);
    temp[6] = 0; //decToBcd(DS1337.A2_DayDate);

    temp[7] = DS1337.rtc_control;
    temp[8] = DS1337.rtc_status;

    write_ds1337(0x07, temp, 9);

    //update_rtc_flg = 0;
    //set_time_date();
}

/************************************
*       get time and date           *
************************************/
/*
Name: get time and date
Description:  reads 7 of the registers from the DS1337
Revision History:
*/
void get_time_date(void)
{
uint8_t temp[7];

    read_ds1337(0, temp, 7);  // read 7 registers

    DS1337.second = bcdToDec(temp[0]);
    DS1337.minute = bcdToDec(temp[1]);
    DS1337.hour = bcdToDec(temp[2]); 		// 24 hour time
    DS1337.weekDay = bcdToDec(temp[3]); 	// 1-7 = Sunday - Saturday
    DS1337.monthDay = bcdToDec(temp[4]); // 01 to 31
    DS1337.month = bcdToDec(temp[5] & 0x7f); // Month, mask out century
    DS1337.year = bcdToDec(temp[6]);
}

/************************************
*       set time and date           *
************************************/
/*
Name: set_time_date
Description: write all resisters to the DS1337

Looks at update_rtc_flg to determine if new time comes from the
network or hard coded.

Revision History:

*/
void set_time_date(void)
{
uint8_t temp[7];

    // set RTC with new time
    if(update_rtc_flg){
        DS1337.second = network_timedate.second; //0-59
        DS1337.minute =  network_timedate.minute; //0-59
        DS1337.hour =  network_timedate.hour; //0-23
        DS1337.monthDay =  network_timedate.day; //1-31
        DS1337.month =  network_timedate.month; //1-12
        DS1337.year  =   network_timedate.year; //0-99
    }
    else {
        // manually set values for clock
        DS1337.second =      0; //0-59, this also sets the CH bit to zero = osc runs
        DS1337.minute =      26; //0-59
        DS1337.hour =        7; //0-23
        DS1337.weekDay =     6; //1-7, Sunday = 1
        DS1337.monthDay =    5; //1-31
        DS1337.month =       9; //1-12
        DS1337.year  =       20; //0-99
    }

    // put formated data into array for sending
    temp[0] = decToBcd(DS1337.second);
    temp[1] = decToBcd(DS1337.minute);
    temp[2] = decToBcd(DS1337.hour);
    temp[3] = decToBcd(DS1337.weekDay);
    temp[4] = decToBcd(DS1337.monthDay);
    temp[5] = decToBcd(DS1337.month);
    temp[6] = decToBcd(DS1337.year);

    write_ds1337(0, temp, 7);
}

/************************************
*      Dec & BCD Conversions        *
************************************/
/*
Synopsis: functions to convert to and from BCD
Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/
uint8_t decToBcd(uint8_t val){
// Convert normal decimal numbers to binary coded decimal
  return ( (val/10*16) + (val%10) );
}

uint8_t bcdToDec(uint8_t val)  {
// Convert binary coded decimal to normal decimal numbers
  return ( (val/16*10) + (val%16) );
}

/************************************
*       write ds1337                *
************************************/
/*
Name: write ds1307
Synopsis: writes data to the DS1337 real time clock
Requires:
wrd_addrs:  word address or register pointer
*ptr: pointer to list of data
len: length of data list to send
pointer to data and number of bytes to write
Description:
Author: Tony Cirineo
Date:
Revision History:
*/
void write_ds1337(uint8_t wrd_addrs, uint8_t *ptr, uint8_t len)
{
uint8_t dev_addrs;
uint8_t i;
// still needs fixing
    // build device address
    dev_addrs = DS1337_ADDRESS;    // leave R/W bit as a zero

    // write device address, word address, then len bytes of data
    i2c_start();
    i2c_write(dev_addrs);	// device address
    i2c_write(wrd_addrs);	// word address
    for(i = 0;i < len;i++)
        i2c_write(*ptr++);
    i2c_stop();	// create a stop condition
}

/************************************
*       read ds1337                 *
************************************/
/*
Name: data read ds1337
Synopsis:
Data Read (Write Pointer, Then Read)—Slave Receive and Transmit

Requires:
wrd_addrs:  word address or register pointer
*ptr: pointer to list of data
len: length of data list to send
pointer to data and number of bytes to write
Description:
Author: Tony Cirineo
Date:
Revision History:
*/
void read_ds1337(uint8_t wdr_addrs, uint8_t *ptr, uint8_t len)
{
uint8_t dev_addrs;
uint8_t i,j,input_data;

	// write device address, then word address followed by repeated start
	dev_addrs = DS1337_ADDRESS;    //leave w/r set to 0
	i2c_start();
	i2c_write(dev_addrs);	// device address
	i2c_write(wdr_addrs);	// word address
	i2c_start();	// send start condition

    // read the data from the device
	dev_addrs |= 0x01;      //set the w/r bit to 1 for read
	i2c_write(dev_addrs);	// device address

    // read len-1 bytes of data followed by ACK
    SDA_SetDigitalInput();        	// set SDA pin as input
    delay_10us();
    for(i = 0;i < len-1;i++){
        input_data = 0x00;
        for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
            input_data <<= 1;   // Shift the byte by one bit
            SCL_SetHigh();         // Clock the data into the I2C Bus
            delay_10us();
            input_data |= SDA_GetValue();  // Input the data from the I2C Bus
            delay_10us();
            SCL_SetLow();
            delay_10us();
        }
        // send ACK
        SDA_SetLow();    	// send ACK valid
        SDA_SetDigitalOutput();   // Put port pin to output
        delay_10us();
        SCL_SetHigh();		// Clock the ACK from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
        SDA_SetDigitalInput(); //return SDA to Hi Z
        *ptr++ = input_data;        //save received data
    }

    // now read last byte of data followed by NACK
    input_data = 0x00;
    for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
        input_data <<= 1;   // Shift the byte by one bit
        SCL_SetHigh();         // Clock the data into the I2C Bus
        delay_10us();
        input_data |= SDA_GetValue();  // Input the data from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
    }
    // send NACK
    SDA_SetHigh();    	// send NACK valid
    SDA_SetDigitalOutput();   // Put port pin to output
    delay_10us();
    SCL_SetHigh();		// Clock the ACK from the I2C Bus
    delay_10us();
    SCL_SetLow();
    delay_10us();
    SDA_SetDigitalInput(); //return SDA to Hi Z

    *ptr = input_data;        //save last received data

	i2c_stop();	// create a stop condition
}

// end of file
