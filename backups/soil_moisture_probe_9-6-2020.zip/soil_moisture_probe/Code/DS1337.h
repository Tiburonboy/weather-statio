/************************************
*       DS1337.h                       *
************************************/
/*
Name: DS1337.h
Synopsis: header file for rtc
Author: Tony Cirineo
Revision History:
*/

void write_ds1337(uint8_t wdr_addrs, uint8_t *ptr, uint8_t len);
void read_ds1337(uint8_t wrd_addrs, uint8_t *ptr, uint8_t len);
void DS1337_init(void);

uint8_t decToBcd(uint8_t val);
uint8_t bcdToDec(uint8_t val);
void set_time_date(void);
void get_time_date(void);

struct DS1337_regs{
    uint8_t second;
    uint8_t minute;
    uint8_t hour; 		// 24 hour time
    uint8_t weekDay; 	// 1-7 = Sunday - Saturday
    uint8_t monthDay; // 01 to 31
    uint8_t month; // Month/Century
    uint8_t year;
    uint8_t A1_second;
    uint8_t	A1_minute;
    uint8_t	A1_hour;
    uint8_t	A1_DayDate;
    uint8_t	A2_minute;
    uint8_t	A2_hour;
    uint8_t	A2_DayDate;
    uint8_t	rtc_control;
    uint8_t	rtc_status;
};


//end
