/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.4
        Device            :  PIC16F18855
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.20 and above
        MPLAB 	          :  MPLAB X 5.40	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set INTA aliases
#define INTA_TRIS                 TRISAbits.TRISA0
#define INTA_LAT                  LATAbits.LATA0
#define INTA_PORT                 PORTAbits.RA0
#define INTA_WPU                  WPUAbits.WPUA0
#define INTA_OD                   ODCONAbits.ODCA0
#define INTA_ANS                  ANSELAbits.ANSA0
#define INTA_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define INTA_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define INTA_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define INTA_GetValue()           PORTAbits.RA0
#define INTA_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define INTA_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define INTA_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define INTA_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define INTA_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define INTA_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define INTA_SetAnalogMode()      do { ANSELAbits.ANSA0 = 1; } while(0)
#define INTA_SetDigitalMode()     do { ANSELAbits.ANSA0 = 0; } while(0)

// get/set SCL aliases
#define SCL_TRIS                 TRISAbits.TRISA1
#define SCL_LAT                  LATAbits.LATA1
#define SCL_PORT                 PORTAbits.RA1
#define SCL_WPU                  WPUAbits.WPUA1
#define SCL_OD                   ODCONAbits.ODCA1
#define SCL_ANS                  ANSELAbits.ANSA1
#define SCL_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define SCL_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define SCL_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define SCL_GetValue()           PORTAbits.RA1
#define SCL_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define SCL_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define SCL_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define SCL_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define SCL_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define SCL_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define SCL_SetAnalogMode()      do { ANSELAbits.ANSA1 = 1; } while(0)
#define SCL_SetDigitalMode()     do { ANSELAbits.ANSA1 = 0; } while(0)

// get/set SDA aliases
#define SDA_TRIS                 TRISAbits.TRISA2
#define SDA_LAT                  LATAbits.LATA2
#define SDA_PORT                 PORTAbits.RA2
#define SDA_WPU                  WPUAbits.WPUA2
#define SDA_OD                   ODCONAbits.ODCA2
#define SDA_ANS                  ANSELAbits.ANSA2
#define SDA_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define SDA_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define SDA_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define SDA_GetValue()           PORTAbits.RA2
#define SDA_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define SDA_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define SDA_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define SDA_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define SDA_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define SDA_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define SDA_SetAnalogMode()      do { ANSELAbits.ANSA2 = 1; } while(0)
#define SDA_SetDigitalMode()     do { ANSELAbits.ANSA2 = 0; } while(0)

// get/set SQW aliases
#define SQW_TRIS                 TRISAbits.TRISA3
#define SQW_LAT                  LATAbits.LATA3
#define SQW_PORT                 PORTAbits.RA3
#define SQW_WPU                  WPUAbits.WPUA3
#define SQW_OD                   ODCONAbits.ODCA3
#define SQW_ANS                  ANSELAbits.ANSA3
#define SQW_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define SQW_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define SQW_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define SQW_GetValue()           PORTAbits.RA3
#define SQW_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define SQW_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define SQW_SetPullup()          do { WPUAbits.WPUA3 = 1; } while(0)
#define SQW_ResetPullup()        do { WPUAbits.WPUA3 = 0; } while(0)
#define SQW_SetPushPull()        do { ODCONAbits.ODCA3 = 0; } while(0)
#define SQW_SetOpenDrain()       do { ODCONAbits.ODCA3 = 1; } while(0)
#define SQW_SetAnalogMode()      do { ANSELAbits.ANSA3 = 1; } while(0)
#define SQW_SetDigitalMode()     do { ANSELAbits.ANSA3 = 0; } while(0)

// get/set LED aliases
#define LED_TRIS                 TRISAbits.TRISA4
#define LED_LAT                  LATAbits.LATA4
#define LED_PORT                 PORTAbits.RA4
#define LED_WPU                  WPUAbits.WPUA4
#define LED_OD                   ODCONAbits.ODCA4
#define LED_ANS                  ANSELAbits.ANSA4
#define LED_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define LED_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define LED_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define LED_GetValue()           PORTAbits.RA4
#define LED_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define LED_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define LED_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define LED_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define LED_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define LED_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define LED_SetAnalogMode()      do { ANSELAbits.ANSA4 = 1; } while(0)
#define LED_SetDigitalMode()     do { ANSELAbits.ANSA4 = 0; } while(0)

// get/set I555_reset aliases
#define I555_reset_TRIS                 TRISAbits.TRISA5
#define I555_reset_LAT                  LATAbits.LATA5
#define I555_reset_PORT                 PORTAbits.RA5
#define I555_reset_WPU                  WPUAbits.WPUA5
#define I555_reset_OD                   ODCONAbits.ODCA5
#define I555_reset_ANS                  ANSELAbits.ANSA5
#define I555_reset_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define I555_reset_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define I555_reset_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define I555_reset_GetValue()           PORTAbits.RA5
#define I555_reset_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define I555_reset_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define I555_reset_SetPullup()          do { WPUAbits.WPUA5 = 1; } while(0)
#define I555_reset_ResetPullup()        do { WPUAbits.WPUA5 = 0; } while(0)
#define I555_reset_SetPushPull()        do { ODCONAbits.ODCA5 = 0; } while(0)
#define I555_reset_SetOpenDrain()       do { ODCONAbits.ODCA5 = 1; } while(0)
#define I555_reset_SetAnalogMode()      do { ANSELAbits.ANSA5 = 1; } while(0)
#define I555_reset_SetDigitalMode()     do { ANSELAbits.ANSA5 = 0; } while(0)

// get/set ESP_RESET aliases
#define ESP_RESET_TRIS                 TRISBbits.TRISB4
#define ESP_RESET_LAT                  LATBbits.LATB4
#define ESP_RESET_PORT                 PORTBbits.RB4
#define ESP_RESET_WPU                  WPUBbits.WPUB4
#define ESP_RESET_OD                   ODCONBbits.ODCB4
#define ESP_RESET_ANS                  ANSELBbits.ANSB4
#define ESP_RESET_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define ESP_RESET_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define ESP_RESET_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define ESP_RESET_GetValue()           PORTBbits.RB4
#define ESP_RESET_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define ESP_RESET_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define ESP_RESET_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define ESP_RESET_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define ESP_RESET_SetPushPull()        do { ODCONBbits.ODCB4 = 0; } while(0)
#define ESP_RESET_SetOpenDrain()       do { ODCONBbits.ODCB4 = 1; } while(0)
#define ESP_RESET_SetAnalogMode()      do { ANSELBbits.ANSB4 = 1; } while(0)
#define ESP_RESET_SetDigitalMode()     do { ANSELBbits.ANSB4 = 0; } while(0)

// get/set RB5 procedures
#define RB5_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define RB5_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define RB5_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define RB5_GetValue()              PORTBbits.RB5
#define RB5_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define RB5_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define RB5_SetPullup()             do { WPUBbits.WPUB5 = 1; } while(0)
#define RB5_ResetPullup()           do { WPUBbits.WPUB5 = 0; } while(0)
#define RB5_SetAnalogMode()         do { ANSELBbits.ANSB5 = 1; } while(0)
#define RB5_SetDigitalMode()        do { ANSELBbits.ANSB5 = 0; } while(0)

// get/set RC0 procedures
#define RC0_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define RC0_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define RC0_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define RC0_GetValue()              PORTCbits.RC0
#define RC0_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define RC0_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define RC0_SetPullup()             do { WPUCbits.WPUC0 = 1; } while(0)
#define RC0_ResetPullup()           do { WPUCbits.WPUC0 = 0; } while(0)
#define RC0_SetAnalogMode()         do { ANSELCbits.ANSC0 = 1; } while(0)
#define RC0_SetDigitalMode()        do { ANSELCbits.ANSC0 = 0; } while(0)

// get/set RC1 procedures
#define RC1_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define RC1_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define RC1_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define RC1_GetValue()              PORTCbits.RC1
#define RC1_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define RC1_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define RC1_SetPullup()             do { WPUCbits.WPUC1 = 1; } while(0)
#define RC1_ResetPullup()           do { WPUCbits.WPUC1 = 0; } while(0)
#define RC1_SetAnalogMode()         do { ANSELCbits.ANSC1 = 1; } while(0)
#define RC1_SetDigitalMode()        do { ANSELCbits.ANSC1 = 0; } while(0)

// get/set V_bat aliases
#define V_bat_TRIS                 TRISCbits.TRISC2
#define V_bat_LAT                  LATCbits.LATC2
#define V_bat_PORT                 PORTCbits.RC2
#define V_bat_WPU                  WPUCbits.WPUC2
#define V_bat_OD                   ODCONCbits.ODCC2
#define V_bat_ANS                  ANSELCbits.ANSC2
#define V_bat_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define V_bat_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define V_bat_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define V_bat_GetValue()           PORTCbits.RC2
#define V_bat_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define V_bat_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define V_bat_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define V_bat_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define V_bat_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define V_bat_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define V_bat_SetAnalogMode()      do { ANSELCbits.ANSC2 = 1; } while(0)
#define V_bat_SetDigitalMode()     do { ANSELCbits.ANSC2 = 0; } while(0)

// get/set V_sol aliases
#define V_sol_TRIS                 TRISCbits.TRISC5
#define V_sol_LAT                  LATCbits.LATC5
#define V_sol_PORT                 PORTCbits.RC5
#define V_sol_WPU                  WPUCbits.WPUC5
#define V_sol_OD                   ODCONCbits.ODCC5
#define V_sol_ANS                  ANSELCbits.ANSC5
#define V_sol_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define V_sol_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define V_sol_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define V_sol_GetValue()           PORTCbits.RC5
#define V_sol_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define V_sol_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define V_sol_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define V_sol_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define V_sol_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define V_sol_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define V_sol_SetAnalogMode()      do { ANSELCbits.ANSC5 = 1; } while(0)
#define V_sol_SetDigitalMode()     do { ANSELCbits.ANSC5 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/