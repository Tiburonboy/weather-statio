"""
Soil Moisture Test Server V1
Last update: 8/24/2020

Name: smp_test_server_v1.py
Synopsis: Python program to communicate with the soil moister probe station.
Requires: python 3
Description:

Author: Tony Cirineo

Revision History:
program modified online tutorials


"""
import time
from datetime import datetime
import os
import socket

HOST = '192.168.1.44' # HP Laptop ip address, reported by running ifconfig
#HOST = '192.168.1.15' # Rpi0w ip address, reported by running ifconfig
PORT = 12345 # just some large number hopefully not in use
BUFFER_SIZE = 64 # data block size

# Create a TCP/IP socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Bind the socket to the host and port
s.bind((HOST, PORT))
print('Listening for connections')

s.listen(1)  # accepts 2 connections

# add column headings, do only once when file is first created
os.chdir('/home/jim/Documents/soil_moisture_probe/') # point to the correct directory

if os.path.isfile('smp_data.csv') == False:
    # if the file does not exits make it
    f = open('smp_data.csv', 'a')
    f.write('server_time,clientIP,addrs,station_time,smp_value,solar_cell_adc_value,battery_adc_value,rssi,channel\r\n')
    f.close()

# run the main loop
try:
    while True:
        # Accept the incomming connection
        conn, addr = s.accept()
        # Print the info of client
        print ('connected with ' , addr)
        # Receive BUFFER_SIZE bytes data
        rx_data = conn.recv(BUFFER_SIZE)
        if rx_data:
            #print received data
            print('data from client: ' , rx_data)

            # check which client is sending data
            if addr[0] == '192.168.1.62':  # soil moisture probe station
                server_timestamp_obj = datetime.now()

                # remove unwanted characters from data string
                rx_data = str(rx_data,'utf-8') # convert byte object to string
                rx_data = rx_data.replace(' ','')
                rx_data = rx_data.replace('\x00','')
                rx_data = rx_data.replace('z','') # don't do when base64 raw data is sent

                #unpack comma seperated values, remove spaces
                rx_data_list = rx_data.split(',')

                client_time_str = rx_data_list[0]
                smp_value = int(rx_data_list[1])
                solar_cell_adc_value = int(rx_data_list[2])
                battery_adc_value = int(rx_data_list[3])
                esp_rssi = int(rx_data_list[4])
                esp_channel = int(rx_data_list[5])

                print('server time stamp: {:s}'.format(server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S")))
                print('client: {:s}, {:d}'.format(addr[0],addr[1]))
                print('client time: {:s}'.format(client_time_str))
                print('smp_value: {:d}'.format(smp_value))
                print('solar_cell_adc_value: {:d}'.format(solar_cell_adc_value))
                print('battery_adc_value: {:d}'.format(battery_adc_value))
                print('rssi: {:d}'.format(esp_rssi))
                print('channel: {:d}'.format(esp_channel))

                # store client data to file
                f = open('smp_data.csv', 'a')
                # write data to file
                # server_time,clientIP,addrs,station_time,smp_value,solar_cell_adc_value,battery_adc_value,rssi,channel
                f.write('{:s},{:s},{:d},{:s},{:d},{:d},{:d},{:d},{:d}\r\n'.format(
                    server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S"),
                    addr[0],
                    addr[1],
                    client_time_str,
                    smp_value,
                    solar_cell_adc_value,
                    battery_adc_value,
                    esp_rssi,
                    esp_channel))
                f.close()

                # send server date and time back to client
                tx_data = datetime.now().strftime("%m/%d/%y,%H:%M:%S")
                tx_data +='z'*(BUFFER_SIZE-len(tx_data))
                conn.send(tx_data.encode())
            else:
                print('unknown client station')

except KeyboardInterrupt: # if CTRL+C, exit cleanly
    print("\n\rexiting")
    time.sleep(2)
    conn.close()
    print('connection closed')

#end
