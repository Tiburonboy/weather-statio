"""
sync_display0_v1
Last update: 9/2/2020

Name: sync_display0_v1.py
Description:
This code is for prototype weather station display.
This code will synchronize the Rpi0w with the sleep timer.  This used to be
accompliashed by inserting the battery 3 minutes before data
collection time.

Start script after Rpi_sleepy has next entered the wake_up_pi loop.
pulses the shut_dwn line
powers off

Revision History:

"""
import sys
import time
import os
import RPi.GPIO as GPIO

sw1 = 11 # sw1, debug enable switch, used to prevent code running poweroff
shut_dwn = 13 # shut down signal to PIC
GPIO.setmode(GPIO.BOARD)
GPIO.setup(sw1, GPIO.IN)
GPIO.setup(shut_dwn, GPIO.OUT)

GPIO.output(shut_dwn,True)  # signal Rpi_sleepy
time.sleep(1) # give PIC time to catch the signal
GPIO.output(shut_dwn,False)  # signal Rpi_sleepy to disable power supply

if GPIO.input(sw1): # read the switch
    print('sw1 is up, running shutdown')
    GPIO.cleanup() # cleanup all GPIO
    os.system('sudo shutdown -h now')
else:
    print('sw1 is down, debug-no shutdown')
    GPIO.cleanup() # cleanup all GPIO
    sys.exit('system exit') # leave the script and return to command prompt

# end
