'''
rtc_lib.py
Functions to read and control the DS1307 Real-Time Clock.

The DS1307 Serial Real-Time Clock is a low-power, full binary-coded decimal (BCD) clock/calendar
plus 56 bytes of NV SRAM. Address and data are transferred serially via a 2-wire, bi-directional bus.
The clock/calendar provides seconds, minutes, hours, day, date, month, and year information. The end of
the month date is automatically adjusted for months with fewer than 31 days, including corrections for
leap year. The clock operates in either the 24-hour or 12-hour format with AM/PM indicator. The
DS1307 has a built-in power sense circuit that detects power failures and automatically switches to the
battery supply.

V BAT – Battery input for any standard 3V lithium cell or other energy source. Battery voltage must be
held between 2.0V and 3.5V for proper operation. The nominal write protect trip point voltage at which
access to the RTC and user RAM is denied is set by the internal circuitry as 1.25 x V BAT nominal. A
lithium battery with 48mAhr or greater will back up the DS1307 for more than 10 years in the absence of
power at 25C. UL recognized to ensure against reverse charging current when used in conjunction with a
lithium battery.

SQW/OUT (Square Wave/Output Driver) – When enabled, the SQWE bit set to 1, the SQW/OUT pin
outputs one of four square wave frequencies (1Hz, 4kHz, 8kHz, 32kHz). The SQW/OUT pin is open
drain and requires an external pull-up resistor. SQW/OUT will operate with either Vcc or Vbat applied.

http://wiki.erazor-zone.de/wiki:linux:python:smbus:doc

Revision History:
8/9/2020:  NHD and RTC do not work together on the i2c bus.
sudo i2cdetect -y 1 returns only the RTC and not the LCD
removed 1k pull resistors on the PCA9306 break out board, did not fix problem
sudo i2cdetect -y 1 still returns only the RTC and not the LCD

Did some research:
i2c clock cannot be changed to below 100kHz
NHD reported has weak i2c line drive capability, which may be the problem

going to implement software i2c bus on general purpose IO pins
replace bus.read_block_data with sw_i2c.read_block_data

8/9/2020:  modified to use software i2c, see backup files older than
this date to view non-working smbus i2c interface
'''
import sw_i2c_lib
from time import *
from datetime import datetime

# define the DS1307_rtc class
class DS1307_rtc:

    addr = 0x68 # 7 bit address of DS1307 Real-Time Clock

    second = 0
    minute = 0
    hour = 0 		# 24 hour time
    weekDay = 1 	# 1-7 = Sunday - Saturday
    monthDay = 1
    month = 1
    year = 0
    rtc_config = 0
    pData = [0,0,0,0,0,0,0,0]  # actually 56 bytes in the DS1307 address space

    def __init__(self):
        # initialize software i2c
        self.sw_i2c = sw_i2c_lib.software_i2c()

    def get_time_date(self):
        #pData = self.bus.read_block_data(self.addr,0,8)
        self.pData = self.sw_i2c.read_block_data(self.addr,0,8)
        self.second = self.bcdToDec(self.pData[0])
        self.minute = self.bcdToDec(self.pData[1])
        self.hour = self.bcdToDec(self.pData[2] & 0b111111) # 24 hour time
        self.weekDay = self.bcdToDec(self.pData[3]) # 1-7 -> Sunday - Saturday
        self.monthDay = self.bcdToDec(self.pData[4])
        self.month = self.bcdToDec(self.pData[5])
        self.year = self.bcdToDec(self.pData[6])
        self.rtc_config = self.pData[7]

    def set_time_date(self):
        # set values from system clock
        server_timestamp_obj = datetime.now() # get system time and date
        # verify network time is correct, should match RTC except for min and sec
        # don't want WiFi error to set RTC to zero
        self.get_time_date() # get RTC time and date
        # roll over logic is complicated, if near top of the hour, skip
        if (server_timestamp_obj.minute < 55) and (server_timestamp_obj.minute > 5):
            # check for agrement between weather station time and network time
            # should only be seconds and minutes error
            if server_timestamp_obj.month == self.month :
                if server_timestamp_obj.day == self.monthDay:
                    if server_timestamp_obj.year == self.year:
                        if server_timestamp_obj.hour == self.hour: # min & sec could be diff, just look for correct hours
                            # all but minutes and seconds must agree
                            # use network time to set RTC, put formated data into array for sending
                            self.pData[0] = self.decToBcd(server_timestamp_obj.second) # 0-59, this also sets the CH bit to zero = osc runs
                            self.pData[1] = self.decToBcd(server_timestamp_obj.minute) # 0-59
                            self.pData[2] = self.decToBcd(server_timestamp_obj.hour) # 0-23
                            # weekday() returns the day of the week as an integer, where Monday is 0 and Sunday is 6
                            # 6, 0, 1, 2, 3, 4, 5, 6 need to convert to 1, 2, 3, 4, 5, 6, 7 where sunday = 1
                            # weekday not used, so it's a don't care, but can't be initialized to zero
                            wd = server_timestamp_obj.weekday() + 2
                            if wd > 7:
                                wd = 1
                            self.pData[3] = self.decToBcd(wd) # 1-7, Sunday = 1
                            self.pData[4] = self.decToBcd(server_timestamp_obj.day) # 1-31
                            self.pData[5] = self.decToBcd(server_timestamp_obj.month) # 1-12
                            self.pData[6] = self.decToBcd(server_timestamp_obj.year-2000) # 0-99
                            self.rtc_config = 0x10 # turn on SQW 1Hz
                            self.pData[7] = self.rtc_config
                            #self.bus.write_block_data(self.addr,0,pData)
                            self.sw_i2c.write_block_data(self.addr,0,self.pData)

    def decToBcd(self,val):
        # Convert normal decimal numbers to binary coded decimal
        return (int(val/10)*16 + val%10)

    def bcdToDec(self,val):
        # Convert binary coded decimal to normal decimal numbers
        return (int(val/16)*10 + val%16)

# end of file
