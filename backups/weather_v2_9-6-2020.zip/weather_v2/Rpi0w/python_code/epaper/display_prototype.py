'''
Prototyping weather station epaper display

'''
from tkinter import *
from datetime import datetime, timedelta
from PIL import Image, ImageTk
import os

os.chdir('/home/jim/Documents/weather_v2/Rpi0w/python_code/')

master = Tk()

# some data to display
humidity = 56.3
dpf_approx = 58.6
barometer = 29.63
trend = 'steady'
epaper_width = 480
epaper_height = 800

w = Canvas(master, width=epaper_width, height=epaper_height)
w.pack()

master.title('weather Station epaper display prototype')

#w.create_line(0, 0, 200, 100)
#w.create_line(0, 100, 200, 0, fill="red", dash=(4, 4))

#w.create_rectangle(50, 25, 150, 75, fill="blue")

# make a lable
#w.Label(master, text="Hello Tkinter!")

w.create_text(epaper_width/2,10, text='@ 12:45')

load = Image.open('24hr temperature.png')
render = ImageTk.PhotoImage(load)

# labels can be text or images
img = Label(image=render)
img.image = render
img.place(x=0, y=20)

load = Image.open('7 day barometer.png')
render = ImageTk.PhotoImage(load)

# labels can be text or images
img = Label(image=render)
img.image = render
img.place(x=0, y=325)


w.create_text(epaper_width/2,650, text='humidity {:.1f}%RH'.format(humidity))
w.create_text(epaper_width/2,660, text='dew point {:.1f}F'.format(dpf_approx))
w.create_text(epaper_width/2,670, text='barometric pressure {:.2f}inHg {:s}'.format(barometer,trend))
w.create_text(epaper_width/2,680, text='Tuedsay Sept 1')
w.create_text(epaper_width/2,790, text='display bottom')



mainloop()










'''


def calculate(*args):
    try:
        value = float(feet.get())
        meters.set((0.3048 * value * 10000.0 + 0.5)/10000.0)
    except ValueError:
        pass
    
root = Tk()
root.title("Feet to Meters")

mainframe = ttk.Frame(root, padding="3 3 12 12")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)

feet = StringVar()
meters = StringVar()

feet_entry = ttk.Entry(mainframe, width=7, textvariable=feet)
feet_entry.grid(column=2, row=1, sticky=(W, E))

ttk.Label(mainframe, textvariable=meters).grid(column=2, row=2, sticky=(W, E))
ttk.Button(mainframe, text="Calculate", command=calculate).grid(column=3, row=3, sticky=W)

ttk.Label(mainframe, text="feet").grid(column=3, row=1, sticky=W)
ttk.Label(mainframe, text="is equivalent to").grid(column=1, row=2, sticky=E)
ttk.Label(mainframe, text="meters").grid(column=3, row=2, sticky=W)

for child in mainframe.winfo_children(): child.grid_configure(padx=5, pady=5)

feet_entry.focus()
root.bind('<Return>', calculate)

root.mainloop()



from tkinter import *

master = Tk()

w = Canvas(master, width=480, height=800)
w.pack()

i = w.create_line(0, 0, 200, 100)
j = w.create_line(0, 100, 200, 0, fill="red", dash=(4, 4))

k = w.create_rectangle(50, 25, 150, 75, fill="blue")

m = w.create_text(120,120, text='this is a test')

mainloop()

w.delete(i)
mainloop()
'''


