#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
Soil moisture probe client simulator
last update: 20 July 2020

Name:
Synopsis:
Requires:
Description:
Author: Tony Cirineo
Date:  8/5/03
Revision History:
# Socket Chatroom client - Creating chat application with sockets in Python
# https://pythonprogramming.net/client-chatroom-sockets-tutorial-python-3/

'''
from datetime import datetime
import socket
import time

BUFFER_SIZE = 64 # data block size

IP = '192.168.1.44' # HP Laptop ip address, reported by running ifconfig
PORT = 12345

SEND_INTERVAL = 2  # send data every 2 minutes

# dummy soil moisture probe data
smp_value = 12345
solar_cell_adc_value = 678
battery_adc_value = 901
esp_rssi = -30
esp_channel = 4

while True:

    # need to wait for correct time to send
    while int(datetime.now().strftime("%M")) % SEND_INTERVAL != 0:
        time.sleep(1.0) # keeps the thread from running at 100%
        no_op = 0

    # Connect to a given ip and port
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((IP, PORT))

    message = '{:s},{:5d},{:4d},{:4d},{:4d},{:4d},'.format(
        datetime.now().strftime("%H:%M:%S"),
        smp_value,
        solar_cell_adc_value,
        battery_adc_value,
        esp_rssi,
        esp_channel)

    message = message+'z'*(BUFFER_SIZE-len(message))

    print(message)
    client_socket.send(message.encode('utf-8'))

    try:
        reply = client_socket.recv(BUFFER_SIZE).decode('utf-8')
        # Print message
        print(f'{reply}')
    except:
        no_op = 0

    # Close connection
    client_socket.close()
    print('connection closed')

    # wait here, until current minute passes
    while int(datetime.now().strftime("%M")) % SEND_INTERVAL == 0:
        time.sleep(1.0)  # keeps the thread from running at 100%
        no_op = 0


# end of file
