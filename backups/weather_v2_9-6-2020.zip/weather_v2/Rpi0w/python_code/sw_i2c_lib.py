'''
Software i2c library
Could not get the Rpi0w hardware i2c to talk to the NHD LCD and the
RTC (via PCA9306 level shift) at same time.

Using GPIO pins to talk to the PIC16F18343 MCU and RTC with software i2c.
Using pull-ups on the Rpi0w.

need a dummy RPi.GPIO for testing on laptop

sleep_test0.py returns 0.0002 on Rpi0w, for dt=1e-5
sleep(1e-5) is really 200us
'''
import RPi.GPIO as GPIO
from time import *

# define the software i2c class
class software_i2c:
    # define functions to physcial pin numbers
    sw_sda = 29 # software i2c sda (yellow wire)
    sw_scl = 31 # software i2c scl (white wire)
    i2c_ack = 0 # ack value returned during write

    def __init__(self):
        # define functions to physcial pin numbers
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(self.sw_sda, GPIO.IN,pull_up_down=GPIO.PUD_UP)
        GPIO.setup(self.sw_scl, GPIO.OUT)  # clock line
        GPIO.output(self.sw_scl, True) # Set clock line high

        # send stop then start and leave lines in correct state
        self.i2c_start()
        self.i2c_stop()

    def read_block_data(self,dev_addr,cmd_byte,num):
        '''
        parameters:
        dev_addr = 7 bit i2c address
        cmd_byte = write 2nd word to device, device dependent
        num = number of bytes to transfer
        '''
        # write device address, then word address or command byte followed by repeated start
        self.i2c_start()
        self.i2c_write(dev_addr << 1)	# device address, leave w/r set to 0
        self.i2c_write(cmd_byte)	# word address or command
        self.i2c_start()	# send start condition

        # read the data from the device
        self.i2c_write((dev_addr << 1) | 0x01)	# set the w/r bit to 1 for read

        # read len-1 bytes of data followed by ACK
        # set SDA pin as input
        GPIO.setup(self.sw_sda, GPIO.IN,pull_up_down=GPIO.PUD_UP)
        sleep(1e-5)

        rvcd_data = []  #empty array for received data
        for i in range(num-1):  # read all but last byte
            input_data = 0x00
            for j in range(8):
                input_data <<= 1   # Shift the byte by one bit
                GPIO.output(self.sw_scl, True) # Set clock line high
                sleep(1e-5)
                input_data |= GPIO.input(self.sw_sda)  # input the data from the I2C Bus
                sleep(1e-5)
                GPIO.output(self.sw_scl, False) # Set clock line low
                sleep(1e-5)
            # send ACK
            GPIO.setup(self.sw_sda, GPIO.OUT)
            GPIO.output(self.sw_sda, False) # send ACK
            sleep(1e-5)
            GPIO.output(self.sw_scl, True) # Set clock line high
            sleep(1e-5)
            GPIO.output(self.sw_scl, False) # Set clock line high
            sleep(1e-5)
            GPIO.setup(self.sw_sda, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            rvcd_data.append(input_data) #save received data

        # now read last byte of data followed by NACK
        input_data = 0x00
        for j in range(8):
            input_data <<= 1   # Shift the byte by one bit
            GPIO.output(self.sw_scl, True) # Set clock line high
            sleep(1e-5)
            input_data |= GPIO.input(self.sw_sda)  # input the data from the I2C Bus
            sleep(1e-5)
            GPIO.output(self.sw_scl, False) # Set clock line low
            sleep(1e-5)

        # send NACK
        GPIO.setup(self.sw_sda, GPIO.OUT)
        GPIO.output(self.sw_sda, True) # send NACK
        sleep(1e-5)
        GPIO.output(self.sw_scl, True) # Set clock line high
        sleep(1e-5)
        GPIO.output(self.sw_scl, False) # Set clock line high
        sleep(1e-5)
        GPIO.setup(self.sw_sda, GPIO.IN, pull_up_down=GPIO.PUD_UP)
        rvcd_data.append(input_data) #save received data

        self.i2c_stop() # create a stop condition
        return(rvcd_data)

    def write_block_data(self,dev_addr,cmd_byte,data):
        '''
        parameters:
        dev_addr = 7 bit i2c address
        cmd_byte = write 2nd word to device, device dependent
        data = array of bytes to transfer, not a string
        '''
        self.i2c_start()
        self.i2c_write(dev_addr << 1)
        self.i2c_write(cmd_byte)
        for i in data:
            self.i2c_write(i)
        self.i2c_stop()

    def i2c_write(self,output_data):
        GPIO.setup(self.sw_sda, GPIO.OUT)
        GPIO.output(self.sw_sda, True) #SDA line is normally pulled high
        sleep(1e-5)

        for j in range(8): # Send 8 bits to the I2C Bus
            GPIO.output(self.sw_sda, True if (output_data & 0x80) else False)
            output_data <<= 1   # Shift the byte by one bit
            GPIO.output(self.sw_scl, True) # Set clock line high
            sleep(1e-5)
            GPIO.output(self.sw_scl, False) # Set clock line low
            sleep(1e-5)

        # get the ACK & save
        GPIO.setup(self.sw_sda, GPIO.IN,pull_up_down=GPIO.PUD_UP) # release pin (open drain output)
        sleep(1e-5)
        GPIO.output(self.sw_scl, True) # Clock the ACK from the I2C Bus
        sleep(1e-5)
        i2c_ack = GPIO.input(self.sw_sda) # get ACK
        GPIO.output(self.sw_scl, False) # Set clock line high
        sleep(1e-5)

    def i2c_read(self):
        # set SDA pin as input
        GPIO.setup(self.sw_sda, GPIO.IN,pull_up_down=GPIO.PUD_UP)
        sleep(1e-5)

        input_data = 0x00
        for j in range(8):
            input_data <<= 1   # Shift the byte by one bit
            GPIO.output(self.sw_scl, True) # Set clock line high
            sleep(1e-5)
            input_data |= GPIO.input(self.sw_sda)  # input the data from the I2C Bus
            sleep(1e-5)
            GPIO.output(self.sw_scl, False) # Set clock line low
            sleep(1e-5)

        # send ACK
        GPIO.setup(self.sw_sda, GPIO.OUT)
        GPIO.output(self.sw_sda, False) # send ACK
        sleep(1e-5)
        GPIO.output(self.sw_scl, True) # Set clock line high
        sleep(1e-5)
        GPIO.output(self.sw_scl, False) # Set clock line high
        sleep(1e-5)
        GPIO.setup(self.sw_sda, GPIO.IN, pull_up_down=GPIO.PUD_UP)
        return input_data


    def i2c_start(self):
        GPIO.setup(self.sw_sda, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # let the pull up control the line
        sleep(1e-5)
        GPIO.output(self.sw_scl, True) # Set clock line high
        sleep(1e-5)
        GPIO.setup(self.sw_sda, GPIO.OUT)
        GPIO.output(self.sw_sda, False) # Set data line low (START SIGNAL)
        sleep(1e-5)
        GPIO.output(self.sw_scl, False) # Set clock line low
        sleep(1e-5)

    def i2c_stop(self):
        GPIO.output(self.sw_scl, False) # Set clock line low
        sleep(1e-5)
        GPIO.setup(self.sw_sda, GPIO.OUT)
        GPIO.output(self.sw_sda, False) # Set data line low (START SIGNAL)
        sleep(1e-5)
        GPIO.output(self.sw_scl, True) # Set clock line high
        sleep(1e-5)
        GPIO.setup(self.sw_sda, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # release the line
        sleep(1e-5)


# end
