"""
Time Out Test 0
Last update: 8/14/2020

Name: time_out_test0.py
Description: Some prototype code to test the main server loop.

The current server code runs in an infinit while loop.  Termination is
with control-c at the console.

This code will loop until data is receive from the stations or
the time out has expired.

Revision History:
weather_station_server_v2.py  runs in infinite loop

weather_station_display0_v1.py
waits for timeout then powers off with help of sleepy_pi    
    

"""
def shut_down():
    GPIO.cleanup() # cleanup all GPIO
    conn.close()
    os.system('sudo shutdown -h now')  

import time

print('Starting up')
print('sleep for 15 sec to allow for services to load')

time.sleep(1)  # 5 for testing later, wait 15 sec for services to load

from datetime import datetime
import os
import socket

# initialize RTC
print('initialize RTC')
print('display RTC read back')
print('verify network time and RTC time, set RTC if necessary')
print('sleep for 5 before clearing LCD')
time.sleep(1)

print('initalize GPIO on Rpi0w')

print('Create a TCP/IP socket')
print('Listening for connections')

HOST = '192.168.1.44' # HP Laptop ip address, reported by running ifconfig
#HOST = '192.168.1.15' # Rpi0w ip address, reported by running ifconfig
PORT = 12345 # just some large number hopefully not in use
BUFFER_SIZE = 64 # data block size

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(2)  # accepts 2 connections
s.settimeout(15) # timeout for listening

print('create csv files for data')

# run the main loop
print('run main loop with time out and cntrl-c termination')

start_time = time.time() # get start time
conn, addr = s.accept()
elapsed_time = time.time() - start_time
print('socket timeout = {:.2d}'.format(elapsed_time))


# NEW CODE
try:
    try: 
        (conn, (ip, port)) = s.accept() 
    except socket.timeout:
        print('socket timed out')
        pass
    else:
        # work with the connection

        # Receive BUFFER_SIZE bytes data
        rx_data = conn.recv(BUFFER_SIZE)
        if rx_data:
            #print received data
            print('data from client: ' , rx_data)

            # check which client is sending data
            if addr[0] == '192.168.1.181':  # weather station data
                server_timestamp_obj = datetime.now()
                GPIO.output(shut_dwn,GPIO.HIGH)  # signal sleepy_pi that connection was made

                # remove unwanted characters from data string
                rx_data = str(rx_data,'utf-8') # convert byte object to string
                rx_data = rx_data.replace(' ','')
                rx_data = rx_data.replace('\x00','')
                rx_data = rx_data.replace('z','')

                # unpack comma seperated values
                rx_data_list = rx_data.split(',')

                client_time_str = rx_data_list[0] # station time string HH:MM:SS
                humidity = int(rx_data_list[1])
                temperture = float(rx_data_list[2])
                barometer = float(rx_data_list[3])
                ALS_PT19_value = int(rx_data_list[4])
                TEPT4400_value = int(rx_data_list[5])
                esp_rssi = int(rx_data_list[6])
                esp_channel = int(rx_data_list[7])

                # store client data to file
                # server_time,clientIP,addrs,station_time,humidity,temperature,barometer,ALS-PT19,TEPT4400,rssi,channel
                f = open('weather_data.csv', 'a')
                # write data to file
                f.write('{:s},{:s},{:d},{:s},{:d},{:.1f},{:.2f},{:d},{:d},{:d},{:d}\r\n'.format(
                        server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S"),
                        addr[0],
                        addr[1],
                        client_time_str,
                        humidity,
                        temperture,
                        barometer,
                        ALS_PT19_value,
                        TEPT4400_value,
                        esp_rssi,
                        esp_channel))
                f.close()

                # send server date and time back to client
                tx_data = datetime.now().strftime("%m/%d/%y,%H:%M:%S")
                tx_data +='z'*(BUFFER_SIZE-len(tx_data))
                conn.send(tx_data.encode())
                GPIO.output(shut_dwn,GPIO.LOW)  # signal sleepy_pi that connection is finished

            elif addr[0] == '192.168.1.44':  # soil moisture probe station
                server_timestamp_obj = datetime.now()
                GPIO.output(shut_dwn,GPIO.HIGH)  # signal sleepy_pi that connection was made

                #unpack comma seperated values, remove spaces
                rx_data_list = str(rx_data,'utf-8').replace(' ','').split(',')

                client_time_str = rx_data_list[0]
                smp_value = int(rx_data_list[1])
                solar_cell_adc_value = int(rx_data_list[2])
                battery_adc_value = int(rx_data_list[3])
                esp_rssi = int(rx_data_list[4])
                esp_channel = int(rx_data_list[5])

                # store client data to file
                f = open('smp_data.csv', 'a')
                # write data to file
                # server_time,clientIP,addrs,station_time,smp_value,solar_cell_adc_value,battery_adc_value,rssi,channel
                f.write('{:s},{:s},{:d},{:s},{:d},{:d},{:d},{:d},{:d}\r\n'.format(
                    server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S"),
                    addr[0],
                    addr[1],
                    client_time_str,
                    smp_value,
                    solar_cell_adc_value,
                    battery_adc_value,
                    esp_rssi,
                    esp_channel))
                f.close()

                # send server date and time back to client
                tx_data = datetime.now().strftime("%m/%d/%y,%H:%M:%S")
                tx_data +='z'*(BUFFER_SIZE-len(tx_data))
                conn.send(tx_data.encode())
                GPIO.output(shut_dwn,GPIO.LOW)  # signal sleepy_pi that connection is finished
 

    print('connection finished')
    #shut_down() # get ready to power off Rpi

except KeyboardInterrupt: # if CTRL+C, exit cleanly
    print('keyboard interrupt')
    #shut_down() # get ready to power off Rpi












#OLD CODE HERE    
    
try:
    while True:
        # Accept the incomming connection
        conn, addr = s.accept()  # waits time value in settimout()
        # Print the info of client
        print ('connected with ' , addr)
        # Receive BUFFER_SIZE bytes data
        rx_data = conn.recv(BUFFER_SIZE)
        if rx_data:
            #print received data
            print('data from client: ' , rx_data)

            # check which client is sending data
            if addr[0] == '192.168.1.181':  # weather station data
                server_timestamp_obj = datetime.now()
                GPIO.output(shut_dwn,GPIO.HIGH)  # signal sleepy_pi that connection was made

                # remove unwanted characters from data string
                rx_data = str(rx_data,'utf-8') # convert byte object to string
                rx_data = rx_data.replace(' ','')
                rx_data = rx_data.replace('\x00','')
                rx_data = rx_data.replace('z','')

                # unpack comma seperated values
                rx_data_list = rx_data.split(',')

                client_time_str = rx_data_list[0] # station time string HH:MM:SS
                humidity = int(rx_data_list[1])
                temperture = float(rx_data_list[2])
                barometer = float(rx_data_list[3])
                ALS_PT19_value = int(rx_data_list[4])
                TEPT4400_value = int(rx_data_list[5])
                esp_rssi = int(rx_data_list[6])
                esp_channel = int(rx_data_list[7])

                # don't need to print
                print('server time: {:s}'.format(server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S")))
                print('client: {:s}, {:d}'.format(addr[0],addr[1]))
                print('client time: {:s}'.format(client_time_str))
                print('humidity: {:d}%'.format(humidity))
                print('temperature: {:.1f}F'.format(temperture))
                print('barometer: {:.2f}inHg'.format(barometer))
                print('ALS-PT19: {:d}'.format(ALS_PT19_value))
                print('TEPT4400: {:d}'.format(TEPT4400_value))
                print('rssi: {:d}'.format(esp_rssi))
                print('channel: {:d}'.format(esp_channel))

                # store client data to file
                # server_time,clientIP,addrs,station_time,humidity,temperature,barometer,ALS-PT19,TEPT4400,rssi,channel
                f = open('weather_data.csv', 'a')
                # write data to file
                f.write('{:s},{:s},{:d},{:s},{:d},{:.1f},{:.2f},{:d},{:d},{:d},{:d}\r\n'.format(
                        server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S"),
                        addr[0],
                        addr[1],
                        client_time_str,
                        humidity,
                        temperture,
                        barometer,
                        ALS_PT19_value,
                        TEPT4400_value,
                        esp_rssi,
                        esp_channel))
                f.close()

                # send server date and time back to client
                tx_data = datetime.now().strftime("%m/%d/%y,%H:%M:%S")
                tx_data +='z'*(BUFFER_SIZE-len(tx_data))
                conn.send(tx_data.encode())
                GPIO.output(shut_dwn,GPIO.LOW)  # signal sleepy_pi that connection is finished

            elif addr[0] == '192.168.1.44':  # soil moisture probe station
                server_timestamp_obj = datetime.now()
                GPIO.output(shut_dwn,GPIO.HIGH)  # signal sleepy_pi that connection was made

                #unpack comma seperated values, remove spaces
                rx_data_list = str(rx_data,'utf-8').replace(' ','').split(',')

                client_time_str = rx_data_list[0]
                smp_value = int(rx_data_list[1])
                solar_cell_adc_value = int(rx_data_list[2])
                battery_adc_value = int(rx_data_list[3])
                esp_rssi = int(rx_data_list[4])
                esp_channel = int(rx_data_list[5])

                print('server time stamp: {:s}'.format(server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S")))
                print('client: {:s}, {:d}'.format(addr[0],addr[1]))
                print('client time: {:s}'.format(client_time_str))
                print('smp_value: {:d}'.format(smp_value))
                print('solar_cell_adc_value: {:d}'.format(solar_cell_adc_value))
                print('battery_adc_value: {:d}'.format(battery_adc_value))
                print('rssi: {:d}'.format(esp_rssi))
                print('channel: {:d}'.format(esp_channel))

                # store client data to file
                f = open('smp_data.csv', 'a')
                # write data to file
                # server_time,clientIP,addrs,station_time,smp_value,solar_cell_adc_value,battery_adc_value,rssi,channel
                f.write('{:s},{:s},{:d},{:s},{:d},{:d},{:d},{:d},{:d}\r\n'.format(
                    server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S"),
                    addr[0],
                    addr[1],
                    client_time_str,
                    smp_value,
                    solar_cell_adc_value,
                    battery_adc_value,
                    esp_rssi,
                    esp_channel))
                f.close()

                # send server date and time back to client
                tx_data = datetime.now().strftime("%m/%d/%y,%H:%M:%S")
                tx_data +='z'*(BUFFER_SIZE-len(tx_data))
                conn.send(tx_data.encode())
                GPIO.output(shut_dwn,GPIO.LOW)  # signal sleepy_pi that connection is finished
            else:
                print('unknown client station')

            # display data on LCD
            lcd.clear()
            # write line 1 on the LCD, something like: @ 12:45 +073.2
            lcd.write('@ {:s} {:.1f}F'.format(client_time_str[0:5],temperture), 1)
            # write 2nd line, something like: 56%RH 29.89in S
            lcd.write('{:d}%RH {:.2f}in'.format(humidity,barometer), 2)

except KeyboardInterrupt: # if CTRL+C, exit cleanly
    print("\n\rexiting")
    time.sleep(2)
    GPIO.cleanup() # cleanup all GPIO
    conn.close()
    print('connection closed')

#end
