'''
We'll use the RPi.GPIO module as the driving force behind our Python
examples. This set of Python files and source is included with Raspbian,
so assuming you're running that most popular Linux distribution, you don't
need to download anything to get started.

Pin Numbering Declaration
After you've included the RPi.GPIO module, the next step is to determine
which of the two pin-numbering schemes you want to use:

GPIO.BOARD -- Board numbering scheme. The pin numbers follow the pin
numbers on header P1.
GPIO.BCM -- Broadcom chip-specific pin numbers. These pin numbers follow
the lower-level numbering system defined by the Raspberry Pi's
Broadcom-chip brain.

Digital Output
To write a pin high or low, use the GPIO.output([pin], [GPIO.LOW, GPIO.HIGH])
function. For example, if you want to set pin 18 high, write:

GPIO.output(18, GPIO.HIGH)
Writing a pin to GPIO.HIGH will drive it to 3.3V, and GPIO.LOW will
set it to 0V. For the lazy, alternative to GPIO.HIGH and GPIO.LOW, you
can use either 1, True, 0 or False to set a pin value.

Inputs
If a pin is configured as an input, you can use the GPIO.input([pin])
function to read its value. The input() function will return either a
True or False indicating whether the pin is HIGH or LOW. You can use
an if statement to test this, for example...

if GPIO.input(17):
    print("Pin 11 is HIGH")
else:
    print("Pin 11 is LOW")
...will read pin 17 and print whether it's being read as HIGH or LOW.

Pull-Up/Down Resistors
Remember back to the GPIO.setup() function where we declared whether a
pin was an input or output? There's an optional third parameter to that
function, which you can use to set pull-up or pull-down resistors. To use
a pull-up resistor on a pin, add pull_up_down=GPIO.PUD_UP as a third
parameter in GPIO.setup. Or, if you need a pull-down resistor, instead
use pull_up_down=GPIO.PUD_DOWN.

For example, to use a pull-up resistor on GPIO 17, write this into your setup:

GPIO.setup(17, GPIO.IN, pull_up_down=GPIO.PUD_UP)
If nothing is declared in that third value, both pull-resistors will be disabled.

Delays
If you need to slow your Python script down, you can add delays.
To incorporate delays into your script, you'll need to include another
module: time. This line, at the top of your script, will do it for you:

include time
Then, throughout the rest of your script, you can use time.sleep([seconds])
to give your script a rest. You can use decimals to precisely set your delay.
For example, to delay 250 milliseconds, write:

time.sleep(0.25)
The time module includes all sorts of useful functions, on top of sleep.
Check out the reference here. https://docs.python.org/3.6/library/time.html

Garbage Collecting
Once your script has run its course, be kind to the next process that
might use your GPIOs by cleaning up after yourself. Use the GPIO.cleanup()
command at the end of your script to release any resources
your script may be using.

Your Pi will survive if you forget to add this command, but it is good
practice to include wherever you can.

code copied from sparkfun
https://learn.sparkfun.com/tutorials/raspberry-gpio/all#python-rpigpio-api


'''


# external module imports
import RPi.GPIO as GPIO
from time import *

# define functions to physcial pin numbers
sw1  = 11 # debug enable switch
shut_dwn = 13 # shut down signal to PIC
sw_sda = 29 # software i2c sda
sw_scl = 31 # software i2c scl

# define functions to physcial pin numbers
GPIO.setmode(GPIO.BOARD) # pin numbers follow the pin numbers on header pi
GPIO.setup(sw1, GPIO.IN)
GPIO.setup(sw_sda, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(sw_scl, GPIO.OUT)  # clock line
GPIO.setup(shut_dwn, GPIO.OUT)
GPIO.output(shut_dwn,False)  # set low to start



print("Running: Press CTRL+C to exit")
try:
    while 1:
        if GPIO.input(sw1): # read the switch
            print('up position')
            GPIO.output(sw_scl, True) # control the i2c clock
            # test of dynamically switching direction on sw_sda line
            GPIO.setup(sw_sda, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            data = GPIO.input(sw_sda) # read i2c data line
            GPIO.output(shut_dwn,True)
        else: # switch is on
            print('down position')
            GPIO.output(sw_scl, False) # control the i2c clock
            # test of dynamically switching direction on sw_sda line
            GPIO.setup(sw_sda, GPIO.OUT)
            GPIO.output(sw_sda, True)
            sleep(0.001)
            GPIO.output(sw_sda, False)
            GPIO.output(shut_dwn,False)
        sleep(1)

except KeyboardInterrupt: # if CTRL+C, exit cleanly
    print("\n\rexiting")
    sleep(2)
    GPIO.cleanup() # cleanup all GPIO

# end
