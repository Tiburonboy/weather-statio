#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 10 07:54:33 2020
@author: jim

sleep_test0.py returns 0.0002 on Rpi0w, for dt=1e-5
sleep(1e-5) is really 200us

"""
from time import *

def testsleep(t):
    s = time()
    sleep(t)
    return time() - s

dt = 1e-5
print('t={:e}'.format(dt))
print(testsleep(dt))
