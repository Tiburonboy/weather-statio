'''
Test RTC update logic

9/3/202: didn't find anything wrong with the logic
still don't know why time got out of sync

'''

net_time_month = 9
net_time_day = 3
net_time_year = 20
net_time_hour = 12
net_time_minute = 15
net_time_second = 4

rtc_month = net_time_month
rtc_day = net_time_day
rtc_year = net_time_year
rtc_hour = net_time_hour
rtc_minute = 12
rtc_second = 59
network_time_valid = 0
update_rtc_flg = 0

if rtc_second > net_time_second:
    sec_dif = rtc_second - net_time_second
else:
    sec_dif = 60-(net_time_second - rtc_second)
if sec_dif > 30:
    sec_dif = 60 - sec_dif;
print(sec_dif)
# sec_dif is unsigned in the PIC C++ code


if (rtc_minute > 55) or (rtc_minute < 5):
    print('minutes between 55 and 05: {:d}'.format(rtc_minute))
    print('need to run exit')
    #exit()
else:
    print('check for time difference')


# check for agrement between weather station time and network time
# should only be seconds error
if net_time_month == rtc_month:
    if net_time_day == rtc_day:
        if net_time_year == rtc_year:
            if net_time_hour == rtc_hour: # min & sec could be diff, just look for correct hours
                network_time_valid = 1 # all but minutes and seconds must agree

                if net_time_second != rtc_second:
                    if rtc_second > net_time_second:
                        sec_dif = (rtc_second - net_time_second);
                    else:
                        sec_dif = 60-(net_time_second - rtc_second);
                    if sec_dif > 30:
                        sec_dif = 60 - sec_dif;
                    if sec_dif > 5:
                        update_rtc_flg = 1;
                        print('set_time_date()')
                        rtc_minute = net_time_minute
                        rtc_second = net_time_second
                    else:
                        update_rtc_flg = 0
            else:
                network_time_valid = 0
                wifi_connect_status = -5 #RX time error
        else:
            network_time_valid = 0
    else:
        network_time_valid = 0
else:
    network_time_valid = 0




if sec_dif > 30:
    sec_dif = 60 - sec_dif;


# end
