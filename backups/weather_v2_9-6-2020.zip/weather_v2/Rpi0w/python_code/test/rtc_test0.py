'''
using software i2c to talk to the RTC and the PIC

'''
import nhd_lcd_lib
import rtc_lib
import sw_i2c_lib
import RPi.GPIO as GPIO
from time import *


# initialize the LCD
lcd = nhd_lcd_lib.nhd_lcd()

lcd.clear()
lcd.write('testing RTC', 1)
lcd.write('line #2', 2)

# initialize software i2c
#sw_i2c = sw_i2c_lib.software_i2c()

# initialize RTC interface
rtc = rtc_lib.DS1307_rtc()

# read the clock
rtc.get_time_date()

print('seconds = {:d}'.format(rtc.second))
print('minute = {:d}'.format(rtc.minute))
print('hour = {:d}'.format(rtc.hour))
print('weekDay = {:d}'.format(rtc.weekDay))
print('monthDay = {:d}'.format(rtc.monthDay))
print('month = {:d}'.format(rtc.month))
print('year = {:d}'.format(rtc.year))

# read shut down pin, using pin# 13 connected to PIC via 500 ohms

sw1 = 11 # sw1, debug enable switch, used to prevent code running poweroff
GPIO.setup(sw1, GPIO.IN)
print('sw1 signal = {:d}'.format(GPIO.input(sw1)))

GPIO.cleanup() # cleanup all GPIO

# end
