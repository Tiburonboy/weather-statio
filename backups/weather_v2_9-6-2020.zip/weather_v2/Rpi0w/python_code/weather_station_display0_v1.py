"""
weather_station_display0_v1
Last update: 8/14/2020

Name: weather_station_display0_v1.py
Description:
This code is for prototype weather station display.
This code will run untill socket times out.

Revision History:

Startup synchronization:
Put battery in about 3 min prior to data scheduled data collection
time seems to work.
During debug mode (sw1 down position), power is kept on, so
need to manually poweroff Rip0w, pull the battery and
re-install 3 min prior to data scheduled data collection.
8/16/2020: change startup wait to 10 sec.  Time&date display
changed to 5 sec wait.  LCD updates changed to keep the previous data
until new data is available.
8/25/2020:  Display looses syncronization if the station fails to connect.
Adding code for timeout exception.
Tested socket.timeout display is blank, don't see 'socket timed out' message.
9/2/2020: 'socket timed out' message only stay for 1 second then LCD goes blank.

"""
def shut_down():
    try:
        log.write('try to close connection\r\n')
        conn.close()
    except:
        print('conn.close exception')  # used for debugging
        log.write('got conn.close exception\r\n')  # used for debugging
        pass

    log.write('set shut_dwn to FALSE\r\n')
    GPIO.output(shut_dwn,False)  # signal sleepy_pi that connection is finished

    if GPIO.input(sw1): # read the switch
        print('sw1 is up, running sudo shutdown')
        log.write('sw1 is up, running sudo shutdown & cleanup GPIO\r\n\n')
        GPIO.cleanup() # cleanup all GPIO
        log.close()
        os.system('sudo shutdown -h now')
    else:
        print('sw1 is down, debug-no shutdown')
        log.write('sw1 is down, debug-no shutdown\r\n')
        GPIO.cleanup() # cleanup all GPIO
        log.close()
        sys.exit(0) # leave the script and return to command prompt

    log.write('got to end of shutdown\r\n')

import sys
import time
#import sw_i2c_lib
import nhd_lcd_lib

from datetime import datetime
import os
import socket
import rtc_lib
import RPi.GPIO as GPIO

# progress log file
os.chdir('/home/pi/') # change to home/pi directory
if os.path.isfile('display0_v1_log.txt') == False:
    # if the file does not exits make it
    f = open('display0_v1_log.txt', 'a')
    f.close()

# open the log file for degugging
log = open('display0_v1_log.txt','a')

lcd_progress_flg = 0 # set to 1 if progress is to be displayed to LCD

if lcd_progress_flg:
    # initialize the LCD
    lcd = nhd_lcd_lib.nhd_lcd()
    lcd.clear()
    lcd.write('Starting up', 1)
    lcd.write('wait 0 sec', 2)

print('Starting up, wait 0 sec')
log.write('Starting up, wait 0 sec\r\n')
#time.sleep(10)  #  wait 10 sec for services to load
# Rpi0w seems to boot faster and 30 sec maybe is too long, try 10.

# initialize RTC
rtc = rtc_lib.DS1307_rtc()
rtc.set_time_date() # keeps RTC in sync with network time
time.sleep(1) # allow RTC time to update
rtc.get_time_date() # read RTC
if lcd_progress_flg:
    lcd.clear()
    lcd.write('{:d}/{:d}/{:d}'.format(rtc.month,rtc.monthDay,rtc.year), 1)
    lcd.write('{:d}:{:d}:{:d}'.format(rtc.hour,rtc.minute,rtc.second), 2)
    time.sleep(5)

print('RTC-{:d}/{:d}/{:d} {:d}:{:d}:{:d}'.format(rtc.month,rtc.monthDay,rtc.year,rtc.hour,rtc.minute,rtc.second))
log.write('RTC- {:02d}/{:02d}/{:02d} {:02d}:{:02d}:{:02d}\r\n'.format(rtc.month,rtc.monthDay,rtc.year,rtc.hour,rtc.minute,rtc.second))
#server_time_obj = datetime.now() # get system time, write to log file
log.write('NWT- {:s}\r\n'.format(datetime.now().strftime("%m/%d/%y, %H:%M:%S")))
log.write('NWT- {:s} 2nd read, because min are 15 behind\r\n'.format(datetime.now().strftime("%m/%d/%y, %H:%M:%S")))

# define functions to physcial pin numbers
#GPIO.setmode(GPIO.BOARD)  # all ready called???
sw1 = 11 # sw1, debug enable switch, used to prevent code running poweroff
shut_dwn = 13 # shut down signal to PIC
GPIO.setup(sw1, GPIO.IN)
GPIO.setup(shut_dwn, GPIO.OUT)
GPIO.output(shut_dwn,False)  # set low to start

#HOST = '192.168.1.44' # HP Laptop ip address, reported by running ifconfig
HOST = '192.168.1.15' # Rpi0w ip address, reported by running ifconfig
PORT = 12345 # just some large number hopefully not in use
BUFFER_SIZE = 64 # data block size

# Create a TCP/IP socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.settimeout(300) # 5 min timeout = 300

print('Listening for connections')
log.write('Listening for connections\r\n')
if lcd_progress_flg:
    lcd.clear()
    lcd.write('Listening for', 1)
    lcd.write('connections', 2)

s.listen(2)  # accepts 2 connections

# add column headings, do only once when file is first created
#os.chdir('/home/jim/Documents/weather_v2/') just creat files in user directory
if os.path.isfile('weather_data.csv') == False:
    # if the file does not exits make it
    f = open('weather_data.csv', 'a')
    f.write('server_time,clientIP,addrs,station_time,humidity,temperature,barometer,ALS-PT19,TEPT4400,rssi,channel,raw_data\r\n')
    f.close()

if os.path.isfile('smp_data.csv') == False:
    # if the file does not exits make it
    f = open('smp_data.csv', 'a')
    f.write('server_time,clientIP,addrs,station_time,smp_value,solar_cell_adc_value,battery_adc_value,rssi,channel\r\n')
    f.close()

# run the main loop
print('runing program with time out and cntrl-c termination')
if GPIO.input(sw1): # read the switch
    print('sw1 is up, running shutdown when finished')
    log.write('sw1 is up, running shutdown when finished\r\n')

start_time = time.time() # get start time
print('socket start time = {:.2f}'.format(start_time))
log.write('socket start time = {:.2f}\r\n'.format(start_time))

# waits 5 min for connection or cntrl-c, then exits
try:
    try:
        conn, addr = s.accept()
    except socket.timeout:
        print('start socket time out exception')
        log.write('start socket time out exception\r\n')
        rtc.get_time_date() # read RTC
        log.write('time out, RTC {:02d}:{:02d}:{:02d}\r\n'.format(rtc.hour,rtc.minute,rtc.second))
        if lcd_progress_flg == 0:
            log.write('initialize the LCD\r\n')
            lcd = nhd_lcd_lib.nhd_lcd() # initialize the LCD
        else:
            log.write('clear LCD\r\n')
            lcd.clear()

        log.write('write socket timed out to LCD & time\r\n')
        lcd.write('socket timed out', 1)
        lcd.write('{:02d}:{:02d}:{:02d}'.format(rtc.hour,rtc.minute,rtc.second), 2)

        # check the debug switch
        if GPIO.input(sw1): # read the switch
            log.write('sw1 is in debug position\r\n')
            GPIO.output(shut_dwn,True)  # signal Rpi_sleepy to power off after timeout
            time.sleep(1) # give PIC time to catch the signal

        log.write('calling shut_down from timeout exception\r\n')
        shut_down() # get ready to power off Rpi
        pass
    else:
        # work with the connection

        # Receive BUFFER_SIZE bytes data
        rx_data = conn.recv(BUFFER_SIZE)
        if rx_data:
            #print received data
            rx_data = str(rx_data,'utf-8') # convert byte object to string
            # remove unwanted characters from data string
            rx_data = rx_data.replace(' ','')
            rx_data = rx_data.replace('\x00','')
            print('data from client: ' , rx_data)
            log.write('data from client: {:s}\r\n'.format(rx_data))
            if GPIO.input(sw1): # read the switch
                GPIO.output(shut_dwn,True)  # signal Rpi_sleepy that connection was made
                time.sleep(1) # give PIC time to catch the signal

            # check which client is sending data
            if addr[0] == '192.168.1.181':  # weather station data
                server_timestamp_obj = datetime.now()

                # unpack comma seperated values
                rx_data_list = rx_data.split(',')

                client_time_str = rx_data_list[0] # station time string HH:MM:SS
                humidity = int(rx_data_list[1])
                temperture = float(rx_data_list[2])
                barometer = float(rx_data_list[3])
                ALS_PT19_value = int(rx_data_list[4])
                TEPT4400_value = int(rx_data_list[5])
                esp_rssi = int(rx_data_list[6])
                esp_channel = int(rx_data_list[7])
                raw_data = rx_data_list[8][1:-2] # extract raw data

                # store client data to file
                # server_time,clientIP,addrs,station_time,humidity,temperature,barometer,ALS-PT19,TEPT4400,rssi,channel
                f = open('weather_data.csv', 'a')
                # write data to file
                f.write('{:s},{:s},{:d},{:s},{:d},{:.1f},{:.2f},{:d},{:d},{:d},{:d},{:s}\r\n'.format(
                        server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S"),
                        addr[0],
                        addr[1],
                        client_time_str,
                        humidity,
                        temperture,
                        barometer,
                        ALS_PT19_value,
                        TEPT4400_value,
                        esp_rssi,
                        esp_channel,raw_data))
                f.close()

                # send server date and time back to client
                tx_data = datetime.now().strftime("%m/%d/%y,%H:%M:%S")
                log.write('time sent to client: {:s}\r\n'.format(tx_data))
                tx_data +='z'*(BUFFER_SIZE-len(tx_data))
                conn.send(tx_data.encode())
                GPIO.output(shut_dwn,False)  # falling shut_dwn signals Rpi_sleepy that connection is finished

            elif addr[0] == '192.168.1.44':  # soil moisture probe station
                server_timestamp_obj = datetime.now()
                #GPIO.output(shut_dwn,True)  # signal sleepy_pi that connection was made

                #unpack comma seperated values, remove spaces
                rx_data_list = str(rx_data,'utf-8').replace(' ','').split(',')

                client_time_str = rx_data_list[0]
                smp_value = int(rx_data_list[1])
                solar_cell_adc_value = int(rx_data_list[2])
                battery_adc_value = int(rx_data_list[3])
                esp_rssi = int(rx_data_list[4])
                esp_channel = int(rx_data_list[5])

                # store client data to file
                f = open('smp_data.csv', 'a')
                # write data to file
                # server_time,clientIP,addrs,station_time,smp_value,solar_cell_adc_value,battery_adc_value,rssi,channel
                f.write('{:s},{:s},{:d},{:s},{:d},{:d},{:d},{:d},{:d}\r\n'.format(
                    server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S"),
                    addr[0],
                    addr[1],
                    client_time_str,
                    smp_value,
                    solar_cell_adc_value,
                    battery_adc_value,
                    esp_rssi,
                    esp_channel))
                f.close()

                # send server date and time back to client
                tx_data = datetime.now().strftime("%m/%d/%y,%H:%M:%S")
                tx_data +='z'*(BUFFER_SIZE-len(tx_data))
                conn.send(tx_data.encode())
                GPIO.output(shut_dwn,False)  # falling shut_dwn signals Rpi_sleepy that connection is finished

    # display data on LCD
    if not lcd_progress_flg: # allows old data to persist on LCD until new data is received
        lcd = nhd_lcd_lib.nhd_lcd() # initialize the LCD
    else:
        lcd.clear()

    # write line 1 on the LCD, something like: @ 12:45 +073.2
    lcd.write('@ {:s} {:.1f}F'.format(client_time_str[0:5],temperture), 1)
    # write 2nd line, something like: 56%RH 29.89in S
    lcd.write('{:d}%RH {:.2f}in'.format(humidity,barometer), 2)

    print('connection finished')
    print('time in socket = {:.3f}'.format(time.time() - start_time))
    log.write('connection finished\r\n')
    log.write('time in socket = {:.3f}\r\n'.format(time.time() - start_time))
    shut_down() # get ready to power off Rpi

except KeyboardInterrupt: # if CTRL+C, exit cleanly
    print('keyboard interrupt')
    log.write('keyboard interrupt\n\r')
    shut_down() # get ready to power off Rpi

#end
