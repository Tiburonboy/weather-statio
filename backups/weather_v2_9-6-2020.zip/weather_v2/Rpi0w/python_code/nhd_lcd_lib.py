'''
library for Newhaven Display LCD
NHD-C0216CiZ-FSW-FBW-3V3
2 Lines x 16 Characters
Side White LED Backlight
3.0V LCD, 3.0V Backlight

Built-in ST7032i-oD with I2C interface
5x8 pixels with cursor
3V power supply
Slave Address = 0x7C 8 bit write address
7 bit i2c address = 0x3e
http://wiki.erazor-zone.de/wiki:linux:python:smbus:doc
'''

import smbus
from time import *

# define the nhd_lcd class
class nhd_lcd():
    Comsend = 0x00 # command word for commands
    Datasend = 0x40 # command word for data
    Line1 = 0x80 # address of 1st character on line 1
    Line2 = 0xC0 # address of 1st character on line 2
    addr = 0x3e # 7 bit address of NHD LCD

    def __init__(self):
        # initialize i2c bus
        self.bus = smbus.SMBus(1)
        sleep(.001)

        # initialize the NHD LCD, the default at power on is display is off
        self.bus.write_byte_data(self.addr,self.Comsend,0x38) # function set, 8 bits, 2 lines, Is=0
        sleep(.001)
        self.bus.write_byte_data(self.addr,self.Comsend,0x39) # function set, 8 bits, 2 lines, Is=1
        sleep(.001)
        self.bus.write_byte_data(self.addr,self.Comsend,0x14) # internal osc, freq 1/4 bias
        self.bus.write_byte_data(self.addr,self.Comsend,0x70) # set contrast, x70 tested OK
        self.bus.write_byte_data(self.addr,self.Comsend,0x5e) # power Ion=1 Bon=1 c5=1, contrast looks OK
        self.bus.write_byte_data(self.addr,self.Comsend,0x6d) # follower control
        self.bus.write_byte_data(self.addr,self.Comsend,0x0c) # display on, c=0, b=0
        self.bus.write_byte_data(self.addr,self.Comsend,0x01) # reset pointer and address back to zero
        self.bus.write_byte_data(self.addr,self.Comsend,0x06)

    def write(self,text, line_num):
        '''
        text = string of text, should not be longer than display length
        line_num = display line = 1 or 2, no out of limit checks are made
        '''
        if line_num == 1:
            self.bus.write_byte_data(self.addr,self.Comsend,self.Line1)
            sleep(.001)
        if line_num == 2:
            self.bus.write_byte_data(self.addr,self.Comsend,self.Line2)
            sleep(.001)

        for k in text:
            self.bus.write_byte_data(self.addr,self.Datasend,ord(k))
            sleep(.001)

    # clear lcd and set cursor to home
    def clear(self):
        self.bus.write_byte_data(self.addr,self.Comsend,0x01)
        sleep(.001)

# end
