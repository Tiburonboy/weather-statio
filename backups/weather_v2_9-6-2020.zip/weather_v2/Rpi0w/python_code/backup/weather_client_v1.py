'''
# Socket Chatroom client - Creating chat application with sockets in Python
# https://pythonprogramming.net/client-chatroom-sockets-tutorial-python-3/

Weather station client simulator
last update: 9 July 2020

make a copy for soil moisture probe smp_client.py

/************************************
*               main                *
************************************/
/*
Name:
Synopsis:
Requires:
Description:
Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/

    // send TX buffer, sample weather station data
    /*
    HTU21D_H;  // humidity 0 to 99
    HTU21D_Twhole;  // whole part of the temperature value
    HTU21D_Tfrac;  // fractional part of the temperature value, need 1 digit
    MPL3115A2_Pwhole;  // usually 29, divide the mPa value by 33.864 to get inHg
    MPL3115A2_Pfrac;   // fractional part, need two digits
    ALS_PT19_value  light sensor raw ADC count, three digits
    */
    clear_esp8266_TxBuf();
    sprintf(esp8266_TxBuf,"%2d,%4d.%1d,%2d.%2d,%3d",HTU21D_H,HTU21D_Twhole,HTU21D_Tfrac,MPL3115A2_Pwhole,MPL3115A2_Pfrac,ALS_PT19_value);
    esp8266_write_TxBuf();
    //retVal = esp8266_GetResponse("ANY", 9000);  // replies OK, could just call this, because it will keep reading until buffer is full

need to send weather station date to server very X min,

message_header = f"{len(message):<{HEADER_LENGTH}}".encode('utf-8')
length:<headerlength

b'4 = f"{len(username):<{HEADER_LENGTH}}".encode('utf-8')

username_header + username
Out[12]: b'4         sta1'

username
Out[13]: b'sta1'

message
Out[17]: '65,  71.4,29.82,1234zzzz'

username_header
Out[18]: b'4         '

username_header + username
Out[19]: b'4         sta

message_header + message
Out[24]: b'24        65,  71.4,29.82,1234zzzz'


message header = length of message, left justified, ten char used.

username_header + username
Out[12]: b'4         sta1'

message_header + message
Out[24]: b'24        65,  71.4,29.82,1234zzzz'


always send 32 byte messages

The esp8266 will always send a fix number of characters, whatever is
specified by n in AT+CIPSEND=n

weather station data is 20 characters long.
change padding to spaces ' '.

in the copied code, the server always reads 10 characters to get the length of message.
Then reads number of characters equal to length.

'''

import socket
#import select
import errno
import time
import sys

HEADER_LENGTH = 10 # why is this 10?

IP = "127.0.0.1"
PORT = 12345
my_username = input("Username: ")

# Create a socket
# socket.AF_INET - address family, IPv4, some otehr possible are AF_INET6, AF_BLUETOOTH, AF_UNIX
# socket.SOCK_STREAM - TCP, conection-based, socket.SOCK_DGRAM - UDP, connectionless, datagrams, socket.SOCK_RAW - raw IP packets
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to a given ip and port
client_socket.connect((IP, PORT))

# Set connection to non-blocking state, so .recv() call won;t block, just return some exception we'll handle
client_socket.setblocking(False)

# Prepare username and header and send them
# We need to encode username to bytes, then count number of bytes and prepare header of fixed size, that we encode to bytes as well
username = my_username.encode('utf-8')
username_header = f"{len(username):<{HEADER_LENGTH}}".encode('utf-8')
client_socket.send(username_header + username)

send_data_flg_s = 1
send_data_flg_r = 0

# weather station data
HTU21D_H = 65   # humidity 0 to 99
HTU21D_Twhole = -100 # whole part of the temperature value
HTU21D_Tfrac = 4  # fractional part of the temperature value, need 1 digit
MPL3115A2_Pwhole = 29  # usually 29, divide the mPa value by 33.864 to get inHg
MPL3115A2_Pfrac = 82  # fractional part, need two digits
ALS_PT19_value = 1234 #  light sensor raw ADC count, 4 digits

while True:

    # need to wait for correct time to send
    while (int(time.strftime("%M")) % 2 != 0):
        no_op = 0

        # need to add date and time
        #sprintf(esp8266_TxBuf,"%2d/%2d/%2d,%02d:%02d:%02d,%2d,%4d.%1d,%2d.%2d,%4d", \
        # month,monthDay,year,hour,minute,second,HTU21D_H,HTU21D_Twhole, \
        # HTU21D_Tfrac,MPL3115A2_Pwhole,MPL3115A2_Pfrac,ALS_PT19_value);
    message = '{:2d},{:4d}.{:1d},{:2d}.{:2d},{:4d}'.format(HTU21D_H,HTU21D_Twhole,HTU21D_Tfrac,MPL3115A2_Pwhole,MPL3115A2_Pfrac,ALS_PT19_value)
    message = message+'z'*(45-len(message))


    print(message)
    message = message.encode('utf-8')
    message_header = f"{len(message):<{HEADER_LENGTH}}".encode('utf-8')
    client_socket.send(message_header + message)

    # Wait for user to input a message
    #message = input(f'{my_username} > ')

    try:
        reply = client_socket.recv(2).decode('utf-8')
        # Print message
        print(f'{reply}')
    except:
        no_op = 0

    # wait here
    while int(time.strftime("%M")) % 2 == 0:
        no_op = 0

'''


    # If message is not empty - send it
    if message:

        # Encode message to bytes, prepare header and convert to bytes, like for username above, then send
        message = message.encode('utf-8')
        message_header = f"{len(message):<{HEADER_LENGTH}}".encode('utf-8')
        client_socket.send(message_header + message)

    try:
        # Now we want to loop over received messages (there might be more than one) and print them
        while True:

            # Receive our "header" containing username length, it's size is defined and constant
            username_header = client_socket.recv(HEADER_LENGTH)

            # If we received no data, server gracefully closed a connection, for example using socket.close() or socket.shutdown(socket.SHUT_RDWR)
            if not len(username_header):
                print('Connection closed by the server')
                sys.exit()

            # Convert header to int value
            username_length = int(username_header.decode('utf-8').strip())

            # Receive and decode username
            username = client_socket.recv(username_length).decode('utf-8')

            # Now do the same for message (as we received username, we received whole message, there's no need to check if it has any length)
            message_header = client_socket.recv(HEADER_LENGTH)
            message_length = int(message_header.decode('utf-8').strip())
            message = client_socket.recv(message_length).decode('utf-8')

            # Print message
            print(f'{username} > {message}')

    except IOError as e:
        # This is normal on non blocking connections - when there are no incoming data error is going to be raised
        # Some operating systems will indicate that using AGAIN, and some using WOULDBLOCK error code
        # We are going to check for both - if one of them - that's expected, means no incoming data, continue as normal
        # If we got different error code - something happened
        if e.errno != errno.EAGAIN and e.errno != errno.EWOULDBLOCK:
            print('Reading error: {}'.format(str(e)))
            sys.exit()

        # We just did not receive anything
        continue

    except Exception as e:
        # Any other exception - something happened, exit
        print('Reading error: '.format(str(e)))
        sys.exit()
'''
