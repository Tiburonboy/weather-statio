"""
Weather Station Server V2
Created on Wed Jul  1 06:55:12 2020
Last update: 7/22/2020

Name: weather_station_server_v2.py
Synopsis: Python program to communicate with the weather station.
Requires: python 3
Description: This program will connect to my WiFi sensors, listed below.
Data collected will be displayed on a 2x16 LCD display and later on an epaper
display.

For development, the display will be on the laptop, then on the
LCD display and finally on the epaper display.

Code development is on the
laptop, then it will migrate to the target, Raspberry Pi Zero W (RPi0W).

Use python TKinter to emulate the LCD and epaper displays.

Raspberry Pi Zero W (RPi0W), running linux and python
802.11 b/g/n wireless LAN
1GHz, single-core CPU
512MB RAM

WiFi sensors:
weather station
soil moisture probe
drip timer
others?:  WWVB receiver, see project blog for ideas

Author: Tony Cirineo

Revision History:
program modified online tutorials

Version 2 updates
Add real time values to down load data packet
format uplink data and save file

include some code for soil moisture probe simulator

on esp8266 use AT+CWJAP_CUR? to get rssi and report back
how do you get other end's rssi?

Need to keep running if WiFi is down and for other exceptions.

8/6/2020: code copied to Rpi0w and runs OK, adding LCD display of data
8/13/2020: adding RTC, GPIO to code, shut down not implemented

"""
import time
import sw_i2c_lib
import nhd_lcd_lib

# initialize the LCD
lcd = nhd_lcd_lib.nhd_lcd()

lcd.clear()
lcd.write('Starting up', 1)
lcd.write('wait 15', 2)

time.sleep(5)  # 5 for testing later, wait 15 sec for services to load

from datetime import datetime
import os
import socket
import rtc_lib
import RPi.GPIO as GPIO

# initialize RTC
rtc = rtc_lib.DS1307_rtc()
rtc.set_time_date() # keeps RTC in sync with network time
rtc.get_time_date() # read RTC
lcd.clear()
lcd.write('{:d}/{:d}/{:d}'.format(rtc.month,rtc.month,rtc.year), 1)
lcd.write('{:d}:{:d}:{:d}'.format(rtc.hour,rtc.minute,rtc.second), 2)
time.sleep(5)

shut_dwn = 13 # signal to sleepy_pi
GPIO.setup(shut_dwn, GPIO.OUT)
GPIO.output(shut_dwn,GPIO.LOW)

#HOST = '192.168.1.44' # HP Laptop ip address, reported by running ifconfig
HOST = '192.168.1.15' # Rpi0w ip address, reported by running ifconfig
PORT = 12345 # just some large number hopefully not in use
BUFFER_SIZE = 64 # data block size


# Create a TCP/IP socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Bind the socket to the host and port
s.bind((HOST, PORT))
print('Listening for connections')
lcd.clear()
lcd.write('Listening for', 1)
lcd.write('connections', 2)

s.listen(2)  # accepts 2 connections

# add column headings, do only once when file is first created
#os.chdir('/home/jim/Documents/weather_v2/') just creat files in suer directory
if os.path.isfile('weather_data.csv') == False:
    # if the file does not exits make it
    f = open('weather_data.csv', 'a')
    f.write('server_time,clientIP,addrs,station_time,humidity,temperature,barometer,ALS-PT19,TEPT4400,rssi,channel\r\n')
    f.close()

if os.path.isfile('smp_data.csv') == False:
    # if the file does not exits make it
    f = open('smp_data.csv', 'a')
    f.write('server_time,clientIP,addrs,station_time,smp_value,solar_cell_adc_value,battery_adc_value,rssi,channel\r\n')
    f.close()

# run the main loop
try:
    while True:
        # Accept the incomming connection
        conn, addr = s.accept()
        # Print the info of client
        print ('connected with ' , addr)
        # Receive BUFFER_SIZE bytes data
        rx_data = conn.recv(BUFFER_SIZE)
        if rx_data:
            #print received data
            print('data from client: ' , rx_data)

            # check which client is sending data
            if addr[0] == '192.168.1.181':  # weather station data
                server_timestamp_obj = datetime.now()
                GPIO.output(shut_dwn,GPIO.HIGH)  # signal sleepy_pi that connection was made

                # remove unwanted characters from data string
                rx_data = str(rx_data,'utf-8') # convert byte object to string
                rx_data = rx_data.replace(' ','')
                rx_data = rx_data.replace('\x00','')
                rx_data = rx_data.replace('z','')

                # unpack comma seperated values
                rx_data_list = rx_data.split(',')

                client_time_str = rx_data_list[0] # station time string HH:MM:SS
                humidity = int(rx_data_list[1])
                temperture = float(rx_data_list[2])
                barometer = float(rx_data_list[3])
                ALS_PT19_value = int(rx_data_list[4])
                TEPT4400_value = int(rx_data_list[5])
                esp_rssi = int(rx_data_list[6])
                esp_channel = int(rx_data_list[7])

                print('server time: {:s}'.format(server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S")))
                print('client: {:s}, {:d}'.format(addr[0],addr[1]))
                print('client time: {:s}'.format(client_time_str))
                print('humidity: {:d}%'.format(humidity))
                print('temperature: {:.1f}F'.format(temperture))
                print('barometer: {:.2f}inHg'.format(barometer))
                print('ALS-PT19: {:d}'.format(ALS_PT19_value))
                print('TEPT4400: {:d}'.format(TEPT4400_value))
                print('rssi: {:d}'.format(esp_rssi))
                print('channel: {:d}'.format(esp_channel))

                # store client data to file
                # server_time,clientIP,addrs,station_time,humidity,temperature,barometer,ALS-PT19,TEPT4400,rssi,channel
                f = open('weather_data.csv', 'a')
                # write data to file
                f.write('{:s},{:s},{:d},{:s},{:d},{:.1f},{:.2f},{:d},{:d},{:d},{:d}\r\n'.format(
                        server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S"),
                        addr[0],
                        addr[1],
                        client_time_str,
                        humidity,
                        temperture,
                        barometer,
                        ALS_PT19_value,
                        TEPT4400_value,
                        esp_rssi,
                        esp_channel))
                f.close()

                # send server date and time back to client
                tx_data = datetime.now().strftime("%m/%d/%y,%H:%M:%S")
                tx_data +='z'*(BUFFER_SIZE-len(tx_data))
                conn.send(tx_data.encode())
                GPIO.output(shut_dwn,GPIO.LOW)  # signal sleepy_pi that connection is finished

            elif addr[0] == '192.168.1.44':  # soil moisture probe station
                server_timestamp_obj = datetime.now()
                GPIO.output(shut_dwn,GPIO.HIGH)  # signal sleepy_pi that connection was made

                #unpack comma seperated values, remove spaces
                rx_data_list = str(rx_data,'utf-8').replace(' ','').split(',')

                client_time_str = rx_data_list[0]
                smp_value = int(rx_data_list[1])
                solar_cell_adc_value = int(rx_data_list[2])
                battery_adc_value = int(rx_data_list[3])
                esp_rssi = int(rx_data_list[4])
                esp_channel = int(rx_data_list[5])

                print('server time stamp: {:s}'.format(server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S")))
                print('client: {:s}, {:d}'.format(addr[0],addr[1]))
                print('client time: {:s}'.format(client_time_str))
                print('smp_value: {:d}'.format(smp_value))
                print('solar_cell_adc_value: {:d}'.format(solar_cell_adc_value))
                print('battery_adc_value: {:d}'.format(battery_adc_value))
                print('rssi: {:d}'.format(esp_rssi))
                print('channel: {:d}'.format(esp_channel))

                # store client data to file
                f = open('smp_data.csv', 'a')
                # write data to file
                # server_time,clientIP,addrs,station_time,smp_value,solar_cell_adc_value,battery_adc_value,rssi,channel
                f.write('{:s},{:s},{:d},{:s},{:d},{:d},{:d},{:d},{:d}\r\n'.format(
                    server_timestamp_obj.strftime("%m/%d/%Y %H:%M:%S"),
                    addr[0],
                    addr[1],
                    client_time_str,
                    smp_value,
                    solar_cell_adc_value,
                    battery_adc_value,
                    esp_rssi,
                    esp_channel))
                f.close()

                # send server date and time back to client
                tx_data = datetime.now().strftime("%m/%d/%y,%H:%M:%S")
                tx_data +='z'*(BUFFER_SIZE-len(tx_data))
                conn.send(tx_data.encode())
                GPIO.output(shut_dwn,GPIO.LOW)  # signal sleepy_pi that connection is finished
            else:
                print('unknown client station')

            # display data on LCD
            lcd.clear()
            # write line 1 on the LCD, something like: @ 12:45 +073.2
            lcd.write('@ {:s} {:.1f}F'.format(client_time_str[0:5],temperture), 1)
            # write 2nd line, something like: 56%RH 29.89in S
            lcd.write('{:d}%RH {:.2f}in'.format(humidity,barometer), 2)

except KeyboardInterrupt: # if CTRL+C, exit cleanly
    print("\n\rexiting")
    time.sleep(2)
    GPIO.cleanup() # cleanup all GPIO
    conn.close()
    print('connection closed')

#end
