'''
NHD LCD Test code

Liquid Crystal Display Module
NHD-C0216CiZ-FSW-FBW-3V3
Newhaven Display
2 Lines x 16 Characters
Transflective
Side White LED Backlight
3.0V LCD, 3.0V Backlight

Functions and Features
2 lines x 16 characters
Built-in ST7032i-oD with I2C interface
5x8 pixels with cursor
3V power supply
Slave Address = 0x7C 8 bit write address
0x3e is the 7 bit i2c address


from data sheet
Built-in ST7032i-0D controller.

const char Slave = 0x7C;
const char Comsend = 0x00;
const char Datasend = 0x40;
const char Line2 = 0xC0;

int main(void)
{
P1 = 0;
P3 = 0;
while(1) 								//continue
{
	init_LCD();
	delay(2);
	Show(text1);
	nextline();
	Show(text2);
	delay(2500);

   	init_LCD();
	Show(text3);//first 16chars in font table(should show CGRAM chars two times)
	nextline();
	Show(text4);
	delay(3000);
}
}

void Show(unsigned char *text)
{
	int n, d;
	d=0x00;
	I2C_Start();
	I2C_out(Slave); // Slave = 0x7C
	I2C_out(Datasend); // Datasend = 0x40
	for(n=0;n<16;n++){
		I2C_out(*text);
		++text;
		}
	I2C_Stop();
}
/*****************************************************/
void nextline(void)
{
	I2C_Start();
	I2C_out(Slave);
	I2C_out(Comsend); // Comsend = 0x00
	I2C_out(Line2); // Line2 = 0xC0
	I2C_Stop();
}

SMD doc - just a table
http://wiki.erazor-zone.de/wiki:linux:python:smbus:doc

'''
import smbus
from time import *

Comsend = 0x00
Datasend = 0x40

i2c_ch = 1

# NHD LCD address on the I2C bus
nhd_lcd_i2c_address = 0x3e # 7 bit address

text1 = 'NEWHAVEN Display'
text2 = 'Hello world 1'
Line1 = 0x80
Line2 = 0xC0

# Initialize I2C (SMBus)
bus = smbus.SMBus(i2c_ch)

# try sending some commands
'''
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x01) # clear display
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x02) # return home
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x04) # entry mode
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x0F) # display ON and more

bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x38) # function set
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x80) # set DDRAM address
'''
# the following works
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x38) # function set, 8 bits, 2 lines, Is=0
sleep(.001)
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x39) # function set, 8 bits, 2 lines, Is=1
sleep(.001)
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x14) # internal osc, freq 1/4 bias
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x70) # set contrast, was 78
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x5e) # power Ion=1 Bon=1 c5=1, contrast looks OK
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x6d) # follower control
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x0c) # display on, c=0, b=0
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x01)
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,0x06)


# write some text
for k in text1:
	bus.write_byte_data(nhd_lcd_i2c_address,Datasend,ord(k))
	sleep(.0001)

# next line
bus.write_byte_data(nhd_lcd_i2c_address,Comsend,Line2)

# write some text
for k in text2:
	bus.write_byte_data(nhd_lcd_i2c_address,Datasend,ord(k))
	sleep(.0001)


'''
# the following was copied from
# https://learn.sparkfun.com/tutorials/python-programming-tutorial-getting-started-with-the-raspberry-pi/experiment-4-i2c-temperature-sensor
# using as a template

i2c_ch = 1

# TMP102 address on the I2C bus
i2c_address = 0x48

# Register addresses
reg_temp = 0x00
reg_config = 0x01

# Calculate the 2's complement of a number
def twos_comp(val, bits):
    if (val & (1 << (bits - 1))) != 0:
        val = val - (1 << bits)
    return val

# Read temperature registers and calculate Celsius
def read_temp():

    # Read temperature registers
    val = bus.read_i2c_block_data(i2c_address, reg_temp, 2)
    # NOTE: val[0] = MSB byte 1, val [1] = LSB byte 2
    #print ("!shifted val[0] = ", bin(val[0]), "val[1] = ", bin(val[1]))

    temp_c = (val[0] << 4) | (val[1] >> 4)
    #print (" shifted val[0] = ", bin(val[0] << 4), "val[1] = ", bin(val[1] >> 4))
    #print (bin(temp_c))

    # Convert to 2s complement (temperatures can be negative)
    temp_c = twos_comp(temp_c, 12)

    # Convert registers value to temperature (C)
    temp_c = temp_c * 0.0625

    return temp_c

# Initialize I2C (SMBus)
bus = smbus.SMBus(i2c_ch)

# Read the CONFIG register (2 bytes)
val = bus.read_i2c_block_data(i2c_address, reg_config, 2)
print("Old CONFIG:", val)

# Set to 4 Hz sampling (CR1, CR0 = 0b10)
val[1] = val[1] & 0b00111111
val[1] = val[1] | (0b10 << 6)

# Write 4 Hz sampling back to CONFIG
bus.write_i2c_block_data(i2c_address, reg_config, val)

# Read CONFIG to verify that we changed it
val = bus.read_i2c_block_data(i2c_address, reg_config, 2)
print("New CONFIG:", val)

# Print out temperature every second
while True:
    temperature = read_temp()
    print(round(temperature, 2), "C")
    time.sleep(1)
'''
