# scratch pad code fragments

display.lcd_display_string("Greetings Human!", 1)


# put string function
def lcd_display_string(self, string, line):
  if line == 1:
     self.lcd_write(0x80)
  if line == 2:
     self.lcd_write(0xC0)
  if line == 3:
     self.lcd_write(0x94)
  if line == 4:
     self.lcd_write(0xD4)

  for char in string:
     self.lcd_write(ord(char), Rs) //Rs = 0b00000001 # Register select bit


# write a command to lcd
def lcd_write(self, cmd, mode=0):
  self.lcd_write_four_bits(mode | (cmd & 0xF0))
  self.lcd_write_four_bits(mode | ((cmd << 4) & 0xF0))


def lcd_write_four_bits(self, data):
  self.lcd_device.write_cmd(data | LCD_BACKLIGHT)
  self.lcd_strobe(data)


# Write a single command
def write_cmd(self, cmd):
  self.bus.write_byte(self.addr, cmd)
  sleep(0.0001)


# clocks EN to latch command
def lcd_strobe(self, data):
  self.lcd_device.write_cmd(data | En | LCD_BACKLIGHT)
  sleep(.0005)
  self.lcd_device.write_cmd(((data & ~En) | LCD_BACKLIGHT))
  sleep(.0001)


SMB.write_byte(addr,val)

Write Byte transaction.	int addr,char val	long
