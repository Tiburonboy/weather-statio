// weather v2
/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.0
        Device            :  PIC16F18857
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/
/*
weather_v2
7/7/2020: copied from Si5153_test

 * weather station version 1 was based on Ardunio Uno from Sparkfun.
 * This weather staion uses a PIC16F18875 MCU as the controller.
 *
CRC and FVR module removed with MCC
MCC used setup the ESUART, 16 char FIFO, did debugging with 32 byte FIFO.

DS1307: 0x68 = 7 bit address
LCD: 0x2e = 7 bit address, 0x5c = 8 bit write address
HTDU21D: 0x40 = 7 bit address, 0x80 = 8 bit write address
MPL3115A2: 0x60 = 7 bit address, 0xC0 = 8 bit write address

EUSART:
5/30/2020:  Letting MCC generate code for buffer and interrupts.

DS1307 has 56-byte, battery-backed, nonvolatile (NV) RAM for data storage
of any use ???

*/

#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include <string.h>
#include <stdio.h>

#include "i2c.h"
#include "rtc.h"
#include "HTU21D.h"
#include "MPL3115A2.h"
#include "esp8266.h"
#include "LCD0821.h"

void display_all_sensors(void);

//defines
//#define LOW 0
//#define HIGH 1
//#define TRUE 1
//#define FALSE 0

//#define LCD_ADDRESS 0x2e

// variables
//uint16_t millis;
uint16_t ml_tmr; // main loop timer, 1ms increment by TMR0
uint16_t to_tmr; // time out timer, 1ms increment by TMR0
bit LED_flg;
extern bit i2c_ack;
//uint8_t temp;
//uint16_t temp16;

int8_t retVal;  // returned value from varius functions.

//uint8_t lcd_line1[10];
//uint8_t lcd_line2[10];

uint8_t HTU21D_h;  // humidity 0 to 99, 2 digits
int8_t HTU21D_Twhole;  // whole part of the temperature value degress F, 3 digits +/-128
uint8_t HTU21D_Tfrac;  // fractional part of the temperature value, 1 digit, 0 to 9
uint8_t MPL3115A2_Pwhole;  // usually 29, divide the mPa value by 33.864 to get inHg, 2digits
uint8_t MPL3115A2_Pfrac;   // fractional part, two digits
uint8_t get_sensor_data_flg;  // used to signal time to read sensors then toggled off
uint8_t raw_data[10];  // raw sensor data

// light sensors
uint16_t ALS_PT19_value; // ALS-PT19 ambient light sensor on the weather shield
uint16_t TEPT4400_value; //TEPT4400 external ambient light sensor

// WiFi radio info reported by esp8266
int8_t esp_rssi;  // rssi value from AT+CWJAP_CUR?, usually -59
uint8_t esp_channel;  // channel value from AT+CWJAP_CUR?, usually 4

//uint16_t Tvalue;
//float Cvalue;

uint8_t update_rtc_flg;  // true if RTC update is needed
uint8_t r_flg, s_flg;  // used to keep track of the phase of the SQW 1Hz signal
uint16_t sec_cnt;
//uint8_t new_minute;

extern uint8_t wifi_connect_flg;  // used to flag if time to connect, then toggled off
extern int8_t wifi_connect_status;  // used to signal WiFi connect status

/*
esp8266/WiFi status, two digits on LCD display
0 = esp8266 not present
1 = esp8266 test OK
2 = WiFi Tx/Rx OK
3 =  RTC was updated

-1 = wakeup test fail
-2 = can't connect to network
-3 = can't connect as client
-4 = RX data error
-5 = RX time error
*/

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();


    LED_flg = i2c_ack = 0;
    BLU_LED_SetLow(); // turn off LED
    GRN_LED_SetLow(); // turn off LED

    // esp8266 reset pin
    ESP_RESET_SetDigitalInput();  //causes pin to be Hi Z
    ESP_RESET_SetLow(); // this pin is an open drain pin, set the default value
    // to low.  Pin state is controlled by changing from input to output.

    //I2C initialization
    // set the SDA line low and use TRIS to control the state
    SDA_SetLow();
    SDA_SetDigitalInput();  //SDA is Hi Z

    // set the SCL line as an output
    SCL_SetDigitalOutput();
    SCL_SetHigh();

    // Create a start condition followed by a stop condition
    i2c_start();
    i2c_stop();

    // init devices
    delay_1sec();
    LCD_backlight(1);  // turn on LCD back light
    clear_LCD();
    printf("start");     // power up message
    get_time_date();
    set_LCD_cursor(1,2);
    printf("%02d:%02d:%02d",hour,minute,second);    
    esp8266_init(); // put esp8266 into known state
    init_MPL3115A2();
    HTU21D_setResolution(0);
    delay_1sec();
  
    // set real time clock
    //update_rtc_flg = 0;  // forces manual setting of RTC
    //set_time_date();  // need to comment out if not setting clock

    // read sensors once after power up
    HTU21D_readHumidity();
    HTU21D_readTemperature();
    MPL3115A2_readPressure();
    MPL3115A2_readTemp();
    ALS_PT19_value = ADCC_GetSingleConversion(ALS_PT19);
    TEPT4400_value = ADCC_GetSingleConversion(TEPT4400);
    get_time_date();
    display_all_sensors();

    wifi_connect_flg = 1; // set flag for 1st tim thru main loop

    /*
  control LCD back light
  open socket and send data every 2 min for test 15 min for deployment
  read sensors every 5 min
  call LCD display loop
  */
    while (1)
    {
        // Add your application code
        // check for a new 1Hz rising edge
        if(SQW_GetValue() && !s_flg)
            r_flg = 1;
        if(!SQW_GetValue() && !r_flg)
            s_flg = 0;

        if(r_flg){
            sec_cnt++;
            ml_tmr = 0;  // used to turnoff the LED 50 ms later
            LED_flg = 1;
            GRN_LED_SetHigh();
            s_flg = 1;
            r_flg = 0;

            // Display all sensor data, rotate through pages
            //display_all_sensors();
            if(sec_cnt > 59){
                get_time_date();
                sec_cnt = second;
            }

            // control LCD backlight
             if(ALS_PT19_value > 5)
                LCD_backlight(0);  // turn off LCD back light
             else
                LCD_backlight(1);  // turn on LCD back light
        }

        // every 2 minutes read sensors
        // this is done to prevent sensors from self heating from constant access
         if((minute%2 == 0) && get_sensor_data_flg){
            HTU21D_readTemperature();
            MPL3115A2_readPressure();
            HTU21D_readHumidity();
            ALS_PT19_value = ADCC_GetSingleConversion(ALS_PT19);
            TEPT4400_value = ADCC_GetSingleConversion(TEPT4400);
            get_sensor_data_flg = 0;
            display_all_sensors();
         }
        if(!(minute%2 == 0))
             get_sensor_data_flg = 1; // set flag for next time

       // connect to the newtork if time
       // for debugging connect every 2 min otherwise every 15 min
       if((minute%15 == 0) && wifi_connect_flg){
         // get fresh sensor data
         HTU21D_readTemperature();
         MPL3115A2_readPressure();
         HTU21D_readHumidity();
         MPL3115A2_readTemp();
         ALS_PT19_value = ADCC_GetSingleConversion(ALS_PT19);
         TEPT4400_value = ADCC_GetSingleConversion(TEPT4400);
         get_time_date();  // save time sensors were read
           connect2network();            // wake up esp8266 and connectto server
           wifi_connect_flg = 0;
       }
      if(!(minute%15 == 0))
           wifi_connect_flg = 1; // set flag for next time

        // control if on, turn off after 50 ms
        if((ml_tmr > 50) && LED_flg){
            GRN_LED_SetLow();
            LED_flg = 0;
        }

    }
}

/************************************
*        display_all_sensors        *
************************************/
/*
Name:
Synopsis:
Display sensor data on LCD.
Requires:
Description:
Author: Tony Cirineo
Date:  8/5/03
Revision History:
7/7/2020 removing sensors not included in weather station
*/
void display_all_sensors(void)
{
#if 1
    clear_LCD();
    printf("%2d %3d.%1d",HTU21D_h,HTU21D_Twhole,HTU21D_Tfrac);
    set_LCD_cursor(1,2);
    printf("%2d.%2d %2d", MPL3115A2_Pwhole,MPL3115A2_Pfrac,wifi_connect_status);
#else
    switch(sec_cnt){
        case 2:
            // page 1: display time
            clear_LCD();
            get_time_date();
            printf("%02d:%02d:%02d",hour,minute,second);
            set_LCD_cursor(1, 2);
            //printf("%2d/%2d/%2d",month,monthDay,year);
            printf("Lux:%d",ALS_PT19_value);  // this is used for debugging since Baro sensor is sensitive to light
            break;
        case 4:
            // page 2: display HTU21D humidity in %RH and temperature in F
            // display MPL3115A2 barometric pressure in inHg
            // sensors data read every 5 minutes and stored values displayed here.
            clear_LCD();
            printf("%2d %3d.%1d",HTU21D_h,HTU21D_Twhole,HTU21D_Tfrac);
            set_LCD_cursor(1,2);
            printf("%2d.%2d", MPL3115A2_Pwhole,MPL3115A2_Pfrac);
            printf(" %2d",wifi_connect_status);  // display last WiFi connect status
            break;
        case 8:
            sec_cnt = 0;
            break;
    }
#endif
}


/*
 End of File
*/
