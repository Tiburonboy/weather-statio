/************************************
*           HTU21D.c                *
************************************/
/*
Name: HTU21D.c
Synopsis: functions to read and control the HTU21D humidity sensor.
Requires: Sparkfun weather shield
Description:

The HTU21D-F Temperature & Humidity Sensor is an accurate and intelligent
sensor with a typical accuracy of ±2%. The HTU21D-F has an operating range
that's optimized from 5% to 95% RH. Operation outside this range
is possible with less accuracy. The temperature output has an accuracy
of ±1°C from -30~90°C.

HTU21D(F) relative humidity sensor provide digital outputs
for humidity and temperature.
Supply Voltage (Peak)(V): 3.8
Current Consumption(mA): .014
Humidity Operating Range(%RH): 0 – 100
Operating Temperature Range(°C): -40 – 125, -40 – 125

Revision History:
Some of this code was a rewrite from Sparkfun library code base.

*/
#include "mcc_generated_files/mcc.h"
//#include <string.h>
//#include <stdio.h>
#include <math.h>
#include "i2c.h"
#include "HTU21D.h"

// shifted 7-bit I2C address for the sensor
#define HTDU21D_ADDRESS 0x80
#define TRIGGER_TEMP_MEASURE_HOLD  0xE3
#define TRIGGER_HUMD_MEASURE_HOLD  0xE5
#define TRIGGER_TEMP_MEASURE_NOHOLD  0xF3
#define TRIGGER_HUMD_MEASURE_NOHOLD  0xF5
#define WRITE_USER_REG  0xE6
#define READ_USER_REG  0xE7
#define SOFT_RESET  0xFE

// debugging CRC
//extern uint8_t crc_check_data[3];
//extern uint16_t crcVal;

extern uint16_t millis;
extern bit i2c_ack;
//extern uint8_t HTU21D_h;  // humidity 0 to 99, 2 digits

uint8_t HTU21D_check_crc(uint16_t message_from_sensor, uint8_t check_value_from_sensor);
void read_HTU21D(uint8_t cmd, uint8_t *ptr, uint8_t len);

/************************************
*       read HTU21D                 *
************************************/
/*
Name: data read HTU21D
Synopsis: writes command to sensor, then reads back data
Description:
cmd: command to send to the sensor
*ptr: pointer to list of data
len: length of data list to send
Revision History:
*/
void read_HTU21D(uint8_t cmd, uint8_t *ptr, uint8_t len)
{
//uint8_t i2c_addrs;
uint8_t i,j,input_data;

		// write device address, then word address followed by repeated start
		i2c_start();	// send start condition
		i2c_write(HTDU21D_ADDRESS);	// device address, leave w/r set to 0
		i2c_write(cmd);	// command
		//i2c_start();	// send start condition

		// delay until HTU21D is finished, fixed delay or wait for ACK
    // read the data from the device
		//dev_addrs |= 0x01;      //set the w/r bit to 1 for read
		i2c_ack = 1;  // device will set ack low when it's ready
		while(i2c_ack){
				delay_25ms();    // 50 ms for 14 bit humidity resolution
				i2c_start();	// send start condition
				i2c_write(HTDU21D_ADDRESS | 0x01);	// device address, set w/r to 1
		}  // this can loop forever
		// need to fix code above to error and exit if hung up, someting like:
#if 0
		int counter = 0;
		while(MPL3115A2_IIC_Read(STATUS) & (1<<2) == 0)
		{
			if(++counter > 600) return(-999); //Error out after max of 512ms for a read
			delay(1);
		}
#endif

    // read len-1 bytes of data followed by ACK
    SDA_SetDigitalInput();        	// set SDA pin as input
    delay_10us();
    for(i = 0;i < len-1;i++){
        input_data = 0x00;
        for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
            input_data <<= 1;   // Shift the byte by one bit
            SCL_SetHigh();         // Clock the data into the I2C Bus
            delay_10us();
            input_data |= SDA_GetValue();  // Input the data from the I2C Bus
            delay_10us();
            SCL_SetLow();
            delay_10us();
        }
        // send ACK
        SDA_SetLow();    	// send ACK valid
        SDA_SetDigitalOutput();   // Put port pin to output
        delay_10us();
        SCL_SetHigh();		// Clock the ACK from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
        SDA_SetDigitalInput(); //return SDA to Hi Z
        *ptr++ = input_data;        //save received data
    }

    // now read last byte of data followed by NACK
    input_data = 0x00;
    for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
        input_data <<= 1;   // Shift the byte by one bit
        SCL_SetHigh();         // Clock the data into the I2C Bus
        delay_10us();
        input_data |= SDA_GetValue();  // Input the data from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
    }
    // send NACK
    SDA_SetHigh();    	// send NACK valid
    SDA_SetDigitalOutput();   // Put port pin to output
    delay_10us();
    SCL_SetHigh();		// Clock the ACK from the I2C Bus
    delay_10us();
    SCL_SetLow();
    delay_10us();
    SDA_SetDigitalInput(); //return SDA to Hi Z

    *ptr = input_data;        //save last received data

	i2c_stop();	// create a stop condition
}

/************************************
*       HTU21D_readHumidity         *
************************************/
/*
Name: HTU21D_readHumidity
Synopsis: Reads humidity from the sensor
Description:
TRIGGER_HUMD_MEASURE_NOHOLD
In the No Hold Master mode, the MCU has to poll for the termination
of the internal processing of the HTU21D(F) sensor. This is done
by sending a start condition followed by the I2C header (0x81).
If the internal processing is finished, the HTU21D(F) sensor
acknowledges the poll of the MCU and data can be read by the MCU.
If the measurement processing is not finished, the HTU21D(F)
sensor answers no ACK bit and start condition must be issued once more.

Measured data are
transferred in two byte packages, i.e. in frames of 8-bit length where the most significant bit (MSB) is transferred
first (left aligned). Each byte is followed by an acknowledge bit. The two status bits, the last bits of LSB, must be
set to ‘0’ before calculating physical values.

To accommodate/adapt any process variation (nominal capacitance value of the humidity die), tolerances of the
sensor above 100%RH and below 0%RH must be considered. As a consequence:
118%RH corresponds to 0xFF which is the maximum RH digital output that can be sent out from the
ASIC. RH output can reach 118%RH and above this value, there will have a clamp of the RH output to this
value.
-6%RH corresponds to 0x00 which is the minimum RH digital output that can be sent out from the ASIC.
RH output can reach -6%RH and below this value, there will have a clamp of the RH output to this value.

The status bit indicates the measuremnt type.

For both modes, since the maximum resolution of the measurement is 14 bits, the two last least significant bits
(LSBs, bits 43 and 44) are used for transmitting status information. Bit 1 of the two LSBs indicates the
measurement type (‘0’: temperature, ‘1’: humidity). Bit 0 is currently not assigned.

Revision History:

*/
uint8_t HTU21D_readHumidity(void)
{
uint8_t HTU21D_data[3];
uint8_t checksum;
uint16_t rawHumidity;
float rh_f;
uint8_t rh;

		read_HTU21D(TRIGGER_HUMD_MEASURE_NOHOLD, HTU21D_data, 3);
		checksum = HTU21D_data[2];
		rawHumidity = (HTU21D_data[0] << 8) |  HTU21D_data[1];

		// try to get PIC CRC hardware working.
		if(HTU21D_check_crc(rawHumidity, checksum) != 0)
				return(0); //Error out

		// save raw data
		raw_data[0] = HTU21D_data[0];
		raw_data[1] = HTU21D_data[1];

		//sensorStatus = rawHumidity & 0x0003; //Grab only the right two bits
		rawHumidity &= 0xFFFC; //Zero out the status bits but keep them in place

		// calculate relative humidity using floating point math
		rh_f = -6.0 + (125.0 * ((float) rawHumidity / 65536.0)); // from data sheet, page 14

		// limit returned measuremet range to between 0 and 99
		if(rh_f < 0)
				rh_f = 0;
		if(rh_f > 99)
				rh_f = 99;

		HTU21D_h = (uint8_t) rh_f;  // why are we saving and returing the same value?

		return((uint8_t) rh_f);
}

/************************************
*       HTU21D_check_crc           *
************************************/
/*
Name: HTU21D_check_crc
Synopsis: checks the crc
Description:
I could not get the PIC CRC module working, so the calculation
is performed in software

Revision History:

*/
//Give this function the 2 byte message (measurement) and the check_value byte from the HTU21D
//If it returns 0, then the transmission was good
//If it returns something other than 0, then the communication was corrupted
//From: http://www.nongnu.org/avr-libc/user-manual/group__util__crc.html
//POLYNOMIAL = 0x0131 = x^8 + x^5 + x^4 + 1 : http://en.wikipedia.org/wiki/Computation_of_cyclic_redundancy_checks
#define SHIFTED_DIVISOR 0x988000 //This is the 0x0131 polynomial shifted to farthest left of three bytes

uint8_t HTU21D_check_crc(uint16_t message_from_sensor, uint8_t check_value_from_sensor)
{
  uint32_t remainder = (uint32_t)message_from_sensor << 8; //Pad with 8 bits because we have to add in the check value
  remainder |= check_value_from_sensor; //Add on the check value

  uint32_t divsor = (uint32_t)SHIFTED_DIVISOR;

  for (int i = 0 ; i < 16 ; i++) //Operate on only 16 positions of max 24. The remaining 8 are our remainder and should be zero when we're done.
  {

    if( remainder & (uint32_t)1<<(23 - i) ) //Check if there is a one in the left position
      remainder ^= divsor;

    divsor >>= 1; //Rotate the divsor max 16 times so that we have 8 bits left of a remainder
  }

  return (uint8_t)remainder;
}

/************************************
*         HTU21D_setResolution      *
************************************/
/*
Name: HTU21D_setResolution
Synopsis:
Requires:
Description:

The content of user register is described in the data sheet.
Reserved bits must not be changed and default values of respective
reserved bits may change over time without prior notice. Therefore, for
any writing to user register, default values of reserved bits must
be read first.

The “End of Battery” alert/status is activated when the battery
power falls below 2.25V.  The heater is intended to be used for
functionality diagnosis: relative humidity drops upon rising temperature.
The heater consumes about 5.5mW and provides a temperature increase
of about 0.5-1.5°C.

OTP reload is a safety feature and load the entire OTP settings to the
register, with the exception of the heater bit, before every measurement.
This feature is disabled per default and it is not recommended for use.
Please use soft reset instead as it contains OTP reload.

Bits 7 and bit 0 set the Measurement resolution
default is 0,0

Bit 7 and Bit 0
0		0		RH=12 bits, temperature=14bits
0		1		RH=8 bits, temperature=12bits
1		0		RH=10 bits, temperature=13bits
1		1		RH=11 bits, temperature=11bits

valid resolution choices:
0
1
8
81

Bit 6: End of Battery
‘0’: VDD>2.25V
‘1’: VDD<2.25V

Bits 3,4 and 5 are reserved and should not be changed according to note
above.

Bit 2: enable on chip heater, default = 0
The heater is intended to be used for functionality diagnosis: relative humidity drops upon rising temperature.
The heater consumes about 5.5mW and provides a temperature increase of about 0.5-1.5°C.
Probably could do the same functional check with a heat gun.  Apply some heat and look for
a humidity change.

Bit 1: Disable OTP reload, default = 1

Revision History:
The sparfun code does not indicate what the correct
function argument should be. Valid resolution choices:
0x00, 0x01, 0x80 and 0x81
*/
void HTU21D_setResolution(uint8_t resolution)
{
uint8_t userRegister;

		// read the user register
		i2c_start();
		i2c_write(HTDU21D_ADDRESS);	// device address
		i2c_write(READ_USER_REG);
		i2c_stop();	// create a stop condition

		i2c_start();
		i2c_write(HTDU21D_ADDRESS | 0x01);	// device address
		userRegister = i2c_read();
		i2c_stop();	// create a stop condition

		userRegister &= 0b01111110; //Turn off the resolution bits
		resolution &= 0b10000001; //Turn off all other bits but resolution bits
		userRegister |= resolution; //Mask in the requested resolution bits

		i2c_start();
		i2c_write(HTDU21D_ADDRESS);	// device address
		i2c_write(READ_USER_REG);
		i2c_write(userRegister);
		i2c_stop();	// create a stop condition
}

/************************************
*      HTU21D_readTemperature       *
************************************/
/*
Name: HTU21D_readTemperature
Synopsis:
Description:
Reads back the temperatue and converts to F.
HTU21D_Tfrac = temperatue in F, 1 decimal place
HTU21D_Twhole = temperatue in F, whole part of the reading
Revision History:
*/
//Read the temperature
/*******************************************************************************************/
//Calc temperature and return it to the user
//Returns 998 if I2C timed out
//Returns 999 if CRC is wrong
int8_t HTU21D_readTemperature(void)
{
uint8_t checksum;
uint16_t rawTemperature;
float realTemperature;
uint8_t HTU21D_data[3];
double i_val, f_val;  // whole and fractional part

read_HTU21D(TRIGGER_TEMP_MEASURE_NOHOLD, HTU21D_data, 3);
checksum = HTU21D_data[2];
rawTemperature = (HTU21D_data[0] << 8) |  HTU21D_data[1];

// try to get PIC CRC hardware working.
if(HTU21D_check_crc(rawTemperature, checksum) != 0)
	return(-99); //Error out

	//if(HTU21D_check_crc(rawTemperature, checksum) != 0) return(999); //Error out

	// save raw data
	raw_data[2] = HTU21D_data[0];
	raw_data[3] = HTU21D_data[1];

	//sensorStatus = rawTemperature & 0x0003; //Grab only the right two bits
	rawTemperature &= 0xFFFC; //Zero out the status bits but keep them in place

	//Given the raw temperature data, calculate the actual temperature
	//tempTemperature = (float) rawTemperature / 65536.0; //2^16 = 65536
	realTemperature = (((-46.85 + (175.72 * rawTemperature / 65536.0)) * 9.0)/ 5.0 + 32.0); //From page 14

    f_val = modf((double) realTemperature , &i_val)*10.0;
    HTU21D_Tfrac = (uint8_t) f_val;
    HTU21D_Twhole = (uint8_t) i_val;

	return(HTU21D_Twhole);
}

//end of file
