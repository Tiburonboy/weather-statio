/************************************
*         LCD0821.h                 *
************************************/
/*
Name: LCD0821.h
Synopsis: header file for the Orbital LCD0821,
2 line by 8 character I2C LCD display functions.
Date: 7/22/2020
*/

void write_LCD(uint8_t *ptr);
void clear_LCD(void);
void putch(uint8_t char_out);
void set_LCD_cursor(uint8_t col, uint8_t row);
void LCD_backlight(uint8_t cmd);

/*
The LCD address is 0x2e, which is the I2C 7 bit address,
which requires a left shift to make room for the W/R bit.
I2C address is set by jumpers, 0x2e is the factory default setting.
*/
#define LCD_ADDRESS 0x2e

// end
