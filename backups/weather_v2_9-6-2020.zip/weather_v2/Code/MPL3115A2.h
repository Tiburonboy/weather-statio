/************************************
*       MPL3115A2.h                 *
************************************/
/*
Name: MPL3115A2.h
Description:  function prototypes.
Revision History:
*/

uint16_t MPL3115A2_readPressure(void);

void init_MPL3115A2(void);
void MPL3115A2_setModeBarometer(void);
void MPL3115A2_setModeStandby(void);
void MPL3115A2_setModeActive(void);
void MPL3115A2_setOversampleRate(uint8_t sampleRate);
void MPL3115A2_enableEventFlags(void);
void MPL3115A2_toggleOneShot(void);
int8_t MPL3115A2_readTemp(void);

// pressure data is stored with units of inHg (kPa value divided by 33.864)
extern uint8_t MPL3115A2_Pwhole;  // need two digits, usually 28 to 30
extern uint8_t MPL3115A2_Pfrac;   // need two digits
extern uint8_t raw_data[10];  // raw sensor data

// end
