


uint8_t i2c_read(void);
void i2c_write(uint8_t output_data);
void i2c_stop(void);
void i2c_start(void);

void delay_10us(void);
void delay_30us(void);
void delay_100us(void);
void delay_480us(void);

void delay_1ms(void);
void delay_25ms(void);
void delay_750ms(void);
void delay_1sec(void);
