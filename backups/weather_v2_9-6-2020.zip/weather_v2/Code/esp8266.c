/************************************
*            ESP8266                *
************************************/
/*
Name: esp8266.c
Synopsis:  An amalgamation of esp8266 code from various sources for the
PIC16F18855 microcontrioller.
Requires:
Description:

ESP8266 UART0 RXI goes to Arduino pin 9
ESP8266 UART0 TXO goes to Arduino pin 8

UART setup: 9600 baud, 8 bits, no parity, 1 stop bit
See the link here:
https://medium.com/@aallan/getting-started-with-the-esp8266-270e30feb4d1

Author: Tony Cirineo
Date:  5/27/2020
Revision History:

*/

#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "esp8266.h"
#include "rtc.h"
#include "i2c.h"

extern int8_t retVal;

//esp8266 Tx/Rx buffers
// buffer size is set to 100 for debugging
// connect string is about 68 char long
uint8_t esp8266_RxBuf[100];  // holds data from esp8266
// time stamp added to data message
// 7-19-2020: increased message size to 64, allows for rssi, and TEPT4400 data
// 8-22-2020: making changes to send raw sensor data
uint8_t esp8266_TxBuf[64];  // holds data for sending to socket

//AT+CWJAP_CUR – Connect to AP, won‘t save to Flash
// can also use: AT+CWJAP_DEF – Connect to AP,save as default
const char connect_string[] = "AT+CWJAP_CUR=\"Jim\",\"E6BD91FB3C\"\r\n";

extern volatile uint8_t eusartRxCount;
extern volatile eusart_status_t eusartRxLastError;

//extern uint16_t ml_tmr; // main loop timer
extern uint16_t to_tmr; // time out timer

extern uint8_t HTU21D_h;  // humidity 0 to 99
extern int8_t HTU21D_Twhole;  // whole part of the temperature value
extern uint8_t HTU21D_Tfrac;  // fractional part of the temperature value, need 1 digit
extern uint8_t MPL3115A2_Pwhole;  // usually 29, divide the mPa value by 33.864 to get inHg
extern uint8_t MPL3115A2_Pfrac;   // fractional part, need two digits
extern uint8_t get_sensor_data_flg;
extern uint16_t ALS_PT19_value; // ALS-PT19 ambient light sensor
extern uint16_t TEPT4400_value; //TEPT4400 ambient light sensor
extern uint8_t raw_data[10];  // raw sensor data
extern int8_t esp_rssi;  // rssi value from AT+CWJAP_CUR?, usually -59
extern uint8_t esp_channel;  // channel value from AT+CWJAP_CUR?, usually 4

//uint16_t sec_cnt;  // used to count seconds
uint8_t wifi_connect_flg;  // used to flag if time to connect
int8_t wifi_connect_status;  // used to signal WiFi connect status

uint8_t network_time_valid;
extern uint8_t update_rtc_flg;

struct network_timedate network_timedate;

/************************************
*            connect2network        *
************************************/
/*
Name:
Synopsis:
Requires:
Description:
// wakeup esp8266
// init
// connect to router
// connect to socket
// send data
// wait for reply
// disconnect socket
// disconnect from router
// put esp8266 to sleep
Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/
void connect2network(void)
{
    // wakeup esp8266 by hardware reset
    ESP_RESET_SetDigitalOutput(); // set pin as output
    delay_100us();  // hold low for a bit
    ESP_RESET_SetDigitalInput(); // release pin

    // give esp8266 time to wake up
    to_tmr = 0;  // reset timer count
    while(to_tmr < 5000); // wait 5 sec

    // test the ESP8266
    esp8266_write("AT\r\n");
    if(esp8266_GetResponse("OK", 3000) <= 0){
      wifi_connect_status = -1; // wakeup test fail
      return;
    }

    // set MUX
    // Enable single connection MUX=0
    esp8266_write("AT+CIPMUX=0\r\n");
    esp8266_GetResponse("OK", 3000);

    // configure as station
    /*
    1 : station mode
    2 : softAP mode
    3 : softAP + station mode
    */
    esp8266_write("AT+CWMODE_CUR=1\r\n"); //  set to station mode
    esp8266_GetResponse("OK", 3000);

    // connect to router
    // AT+CWJAP_CUR Connect to AP, not stored in flash
    esp8266_write(connect_string);
    if(esp8266_GetResponse("CONNECTED", 9000) <= 0){
      wifi_connect_status = -2; // esp8266 can't connect to network
      return;
    }

    // need a delay here, give newtork time to register connection
    to_tmr = 0;  // reset timer count
    while(to_tmr < 5000); // wait 5 sec

    // get station rssi and channel
    esp8266_rssi();  // get rssi and channel

    // connect as TCP client
    // connects to HP laptop change to Rpi0w later
    //esp8266_write("AT+CIPSTART=\"TCP\",\"192.168.1.44\",12345\r\n"); //protocol, server IP and port
    esp8266_write("AT+CIPSTART=\"TCP\",\"192.168.1.15\",12345\r\n"); //protocol, server IP and port
    if(esp8266_GetResponse("CONNECT", 5000) <= 0){  // look for CONNECT
            // disconnect from router
            // AT+CWQAP – Disconnect from AP
            esp8266_write("AT+CWQAP\r\n");
            esp8266_GetResponse("OK", 3000);

            // deep sleep mode, turns wifi blue LED off
            // requires hardware reset to wake
            esp8266_write("AT+GSLP=0\r\n");
            esp8266_GetResponse("OK", 3000);

            wifi_connect_status = -3; // esp8266 can't connect as client
            return;
    }

    // Step 6. ESP8266 sends data to the server
#if 0
    //  don't hard code block size, test this later
    sprintf(esp8266_TxBuf,"AT+CIPSEND=%d\r\n",sizeof(esp8266_TxBuf));
    esp8266_write(esp8266_TxBuf);
#else
    esp8266_write("AT+CIPSEND=64\r\n");  // number of chars needs to be correct
    esp8266_GetResponse(">", 5000);  // replies ">" or ERROR  <-- add some error checking
#endif

    // send TX buffer, sample weather station data
    /*
    xx:xx:xx  weather station time
    HTU21D_H;  // humidity 0 to 99
    HTU21D_Twhole;  // whole part of the temperature value
    HTU21D_Tfrac;  // fractional part of the temperature value, need 1 digit
    MPL3115A2_Pwhole;  // usually 29, divide the mPa value by 33.864 to get inHg
    MPL3115A2_Pfrac;   // fractional part, need two digits
    ALS_PT19_value  light sensor raw ADC count, four digits
    */

    clear_esp8266_TxBuf();
    sprintf(esp8266_TxBuf,"%02d:%02d:%02d,%2d,%4d.%1d,%2d.%2d,%4d,%4d,%4d,%2d,", \
        hour,minute,second,HTU21D_h,HTU21D_Twhole,HTU21D_Tfrac, \
        MPL3115A2_Pwhole,MPL3115A2_Pfrac,ALS_PT19_value,
        TEPT4400_value,esp_rssi,esp_channel);
        // final comma is also included in string
    // insert raw sensor data at offset 45 in esp8266_TxBuf as base64 encoded data
    include_raw_data();
    esp8266_write_TxBuf();

    // wait for data from TCP server, data is saved in esp8266_RxBuf
    esp8266_GetDataFromServer(5000); // gets RX_buf_size or times out, also decodes network time
    // RXBuf has both esp8266 response and server data

    // End the TCP connection
    esp8266_write("AT+CIPCLOSE\r\n");
    esp8266_GetResponse("OK", 3000);

    // disconnect from router
    // AT+CWQAP – Disconnect from AP
    esp8266_write("AT+CWQAP\r\n");
    esp8266_GetResponse("OK", 3000);

    // deep sleep mode, turns wifi blue LED off
    // requires hardware reset to wake
    esp8266_write("AT+GSLP=0\r\n");
    esp8266_GetResponse("OK", 3000);

}

/************************************
*          esp8266_rssi             *
************************************/
/*
Name: esp8266_rssi
Synopsis:
Requires:
Description:

AT+CWJAP_CUR – Connect to AP,for current
AT+CWJAP_CUR?
Response

Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/
void esp8266_rssi(void)
{
uint8_t *ptr,temp[4];

esp8266_write("AT+CWJAP_CUR?\r\n");
esp8266_GetResponse("OK", 3000);

    // decode channel # and rssi from string
    ptr = strstr(esp8266_RxBuf,"0\","); // look for 0",
    if(ptr == 0){
        esp_rssi = -127;  // set value to -127 because of error
        esp_channel = 0;  // set channel to 0 because of error
        return;
    }

    // get wifi channel
    ptr++;  // advance by 3
    ptr++;
    ptr++;  // now points to 1st digit in channel number
    temp[0] = *ptr++; // get 1st digit of channle #, could be 1 or 2 digits
    if(*ptr != ','){
        temp[1] = *ptr++; // get next digit
        temp[2] = 0;
    }
    else{
        temp[1] = 0;
    }
    esp_channel = atoi(temp);
    ptr++; // skip ','

    temp[0] = *ptr++; // get rssi, usually like -59
    temp[1] = *ptr++;
    temp[2] = *ptr++;
    temp[3] = 0;
    esp_rssi = atoi(temp);
}

/************************************
*     esp8266_GetDataFromServer     *
************************************/
/*
Name: esp8266_GetResponse
Synopsis:
Requires:
Description:

timeout: time in millis (1ms from TMR0)
waits for data from server, writes to esp8266_RxBuf
only reads one buffer size

read time sent by server and can flag an update to the RTC if
the time has drifted by more than XX seconds.
time roll over logic is complicated, so don't check the time
near the top of the hour because slight differences can
cause the time not to aggree at 59 seconds.

Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/
int8_t esp8266_GetDataFromServer(uint16_t timeout)
{
uint8_t char_cnt,*ptr,temp[3],sec_dif;
uint16_t wait;

    char_cnt = 0; // clear character count
    to_tmr = 0;   // reset timer count
    clear_esp8266_RxBuf();    // clear last message from RxBuf

    ptr = esp8266_RxBuf;  // initialize pointer to RX buffer

    // while waiting for time out, get data
    while(to_tmr < timeout){
        if(EUSART_is_rx_ready()){
            *ptr++ = EUSART_Read();  // get one charater
            char_cnt++;
        }
        // exit time out loop if received sizeof(esp8266_TxBuf) + ??? block of data
        if(char_cnt > sizeof(esp8266_TxBuf)+22)  // need to debug this, is returned string variable?
            break;
    }

    // decode data from server, look for +IPD,n:xxxxxxxxxx received n bytes, data=xxxxxxxxxxx
    // look for
    ptr = strstr(esp8266_RxBuf,"+IPD"); // look for +IPD
    if(ptr == 0){
        wifi_connect_status = -4; // RX data error
        return 0;
    }
    ptr = strstr(esp8266_RxBuf,":"); // now look for :
    if(ptr == 0){
        wifi_connect_status = -4; // RX data error
        return 0;
    }

    // get network time and date
    ptr++;  // advance by one char
    // get time string - hh:mm:ss,MM/DD/YY
    temp[0] = *ptr++; // get month
    temp[1] = *ptr++;
    temp[2] = 0;
    network_timedate.month = atoi(temp);
    ptr++; // skip :

    temp[0] = *ptr++; // get day
    temp[1] = *ptr++;
    temp[2] = 0;
    network_timedate.day = atoi(temp);
    ptr++; // skip :

    temp[0] = *ptr++; // get year
    temp[1] = *ptr++;
    temp[2] = 0;
    network_timedate.year = atoi(temp);
    ptr++; // skip ,

    temp[0] = *ptr++; // get hours
    temp[1] = *ptr++;
    temp[2] = 0;
    network_timedate.hour = atoi(temp);
    ptr++; // skip /

    temp[0] = *ptr++; // get minutes
    temp[1] = *ptr++;
    temp[2] = 0;
    network_timedate.minute = atoi(temp);
    ptr++; // skip /

    temp[0] = *ptr++; // get seconds
    temp[1] = *ptr++;
    temp[2] = 0;
    network_timedate.second = atoi(temp);

    // only check for agreement if not top of the hour because
    // roll over logic is complicated
    if((minute > 55) || (minute < 5)){
        // network_time_valid = 1; just leave this set from last time
        wifi_connect_status = 2; // WiFi Tx/Rx OK, just assume OK
        return char_cnt;
    }

    // check for agrement between weather station time and network time
    // should only be seconds error
    if(network_timedate.month == month){
        if(network_timedate.day == monthDay){
            if(network_timedate.year == year){
                if(network_timedate.hour == hour){  // min & sec could be diff, just look for correct hours
                    network_time_valid = 1;  // all but minutes and seconds must agree
                    //if(network_timedate.minute == minute){

                    get_time_date();  // get RTC values, are these going to be with 1 second????  maybe only look at min
                    if(network_timedate.second != second){  // need to fix this, when was seconds last read,
                        // if second difference is > 5, set flag to update weather station time
                        // see python code for a check of the math
                        if(second > network_timedate.second)
                            sec_dif = (second - network_timedate.second);
                        else
                            sec_dif = 60-(network_timedate.second - second);
                        if (sec_dif > 30)
                            sec_dif = 60 - sec_dif;
                        if(sec_dif > 5){
                            update_rtc_flg = 1;
                            set_time_date();
                        }
                        else
                            update_rtc_flg = 0;
                    }
                    //}else{network_time_valid = 0;}
                }
                else{
                    network_time_valid = 0;
                    wifi_connect_status = -5; // RX time error
                    return char_cnt;
                }
            }else{network_time_valid = 0;}
        }else{network_time_valid = 0;}
    }else{network_time_valid = 0;}

    // set WiFi status, this gets updated at next exchange of data
    if(update_rtc_flg){
        wifi_connect_status = 3; //  RTC was updated
        update_rtc_flg = 0;
    }
    else
        wifi_connect_status = 2; // WiFi Tx/Rx OK

    return char_cnt;  // return character count
}

/************************************
*          esp8266_init             *
************************************/
/*
Name:
Synopsis:
Requires:
Description:
run on power up

returns number of chars

Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/
int8_t esp8266_init(void)
{
    // After power up esp8266 tries to auto connect, wait 9sec to complete
    to_tmr = 0;  // reset timer count
    while(to_tmr < 5000); // wait 5 sec

    // send \r\n to clear serial after PIC program load
    esp8266_write("\r\n");  // send \r\n to clear serial after PIC program load
    esp8266_GetResponse("ERROR", 3000);  // returns ERROR

    // restart esp8266, not necessary, comment out
    //esp8266_write("AT+RST\r\n");  // restart
    //retVal = esp8266_GetResponse("OK", 5000);

    // test the ESP8266
    esp8266_write("AT\r\n"); //
    if(esp8266_GetResponse("OK", 3000) <= 0){
        wifi_connect_status = 0; // esp8266 not present
    }
    else{
        wifi_connect_status = 1; // esp8266 test OK
    }
    /*
    In Deep-sleep mode, the chip can be woken up and initialized by a low-level pulse
    generated on the EXT_RSTB pin via an external IO.
    */

    // deep sleep mode
    esp8266_write("AT+GSLP=0\r\n");
    retVal = esp8266_GetResponse("OK", 3000);

    return(retVal);
}

/************************************
*     esp8266_GetResponse           *
************************************/
/*
Name: esp8266_GetResponse
Synopsis:
Requires:
Description:
rsp: string to look for if no error
timeout: time in millis (1ms from TMR0)

After sending a command to ESP8266 wait, read and chaeck response

could combine into one function
esp8266_write("AT+SLEEP=1\r\n");
retVal = esp8266_GetResponse("OK", 3000);

esp8266_WriteCmd  = writes command then checks response
returns with error code

Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/
int8_t esp8266_GetResponse(uint8_t *rsp, uint16_t timeout)
{
uint8_t char_cnt,*ptr;
uint16_t wait;

    char_cnt = 0; // clear character count
    to_tmr = 0;  // reset timer count
    clear_esp8266_RxBuf();    // clear last message from RxBuf

    ptr = esp8266_RxBuf;  // initialize pointer to RX buffer

    while(to_tmr < timeout){
        if(EUSART_is_rx_ready()){
            *ptr++ = EUSART_Read();  // get one charater
            char_cnt++;
            if(strstr(esp8266_RxBuf,rsp)){	// search RxBuf for match
                // esp8266 can send more info after string match
                while(EUSART_is_rx_ready()){  //get any remaining chars after match
                    // check char count, if at max don't save new chars
                    if(char_cnt < sizeof(esp8266_RxBuf))
                        *ptr++ = EUSART_Read();
                    else
                        *ptr = EUSART_Read();  // read but don't increment pointer
                    char_cnt++;
                    wait = to_tmr+10;  // wait 10ms for more characters
                    while(to_tmr < wait);
                }
                return char_cnt;	// Return number of chars read, one high?
            }
        }
    }

    if (char_cnt > 0){ // received unknown
        return -1; // unkown response error code
    }
    else{ // got nothing and timed out
        return 0; // timeout error code
    }
}

/************************************
*         clear_esp8266_RxBuf       *
************************************/
/*
Name: clear_esp8266_RxBuf
Description: clears the RX buffer by filling with known char
Fill char used for debugging.
Revision History:
*/
void clear_esp8266_RxBuf(void)
{
uint8_t i;

    for(i = 0; i <= sizeof(esp8266_RxBuf);i++)
        esp8266_RxBuf[i] = 'a';  // fill char, for debug

    esp8266_RxBuf[sizeof(esp8266_RxBuf)-1] = 0;
}

/************************************
*           esp8266_write           *
************************************/
/*
Name: esp8266_write
Description:  writes a sring to the esp8266 via the EUSART.
seems like the PIC EUSART is only able to support 1 stop bit, and parity is
done in software.
Revision History:
*/
// write a string to ESP8266, need to re-visit for long strings
void esp8266_write(uint8_t *string)
{
    while(*string != 0){
        while(!EUSART_is_tx_ready());
        EUSART_Write(*string++);
    }
    while(!EUSART_is_tx_done());
}

/************************************
*         esp8266_write_TxBuf       *
************************************/
/*
Name: esp8266_write_TxBuf
Description: writes entire TxBuf to esp8266
ESP8266 was told how many chars to expect and will wait for
the number of chars if less is sent.  So send entire buffer.
Revision History:
*/
void esp8266_write_TxBuf(void)
{
uint8_t i;

    for(i = 0; i < sizeof(esp8266_TxBuf);i++){
        while(!EUSART_is_tx_ready());
        EUSART_Write(esp8266_TxBuf[i]);
    }
    while(!EUSART_is_tx_done());
}

/************************************
*       clear_esp8266_TxBuf         *
************************************/
/*
Name: clear_esp8266_TxBuf
Description: clears the TX buffer by filling with a known character
Description: Clears the buffer by fillling the buffer with a known character.
This is used in debugging to easily identify new chars written to the
buffer and length of buffer being used.
Revision History:
*/
void clear_esp8266_TxBuf(void)
{
uint8_t i;

    for(i = 0; i <= sizeof(esp8266_TxBuf);i++)
        esp8266_TxBuf[i] = 'z';  // fill char, for debug, later replace with 0x0

    esp8266_TxBuf[sizeof(esp8266_TxBuf)-1] = 0;
}

/************************************
*       include_raw_data           *
************************************/
/*
Name: include_raw_data
Description: Hard coded to put base64 encoded data at correct
offsent in esp8266_TxBuf.
raw_data is 10 bytes, should incode into 13 characters
modified from:
https://nachtimwald.com/2017/11/18/base64-encode-and-decode-in-c/
Revision History:
8/28/2020: changed variable v from uint8_t to uint32_t
*/
const uint8_t b64chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
void include_raw_data(void)
{
uint8_t  i, j, len;
uint32_t v;

  len = 10;

  for (i=0, j=45; i<len; i+=3, j+=4) {
		v = raw_data[i];
		v = i+1 < len ? v << 8 | raw_data[i+1] : v << 8;
		v = i+2 < len ? v << 8 | raw_data[i+2] : v << 8;

		esp8266_TxBuf[j]   = b64chars[(v >> 18) & 0x3F];
		esp8266_TxBuf[j+1] = b64chars[(v >> 12) & 0x3F];
		if (i+1 < len) {
			esp8266_TxBuf[j+2] = b64chars[(v >> 6) & 0x3F];
		} else {
			esp8266_TxBuf[j+2] = '=';
		}
		if (i+2 < len) {
			esp8266_TxBuf[j+3] = b64chars[v & 0x3F];
		} else {
			esp8266_TxBuf[j+3] = '=';
		}
	}

}


// end
