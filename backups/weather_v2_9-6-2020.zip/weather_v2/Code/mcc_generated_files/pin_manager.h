/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.0
        Device            :  PIC16F18857
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.10 and above
        MPLAB 	          :  MPLAB X 5.35	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set SCL aliases
#define SCL_TRIS                 TRISAbits.TRISA1
#define SCL_LAT                  LATAbits.LATA1
#define SCL_PORT                 PORTAbits.RA1
#define SCL_WPU                  WPUAbits.WPUA1
#define SCL_OD                   ODCONAbits.ODCA1
#define SCL_ANS                  ANSELAbits.ANSA1
#define SCL_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define SCL_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define SCL_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define SCL_GetValue()           PORTAbits.RA1
#define SCL_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define SCL_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define SCL_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define SCL_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define SCL_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define SCL_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define SCL_SetAnalogMode()      do { ANSELAbits.ANSA1 = 1; } while(0)
#define SCL_SetDigitalMode()     do { ANSELAbits.ANSA1 = 0; } while(0)

// get/set SDA aliases
#define SDA_TRIS                 TRISAbits.TRISA2
#define SDA_LAT                  LATAbits.LATA2
#define SDA_PORT                 PORTAbits.RA2
#define SDA_WPU                  WPUAbits.WPUA2
#define SDA_OD                   ODCONAbits.ODCA2
#define SDA_ANS                  ANSELAbits.ANSA2
#define SDA_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define SDA_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define SDA_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define SDA_GetValue()           PORTAbits.RA2
#define SDA_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define SDA_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define SDA_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define SDA_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define SDA_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define SDA_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define SDA_SetAnalogMode()      do { ANSELAbits.ANSA2 = 1; } while(0)
#define SDA_SetDigitalMode()     do { ANSELAbits.ANSA2 = 0; } while(0)

// get/set ALS_PT19 aliases
#define ALS_PT19_TRIS                 TRISAbits.TRISA3
#define ALS_PT19_LAT                  LATAbits.LATA3
#define ALS_PT19_PORT                 PORTAbits.RA3
#define ALS_PT19_WPU                  WPUAbits.WPUA3
#define ALS_PT19_OD                   ODCONAbits.ODCA3
#define ALS_PT19_ANS                  ANSELAbits.ANSA3
#define ALS_PT19_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define ALS_PT19_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define ALS_PT19_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define ALS_PT19_GetValue()           PORTAbits.RA3
#define ALS_PT19_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define ALS_PT19_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define ALS_PT19_SetPullup()          do { WPUAbits.WPUA3 = 1; } while(0)
#define ALS_PT19_ResetPullup()        do { WPUAbits.WPUA3 = 0; } while(0)
#define ALS_PT19_SetPushPull()        do { ODCONAbits.ODCA3 = 0; } while(0)
#define ALS_PT19_SetOpenDrain()       do { ODCONAbits.ODCA3 = 1; } while(0)
#define ALS_PT19_SetAnalogMode()      do { ANSELAbits.ANSA3 = 1; } while(0)
#define ALS_PT19_SetDigitalMode()     do { ANSELAbits.ANSA3 = 0; } while(0)

// get/set GRN_LED aliases
#define GRN_LED_TRIS                 TRISAbits.TRISA4
#define GRN_LED_LAT                  LATAbits.LATA4
#define GRN_LED_PORT                 PORTAbits.RA4
#define GRN_LED_WPU                  WPUAbits.WPUA4
#define GRN_LED_OD                   ODCONAbits.ODCA4
#define GRN_LED_ANS                  ANSELAbits.ANSA4
#define GRN_LED_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define GRN_LED_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define GRN_LED_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define GRN_LED_GetValue()           PORTAbits.RA4
#define GRN_LED_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define GRN_LED_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define GRN_LED_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define GRN_LED_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define GRN_LED_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define GRN_LED_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define GRN_LED_SetAnalogMode()      do { ANSELAbits.ANSA4 = 1; } while(0)
#define GRN_LED_SetDigitalMode()     do { ANSELAbits.ANSA4 = 0; } while(0)

// get/set BLU_LED aliases
#define BLU_LED_TRIS                 TRISAbits.TRISA5
#define BLU_LED_LAT                  LATAbits.LATA5
#define BLU_LED_PORT                 PORTAbits.RA5
#define BLU_LED_WPU                  WPUAbits.WPUA5
#define BLU_LED_OD                   ODCONAbits.ODCA5
#define BLU_LED_ANS                  ANSELAbits.ANSA5
#define BLU_LED_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define BLU_LED_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define BLU_LED_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define BLU_LED_GetValue()           PORTAbits.RA5
#define BLU_LED_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define BLU_LED_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define BLU_LED_SetPullup()          do { WPUAbits.WPUA5 = 1; } while(0)
#define BLU_LED_ResetPullup()        do { WPUAbits.WPUA5 = 0; } while(0)
#define BLU_LED_SetPushPull()        do { ODCONAbits.ODCA5 = 0; } while(0)
#define BLU_LED_SetOpenDrain()       do { ODCONAbits.ODCA5 = 1; } while(0)
#define BLU_LED_SetAnalogMode()      do { ANSELAbits.ANSA5 = 1; } while(0)
#define BLU_LED_SetDigitalMode()     do { ANSELAbits.ANSA5 = 0; } while(0)

// get/set ESP_RESET aliases
#define ESP_RESET_TRIS                 TRISAbits.TRISA6
#define ESP_RESET_LAT                  LATAbits.LATA6
#define ESP_RESET_PORT                 PORTAbits.RA6
#define ESP_RESET_WPU                  WPUAbits.WPUA6
#define ESP_RESET_OD                   ODCONAbits.ODCA6
#define ESP_RESET_ANS                  ANSELAbits.ANSA6
#define ESP_RESET_SetHigh()            do { LATAbits.LATA6 = 1; } while(0)
#define ESP_RESET_SetLow()             do { LATAbits.LATA6 = 0; } while(0)
#define ESP_RESET_Toggle()             do { LATAbits.LATA6 = ~LATAbits.LATA6; } while(0)
#define ESP_RESET_GetValue()           PORTAbits.RA6
#define ESP_RESET_SetDigitalInput()    do { TRISAbits.TRISA6 = 1; } while(0)
#define ESP_RESET_SetDigitalOutput()   do { TRISAbits.TRISA6 = 0; } while(0)
#define ESP_RESET_SetPullup()          do { WPUAbits.WPUA6 = 1; } while(0)
#define ESP_RESET_ResetPullup()        do { WPUAbits.WPUA6 = 0; } while(0)
#define ESP_RESET_SetPushPull()        do { ODCONAbits.ODCA6 = 0; } while(0)
#define ESP_RESET_SetOpenDrain()       do { ODCONAbits.ODCA6 = 1; } while(0)
#define ESP_RESET_SetAnalogMode()      do { ANSELAbits.ANSA6 = 1; } while(0)
#define ESP_RESET_SetDigitalMode()     do { ANSELAbits.ANSA6 = 0; } while(0)

// get/set RB2 procedures
#define RB2_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define RB2_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define RB2_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define RB2_GetValue()              PORTBbits.RB2
#define RB2_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define RB2_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define RB2_SetPullup()             do { WPUBbits.WPUB2 = 1; } while(0)
#define RB2_ResetPullup()           do { WPUBbits.WPUB2 = 0; } while(0)
#define RB2_SetAnalogMode()         do { ANSELBbits.ANSB2 = 1; } while(0)
#define RB2_SetDigitalMode()        do { ANSELBbits.ANSB2 = 0; } while(0)

// get/set RC1 procedures
#define RC1_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define RC1_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define RC1_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define RC1_GetValue()              PORTCbits.RC1
#define RC1_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define RC1_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define RC1_SetPullup()             do { WPUCbits.WPUC1 = 1; } while(0)
#define RC1_ResetPullup()           do { WPUCbits.WPUC1 = 0; } while(0)
#define RC1_SetAnalogMode()         do { ANSELCbits.ANSC1 = 1; } while(0)
#define RC1_SetDigitalMode()        do { ANSELCbits.ANSC1 = 0; } while(0)

// get/set SQW aliases
#define SQW_TRIS                 TRISCbits.TRISC5
#define SQW_LAT                  LATCbits.LATC5
#define SQW_PORT                 PORTCbits.RC5
#define SQW_WPU                  WPUCbits.WPUC5
#define SQW_OD                   ODCONCbits.ODCC5
#define SQW_ANS                  ANSELCbits.ANSC5
#define SQW_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define SQW_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define SQW_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define SQW_GetValue()           PORTCbits.RC5
#define SQW_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define SQW_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define SQW_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define SQW_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define SQW_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define SQW_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define SQW_SetAnalogMode()      do { ANSELCbits.ANSC5 = 1; } while(0)
#define SQW_SetDigitalMode()     do { ANSELCbits.ANSC5 = 0; } while(0)

// get/set TEPT4400 aliases
#define TEPT4400_TRIS                 TRISCbits.TRISC7
#define TEPT4400_LAT                  LATCbits.LATC7
#define TEPT4400_PORT                 PORTCbits.RC7
#define TEPT4400_WPU                  WPUCbits.WPUC7
#define TEPT4400_OD                   ODCONCbits.ODCC7
#define TEPT4400_ANS                  ANSELCbits.ANSC7
#define TEPT4400_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define TEPT4400_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define TEPT4400_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define TEPT4400_GetValue()           PORTCbits.RC7
#define TEPT4400_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define TEPT4400_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define TEPT4400_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define TEPT4400_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define TEPT4400_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define TEPT4400_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define TEPT4400_SetAnalogMode()      do { ANSELCbits.ANSC7 = 1; } while(0)
#define TEPT4400_SetDigitalMode()     do { ANSELCbits.ANSC7 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/