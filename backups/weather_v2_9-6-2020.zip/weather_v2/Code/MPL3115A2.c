/************************************
*           MPL3115A2.c             *
************************************/
/*
Name: MPL3115A2.c
Synopsis: Functions to control the MPL3115A2, Precision Altimeter.
Requires:  The MPL3115A2 is on the Sparkfun weather sheild.
Description:

need to look at toggel one shot, when was last sensor reading made?  If we pole every 5 min, is the data that old?

The MPL3115A2 employs a MEMS pressure sensor with an I2C interface
to provide accurate Pressure/Altitude and Temperature data. The
sensor outputs are digitized by a high resolution 24-bit ADC.

The device is a low-power, high accuracy, digital output altimeter, barometer and
thermometer, packaged in a 3 x 5 x 1.1 mm form factor. The complete device includes a
2
sensing element, analog and digital signal processing and an I C interface.


The device has two operational modes, barometer and altimeter. Both modes include a
thermometer temperature output function.

Power consumption and sensitivity are programmable where the data oversampling
ratio can be set to balance current consumption and noise/resolution.



Measures pressure: 20-bit measurement, 20 to 110 kPa.  Converted to inHg in
software.

When in barometer mode, all pressure related data is reported as
20-bit unsigned data in Pascals.

The unit contains a high-resolution temperature sensor that provides
data to the user via a 16-bit data register, as well as for internal
compensation of the pressure sensor.

Noticed while testing that the sensor seems sensitoive to ambient light.
Datasheet Rev. 8 — 12 April 2018 says: The sensor die is sensitive to light
exposure. Direct light exposure through the port hole can lead to varied
accuracy of pressure measurement. Avoid such exposure to the port during normal
operation.

To avoid floating point processing when using sprintf, the whole and
fractional part of the data is saved.
MPL3115A2_Pfrac = (uint8_t) f_val;
MPL3115A2_Pwhole = (uint8_t) i_val;
This was done during development to save memory.  Later the target MCU
was changed to the PIC16F18857 and memory was not an issue.

Revision History:
Code copied and modified from sparkfun.com.  Only the pressure value is
read once as polled.  Temperature is not used.


*/

#include "mcc_generated_files/mcc.h"
#include "i2c.h"
#include "MPL3115A2.h"
#include <math.h>

#define MPL3115A2_ADDRESS 0xC0 // Unshifted 7-bit I2C address for sensor
#define MPL_STATUS     0x00
#define OUT_P_MSB  0x01
#define OUT_P_CSB  0x02
#define OUT_P_LSB  0x03
#define OUT_T_MSB  0x04
#define OUT_T_LSB  0x05
#define DR_STATUS  0x06
#define OUT_P_DELTA_MSB  0x07
#define OUT_P_DELTA_CSB  0x08
#define OUT_P_DELTA_LSB  0x09
#define OUT_T_DELTA_MSB  0x0A
#define OUT_T_DELTA_LSB  0x0B
#define WHO_AM_I   0x0C
#define F_STATUS   0x0D
#define F_DATA     0x0E
#define F_SETUP    0x0F
#define TIME_DLY   0x10
#define SYSMOD     0x11
#define INT_SOURCE 0x12
#define PT_DATA_CFG 0x13
#define BAR_IN_MSB 0x14
#define BAR_IN_LSB 0x15
#define P_TGT_MSB  0x16
#define P_TGT_LSB  0x17
#define T_TGT      0x18
#define P_WND_MSB  0x19
#define P_WND_LSB  0x1A
#define T_WND      0x1B
#define P_MIN_MSB  0x1C
#define P_MIN_CSB  0x1D
#define P_MIN_LSB  0x1E
#define T_MIN_MSB  0x1F
#define T_MIN_LSB  0x20
#define P_MAX_MSB  0x21
#define P_MAX_CSB  0x22
#define P_MAX_LSB  0x23
#define T_MAX_MSB  0x24
#define T_MAX_LSB  0x25
#define CTRL_REG1  0x26
#define CTRL_REG2  0x27
#define CTRL_REG3  0x28
#define CTRL_REG4  0x29
#define CTRL_REG5  0x2A
#define OFF_P      0x2B
#define OFF_T      0x2C
#define OFF_H      0x2D

extern bit i2c_ack;  // used for debugging
extern int8_t wifi_connect_status;  // used to signal WiFi connect status

/************************************
*       read MPL3115A2              *
************************************/
/*
Name: data read MPL3115A2
Description:
Read data from I2C bus.
*ptr: pointer to data
len: number of bytes to read
Revision History:
*/
void read_MPL3115A2(uint8_t cmd, uint8_t *ptr, uint8_t len)
{
uint8_t i,j,input_data;

		// write device address, then word address followed by repeated start
		i2c_start();	// send start condition
		i2c_write(MPL3115A2_ADDRESS);	// device address
		i2c_write(cmd);	// command
		i2c_start();	// send start condition

		i2c_write(MPL3115A2_ADDRESS | 0x01);	// device address, read

    // read 1 byte of data followed by ACK
    SDA_SetDigitalInput();        	// set SDA pin as input
    delay_10us();
    for(i = 0;i < len-1;i++){
        input_data = 0x00;
        for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
            input_data <<= 1;   // Shift the byte by one bit
            SCL_SetHigh();      // Clock the data into the I2C Bus
            delay_10us();
            input_data |= SDA_GetValue();  // Input the data from the I2C Bus
            delay_10us();
            SCL_SetLow();
            delay_10us();
        }
        // send ACK
        SDA_SetLow();    	// send ACK valid
        SDA_SetDigitalOutput();   // Put port pin to output
        delay_10us();
        SCL_SetHigh();		// Clock the ACK from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
        SDA_SetDigitalInput(); //return SDA to Hi Z
        *ptr++ = input_data;        //save received data
    }

    // now read last byte of data followed by NACK
    input_data = 0x00;
    for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
        input_data <<= 1;   // Shift the byte by one bit
        SCL_SetHigh();         // Clock the data into the I2C Bus
        delay_10us();
        input_data |= SDA_GetValue();  // Input the data from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
    }
    // send NACK
    SDA_SetHigh();    	// send NACK valid
    SDA_SetDigitalOutput();   // Put port pin to output
    delay_10us();
    SCL_SetHigh();		// Clock the ACK from the I2C Bus
    delay_10us();
    SCL_SetLow();
    delay_10us();
    SDA_SetDigitalInput(); //return SDA to Hi Z

    *ptr = input_data;        //save last received data

		i2c_stop();	// create a stop condition
}

/************************************
*       MPL3115A2_readPressure      *
************************************/
/*
Name: MPL3115A2_readPressure
Description:
Reads the current pressure and converts to inHg.
Stores whole and fractional part of reading.
Unit must be set in barometric pressure mode
Returns 0 if time out error.

need to review sample rate and freshness of data

Revision History:
*/
uint16_t MPL3115A2_readPressure(void)
{
uint8_t status_setting, sensor_data[3];
uint16_t counter;
uint32_t pressure_whole;
double pressure, pressure_decimal;
double i_val, f_val;  // whole and fractional part

		read_MPL3115A2(MPL_STATUS, &status_setting, 1);
		if((status_setting & 0x04) == 0)
				MPL3115A2_toggleOneShot(); //Toggle the OST bit to take another reading

		//Wait for PDR bit, indicates we have new pressure data
		counter = 0;
		while((status_setting & 0x04) == 0){
				if(++counter > 60)
						return(0); // waits 60 ms before time out error
				delay_1ms();
				read_MPL3115A2(MPL_STATUS, &status_setting, 1);
		}

		// Read pressure registers
		read_MPL3115A2(OUT_P_MSB, sensor_data, 3);
		MPL3115A2_toggleOneShot(); //Toggle the OST bit to take another reading

		// Pressure comes back as a left shifted 20 bit number
		pressure_whole = sensor_data[0];
		pressure_whole <<= 8;
		pressure_whole |= sensor_data[1];
		pressure_whole <<= 8;
		pressure_whole |= sensor_data[2];
		pressure_whole >>= 6; // get rid of decimal portion

		// save raw data
		raw_data[4] = sensor_data[0];
		raw_data[5] = sensor_data[1];
		raw_data[6] = sensor_data[2];

		sensor_data[2] &= 0b00110000; //Bits 5/4 represent the fractional component
		sensor_data[2] >>= 4; //Get it right aligned
		pressure_decimal = (double) sensor_data[2]/4.0; //Turn it into fraction

		pressure = (((double) pressure_whole + pressure_decimal)/100.0)/33.864; // convert to inHg

		f_val = modf(pressure , &i_val)*100.0;
		MPL3115A2_Pfrac = (uint8_t) f_val;
		MPL3115A2_Pwhole = (uint8_t) i_val;

		return(MPL3115A2_Pwhole);
}

/************************************
*       init_MPL3115A2              *
************************************/
/*
Name: init_MPL3115A2
Description:
Calls several function to initialize the sensor.

Need to review all this code and use the polling mode to read the data. We want a
freash value every time we read the sensor, not old data.


need to add a better description of the mode
Also need to review
Data Manipulation and Basic Settings of
the MPL3115A2 Command Line Interface (document AN4519).

There are three modes: Standby Mode, Active Altimeter Mode and Active Barometer Mode.

To set up the device in altimeter mode, you may select your data retrieval method
between polling (no FIFO), interrupt (no FIFO) or with the FIFO. The flow charts in
Figure 7 and Figure 8 describe the setup for polling or interrupt with an OSR of 128.
For more information, see application note titled Data Manipulation and Basic Settings of
the MPL3115A2 Command Line Interface (document AN4519).


In order to enter Active Barometer mode, the MPL3115A2 must be put into Standby mode prior to any
changes. You must then write a 0 to the ALT bit of CTRL_REG_1 and a 1 to SBYB bit to go into Active
mode.

6
Polling Data Versus Interrupts
The data can be polled continuously or a hardware interrupt can be configured to signal when the data
ready flag is set. The MCU can then use an interrupt service routine to retrieve the data. Depending on the
circumstances, one might be more desirable than the other although polling typically is less efficient.
6.1
Polling data
Polling requires less configuration of the device and is very simple to implement. However, the MCU must
poll the sensor at a rate that is faster than the output data rate. Otherwise, if the polling is too slow, data
samples will be missed. The MCU can detect the missed or corrupted data condition by checking the
overwrite flags in the STATUS register (i.e., PTOW, POW, TOW, PTDR, PDR, and TDR). The code
examples provided so far in this document have primarily described the polling technique. As a summary,
here is a more complete example of the basic code, specific to the operation of the MPL3115A2, required
to continuously poll 20-bit PT data using the Altimeter Active mode:




Revision History:
*/
void init_MPL3115A2(void)
{
		// these functions are only called once, could consolidate into one function.
		MPL3115A2_setModeStandby();// Puts the sensor into Standby mode. Required when changing CTRL1 register.
		MPL3115A2_setModeBarometer();// Measure pressure in Pascals from 20 to 110 kPa
		MPL3115A2_setOversampleRate(7); // Set Oversample to the recommended 7=128 oversampling ratio
		MPL3115A2_enableEventFlags();// Enable all three pressure and temp event flags
		MPL3115A2_setModeActive();  // Start taking measurements
}

/************************************
*     MPL3115A2_setModeBarometer    *
************************************/
/*
Name:
Synopsis:
Requires:
Description:


** Read contents of CTRL_REG_1
** Clear SBYB mask while holding all other values of CTRL_REG_1.
** To put part into Standby mode

CTRL_REG_1_DATA = IIC_RegRead(SlaveAddressIIC, CTRL_REG1);
IIC_RegWrite(SlaveAddressIIC, CTRL_REG1, CTRL_REG_1_DATA & STANDBY_SBYB_MASK);

** Write a 0 to the ALT and a 1 SBYB bits to go into Active Barometer mode

IIC_RegWrite(SlaveAddressIIC, CTRL_REG1, (CTRL_REG_1_DATA | BAR_MASK | ACTIVE_MASK));

In Barometer mode, the 20-bit value stored in OUT_P_MSB, OUT_P_CSB
and OUT_P_LSB is in Pascals represented as an unsigned 18-bit value in
OUT_P_MSB, OUT_P_CSB and bits 7-6 of OUT_P_LSB with the
fractional value in bits 5-4 of OUT_P_LSB. Bits 3-0 of OUT_P_LSB are
unused in this mode.


Sets the mode to Barometer
Revision History:
*/
void MPL3115A2_setModeBarometer(void)
{
uint8_t tempSetting;

		read_MPL3115A2(CTRL_REG1, &tempSetting, 1);
		tempSetting &= ~(1<<7); //Clear ALT bit

		i2c_start();	// send start condition
		i2c_write(MPL3115A2_ADDRESS);	// device address
		i2c_write(CTRL_REG1);	// register address
		i2c_write(tempSetting);	// value
		i2c_stop();
}

/************************************
*       MPL3115A2_setModeStandby    *
************************************/
/*
Name: MPL3115A2_setModeStandby
Synopsis: Puts the sensor in standby mode
Description:
This is needed so that we can modify the major control registers


** Read contents of CTRL_REG_1
** Clear SBYB mask while holding all other values of CTRL_REG_1.

CTRL_REG_1_DATA = IIC_RegRead(SlaveAddressIIC, CTRL_REG1);
IIC_RegWrite(SlaveAddressIIC, CTRL_REG1, CTRL_REG_1_DATA & STANDBY_SBYB_MASK);


Revision History:
*/
void MPL3115A2_setModeStandby(void)
{
uint8_t tempSetting;

		read_MPL3115A2(CTRL_REG1, &tempSetting, 1);
		tempSetting &= ~(1<<0); //Clear SBYB bit for Standby mode

		i2c_start();	// send start condition
		i2c_write(MPL3115A2_ADDRESS);	// device address
		i2c_write(CTRL_REG1);	// register address
		i2c_write(tempSetting);	// value
		i2c_stop();
}

/************************************
*        MPL3115A2_setModeActive    *
************************************/
/*
Name: MPL3115A2_setModeActive
Description: Puts the sensor in active mode
Revision History:
*/
void MPL3115A2_setModeActive(void)
{
uint8_t tempSetting;

		read_MPL3115A2(CTRL_REG1, &tempSetting, 1);
		tempSetting |= (1<<0); //Set SBYB bit for Active mode

		i2c_start();	// send start condition
		i2c_write(MPL3115A2_ADDRESS);	// device address
		i2c_write(CTRL_REG1);	// register address
		i2c_write(tempSetting);	// value
		i2c_stop();
}

/************************************
*      MPL3115A2_setOversampleRate  *
************************************/
/*
Name: MPL3115A2_setOversampleRate
Description: set to a value of 7 which gives an
oversample ratio of 127 and a minimum time between
data samples of 512ms.

More research is needed as to why this is set to 7.

Oversample ratio


Revision History:
*/
void MPL3115A2_setOversampleRate(uint8_t sampleRate)
{
uint8_t tempSetting;

		if(sampleRate > 7)
				sampleRate = 7; //OS cannot be larger than 0b.0111
		sampleRate <<= 3; //Align it for the CTRL_REG1 register

		read_MPL3115A2(CTRL_REG1, &tempSetting, 1);
		tempSetting &= 0b11000111; //Clear out old OS bits
		tempSetting |= sampleRate; //Mask in new OS bits

		i2c_start();	// send start condition
		i2c_write(MPL3115A2_ADDRESS);	// device address
		i2c_write(CTRL_REG1);	// register address
		i2c_write(tempSetting);	// value
		i2c_stop();
}

/************************************
*      MPL3115A2_enableEventFlags   *
************************************/
/*
Name: MPL3115A2_enableEventFlags
Description:
Enables the pressure and temp measurement event flags so that we can
test against them. This is recommended in datasheet during setup

PT_DATA_CFG - sensor data register (address13h)
The PT_DATA_CFG register configures the pressure data, temperature data and event
flag generator.

bits 7 to 3: reserved These bits are reserved

bit 2: DREM Data ready event mode.
0 — Event detection disabled (reset value) If the DREM bit is cleared logic '0' and one or
more of the data ready event flags are enabled, then an event flag will be raised whenever
the system acquires a new set of data.
1 — Generate data ready event flag on new pressure/altitude or temperature data. If the
DREM bit is set logic '1' and one or more of the data ready event flags (PDEFE, TDEFE) are
enabled, then an event flag will be raised upon change in state of the data.

bit 1: PDEFE Data event flag enable on new pressure/altitude
0 — Event detection disabled (reset value)
1 — Raise event flag on new pressure/altitude data

bit 0: TDEFE Data event flag enable on new temperature data.
0 — Event detection disabled (reset value)
1 — Raise event flag on new temperature data

Revision History:
*/
void MPL3115A2_enableEventFlags(void)
{
		i2c_start();	// send start condition
		i2c_write(MPL3115A2_ADDRESS);	// device address
		i2c_write(PT_DATA_CFG);	// register address
		i2c_write(0x07);	// Enable all three pressure and temp event flags
		i2c_stop();
}

/************************************
*     MPL3115A2_toggleOneShot       *
************************************/
/*
Name: MPL3115A2_toggleOneShot
Description:
Clears then sets the OST bit which causes the sensor to immediately take another reading
Needed to sample faster than 1Hz

CTRL_REG1

CTRL_REG1 - control register 1 (address 26h)
Note: Except for STANDBY and OST mode selection, the device must be in STANDBY
mode to change any of the fields within bits 7 to 0 of CTRL_REG1 (26h).

bit 7: ALT, Altimeter/barometer mode.
0 — Part is in barometer mode (reset value)
1 — Part is in altimeter mode

bit 6: Reserved

bits 5 to 3: OS[2:0] Oversample ratio. These bits select the oversampling ratio.
The value is 2^(OS). The default value is 000 for a ratio of 1.

bit 2: 0 (R) RST (W), Software reset. This bit is used to activate the software reset. The boot mechanism can be
enabled in STANDBY and ACTIVE mode.
When the boot bit is enabled the boot mechanism resets all functional block registers and
loads the respective internal registers with default values.
If the system was already in STANDBY mode, the reboot process will immediately begin, or
else if the system was in ACTIVE mode, the boot mechanism will automatically transition the
system from ACTIVE mode to STANDBY mode. Only then can the reboot process begin.
2
The I C communication system is reset to avoid accidental corrupted data access.
At the end of the boot process the RST bit is de-asserted to 0. Reading this bit will return a
value of zero.
0 — Device reset disabled (reset value)
1 — Device reset enabled

bit 1: OST, OST bit will initiate a measurement immediately. If the SBYB bit is set to active, setting the
OST bit will initiate an immediate measurement, the part will then return to acquiring data as
per the setting of the ST bits in CTRL_REG2. In this mode, the OST bit does not clear itself
and must be cleared and set again to initiate another immediate measurement.

In one-shot mode, when SBYB is 0, the OST bit is an auto-clear bit. When OST is set, the
device initiates a measurement by going into active mode. Once a pressure/altitude and
temperature measurement is completed, it clears the OST bit and comes back to STANDBY
mode. User shall read the value of the OST bit before writing to this bit again.

bit 0: SBYB, This bit is sets the mode to ACTIVE, where the system will make measurements at periodic
times based on the value of ST bits.
0 — Part is in STANDBY mode (reset value)
1 — Part is ACTIVE


CTRL_REG2 - control register 2 (address 27h)

bits 7 to 6: reserved These bits are reserved.

bit 5: LOAD_OUTPUT This is to load the target values for SRC_PW/SRC_TW and SRC_PTH/SRC_TTH.
0 — Do not load OUT_P/OUT_T as target values (reset value)
1 — The next values of OUT_P/OUT_T are used to set the target values for the interrupts.
Notes:
• This bit must be set at least once if ALARM_SEL=1
• To reload the next OUT_P/OUT_T as the target values, clear and set again.

bit 4: ALARM_SEL, The bit selects the target value for SRC_PW/SRC_TW and SRC_PTH/SRC_TTH.
0 — (reset value) The values in P_TGT_MSB, P_TGT_LSB and T_TGT are used.
1 — The values in OUT_P/OUT_T are used for calculating the interrupts SRC_PW/SRC_TW
and SRC_PTH/SRC_TTH.

bits 3 to 0: ST[3:0] Auto acquisition time step.
0 — (reset value)
Step value is 2^(ST) — Giving a range of 1 second to 215 seconds (9 hours)

Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/
void MPL3115A2_toggleOneShot(void)
{
uint8_t tempSetting;

		read_MPL3115A2(CTRL_REG1, &tempSetting, 1);
		tempSetting &= ~(1<<1); //Clear OST bit

		i2c_start();	// send start condition
		i2c_write(MPL3115A2_ADDRESS);	// device address
		i2c_write(CTRL_REG1);	// register address
		i2c_write(tempSetting);	// value
		i2c_stop();

		read_MPL3115A2(CTRL_REG1, &tempSetting, 1);
		tempSetting |= (1<<1); //Set OST bit

		i2c_start();	// send start condition
		i2c_write(MPL3115A2_ADDRESS);	// device address
		i2c_write(CTRL_REG1);	// register address
		i2c_write(tempSetting);	// value
		i2c_stop();
}


/************************************
*            MPL3115A2_readTemp     *
************************************/
/*
Name: MPL3115A2_readTemp
Synopsis:
Requires:
Description: 12 bit 2's complement value in degrees C.
Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/
#if 1
//function not used
int8_t MPL3115A2_readTemp(void)
{
uint8_t status_setting, negSign, sensor_data[2];
uint16_t counter, foo;
//uint32_t pressure_whole;
float temperature, templsb;

  read_MPL3115A2(MPL_STATUS, &status_setting, 1);
  if((status_setting & 0x02) == 0)
      MPL3115A2_toggleOneShot(); //Toggle the OST bit causing the sensor to immediately take another reading

  //Wait for PDR bit, indicates we have new pressure data
  counter = 0;
  while((status_setting & 0x02) == 0)
  {
  	if(++counter > 60)
        return(-99); //Error out after max of 60ms for a read
  	delay_1ms();
    read_MPL3115A2(MPL_STATUS, &status_setting, 1);
  }

  // Read temperature registers
  read_MPL3115A2(OUT_T_MSB, sensor_data, 2);
  MPL3115A2_toggleOneShot(); //Toggle the OST bit causing the sensor to immediately take another reading

	// save raw data
	raw_data[7] = sensor_data[0];
	raw_data[8] = sensor_data[1];
	raw_data[9] = wifi_connect_status;  // include the last connect status

    //Negative temperature fix by D.D.G.
	 foo = 0;
   negSign = 0;

    //Check for 2s compliment
	if(sensor_data[0] > 0x7F)
	{
        foo = ~((sensor_data[0] << 8) + sensor_data[1]) + 1;  //2’s complement
        sensor_data[0] = foo >> 8;
        sensor_data[1] = foo & 0x00F0;
        negSign = 1;
	}

	// The least significant bytes l_altitude and l_temp are 4-bit,
	// fractional values, so you must cast the calulation in (float),
	// shift the value over 4 spots to the right and divide by 16 (since
	// there are 16 values in 4-bits).
	 templsb = (float)(sensor_data[1]>>4)/16.0; //temp, fraction of a degree

	 temperature = (float)(sensor_data[0] + templsb);

	if (negSign) temperature = 0 - temperature;

    temperature = (temperature * 9.0)/ 5.0 + 32.0;  // Convert celsius to fahrenheit

	return((int8_t) temperature); // return int value
}
#endif


//end of file
