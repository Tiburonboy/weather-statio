/************************************
*         LCD0821.c                 *
************************************/
/*
Name: LCD0821.c
Synopsis: Controls the Orbital LCD0821, 2x8 I2C LCD display
Requires: I2C connection to the LCD0821.  Pullup resistors
are on the weather shield.
Author: Tony Cirineo
Revision History:
*/

#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include "LCD0821.h"
#include "i2c.h"

uint8_t lcd_cmd_str[10];  // longest command string needs 5 characters

/************************************
*         putch                 *
************************************/
/*
Name: putch
Synopsis: called by printf() which sends character to the LCD
Note: When configuring the EUSART with MCC generated code,
do not redirect STDIO to EUSART as this will generate a
conflict with putch().
Revision History:
*/
void putch(uint8_t char_out)
{
    // write device address, then data
    i2c_start();
    i2c_write(LCD_ADDRESS << 1);	// device address
    i2c_write(char_out);
    i2c_stop();	// create a stop condition
}

/************************************
*       set LCD cursor              *
************************************/
/*
Name: set LCD cursor
Synopsis: Set cursor position on LCD
Description:
This command sets the cursor position (text insertion point)
to the [column] and [row] specified. Columns have values from
1 to 8 and rows have values of 1 to 4.
Revision History:
*/
void set_LCD_cursor(uint8_t col, uint8_t row)
{
    lcd_cmd_str[0] = 254;
    lcd_cmd_str[1] = 71;
    lcd_cmd_str[2] = col;
    lcd_cmd_str[3] = row;
    lcd_cmd_str[4] = 0;
    write_LCD(lcd_cmd_str);
}

/************************************
*       clear LCD                   *
************************************/
/*
Name: clear LCD
Synopsis: Clear Orbital LCD0821 display
Description: This command clears the display and resets the text
insertion point to the top left of the screen.
Revision History:
*/
void clear_LCD(void)
{
    // clear LCD, 254 88
    lcd_cmd_str[0] = 254;
    lcd_cmd_str[1] = 88;
    lcd_cmd_str[2] = 0;
    write_LCD(lcd_cmd_str);
}

/************************************
*       LCD Backlight               *
************************************/
/*
Name: clear LCD
Synopsis: Turns on or off LCD backlight
Description:
Backlight on (254 66 [minutes])
This command turns on the backlight for a time of [minutes] minutes.
If [minutes] is zero (0), the backlight will remain on indefinitely.
Note: the factory default for backlight is on at power up.
This function will set the minutes to zero, keeping the backlight on.
Backlight off (254 70)
This command turns the backlight of the LCD0821 off.

cmd = 0: backlight off
cmd = 1: backlight on

Revision History:
*/
void LCD_backlight(uint8_t cmd)
{
uint8_t i;

    if(cmd){
        // Backlight on (254 66 [minutes])
        // need to send 0x00 for [minutes]
        lcd_cmd_str[0] = 254;
        lcd_cmd_str[1] = 66;
        lcd_cmd_str[2] = 0;   // need to send 0x00 for length of time
                              // this is not the end of a ascii string
        // write device address, then 3 bytes of data, including final 0x00
        i2c_start();
        i2c_write(LCD_ADDRESS << 1);	// device address
        for(i=0;i<3;i++)
            i2c_write(lcd_cmd_str[i]);
        i2c_stop();	// create a stop condition
    }
    else{
        // Backlight off (254 70)
        lcd_cmd_str[0] = 254;
        lcd_cmd_str[1] = 70;
        lcd_cmd_str[2] = 0;
        write_LCD(lcd_cmd_str);
    }
}

/************************************
*       write LCD                   *
************************************/
/*
Name: write LCD
Synopsis: writes data to the Orbital LCD0821 display at
current char location.
Description: *ptr: pointer to list of bytes
sends until 0x00 is reached.
Revision History:
5 May 2020: figured out correct i2c address and i2c timing.
*/
void write_LCD(uint8_t *ptr)
{
    // write device address, data until 0x00
    i2c_start();
    i2c_write(LCD_ADDRESS << 1);	// device address
    while(*ptr != 0)
        i2c_write(*ptr++);
    i2c_stop();	// create a stop condition
}

// end
