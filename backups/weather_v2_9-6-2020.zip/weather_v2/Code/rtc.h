/************************************
*       RTC.h                       *
************************************/
/*
Name: rtc.h
Synopsis: header file for rtc
Author: Tony Cirineo
Revision History:
*/

void write_ds1307(uint8_t wdr_addrs, uint8_t *ptr, uint8_t len);
void read_ds1307(uint8_t wrd_addrs, uint8_t *ptr, uint8_t len);

uint8_t decToBcd(uint8_t val);
uint8_t bcdToDec(uint8_t val);
void set_time_date(void);
void get_time_date(void);

//extern uint8_t r_flg, s_flg;  // used to keep track of the phase of the SQW 1Hz signal
extern uint8_t second;
extern uint8_t minute;
extern uint8_t hour; 		// 24 hour time
extern uint8_t weekDay; 	// 1-7 = Sunday - Saturday
extern uint8_t monthDay;
extern uint8_t month;
extern uint8_t year;
extern uint8_t rtc_config;
extern uint8_t pData[10]; //actually 56 bytes in the DS1307 address space

//end
