/************************************
*              RTC.c                *
************************************/
/*
Name: RTC.c
Synopsis: functions to read and control the Real-Time Clock.
Requires: Sparkfun RTC module using the DS1307
Description:
The DS1307 Serial Real-Time Clock is a low-power, full binary-coded decimal (BCD) clock/calendar
plus 56 bytes of NV SRAM. Address and data are transferred serially via a 2-wire, bi-directional bus.
The clock/calendar provides seconds, minutes, hours, day, date, month, and year information. The end of
the month date is automatically adjusted for months with fewer than 31 days, including corrections for
leap year. The clock operates in either the 24-hour or 12-hour format with AM/PM indicator. The
DS1307 has a built-in power sense circuit that detects power failures and automatically switches to the
battery supply.

V BAT – Battery input for any standard 3V lithium cell or other energy source. Battery voltage must be
held between 2.0V and 3.5V for proper operation. The nominal write protect trip point voltage at which
access to the RTC and user RAM is denied is set by the internal circuitry as 1.25 x V BAT nominal. A
lithium battery with 48mAhr or greater will back up the DS1307 for more than 10 years in the absence of
power at 25oC. UL recognized to ensure against reverse charging current when used in conjunction with a
lithium battery.

SQW/OUT (Square Wave/Output Driver) – When enabled, the SQWE bit set to 1, the SQW/OUT pin
outputs one of four square wave frequencies (1Hz, 4kHz, 8kHz, 32kHz). The SQW/OUT pin is open
drain and requires an external pull-up resistor. SQW/OUT will operate with either Vcc or Vbat applied.

Revision History:

*/

#include "mcc_generated_files/mcc.h"
#include <string.h>
#include <stdio.h>
#include "i2c.h"
#include "rtc.h"
#include "esp8266.h"

#define DS1307_ADDRESS 0x68

extern uint8_t update_rtc_flg;

extern struct network_timedate network_timedate;

uint8_t second;
uint8_t minute;
uint8_t hour; 		// 24 hour time
uint8_t weekDay; 	// 1-7 = Sunday - Saturday
uint8_t monthDay;
uint8_t month;
uint8_t year;
uint8_t rtc_config;
uint8_t pData[10]; //actually 56 bytes in the DS1307 address space

/************************************
*       get time and date           *
************************************/
/*
Name: get time and date
Description:  reads time and date from the DS1307
Revision History:
*/
void get_time_date(void)
{
uint8_t dev_addrs;
uint8_t i;

    read_ds1307(0, pData, 8);

    second = bcdToDec(pData[0]);
    minute = bcdToDec(pData[1]);
    hour = bcdToDec(pData[2] & 0b111111); //24 hour time
    weekDay = bcdToDec(pData[3]); //1-7 -> Sunday - Saturday
    monthDay = bcdToDec(pData[4]);
    month = bcdToDec(pData[5]);
    year = bcdToDec(pData[6]);
    rtc_config = pData[7];
}

/************************************
*       set time and date           *
************************************/
/*
Name: set_time_date
Description: write new time and date to the rtc
Looks at update_rtc_flg to determine if new time comes from the
network or hard coded.

Revision History:

*/
void set_time_date(void)
{
uint8_t dev_addrs;
uint8_t i;

    // set RTC with new time
    if(update_rtc_flg){
        second = network_timedate.second; //0-59, this also sets the CH bit to zero = osc runs
        minute =  network_timedate.minute; //0-59
        hour =  network_timedate.hour; //0-23
        monthDay =  network_timedate.day; //1-31
        month =  network_timedate.month; //1-12
        year  =   network_timedate.year; //0-99
        rtc_config = 0x10; //turn on SQW 1Hz
    }
    else {
        // manually set values for clock
        second =      0; //0-59, this also sets the CH bit to zero = osc runs
        minute =      10; //0-59
        hour =        04; //0-23
        weekDay =     5; //1-7, Sunday = 1
        monthDay =    3; //1-31
        month =       9; //1-12
        year  =       20; //0-99
        rtc_config = 0x10; //turn on SQW 1Hz
    }

    // put formated data into array for sending
    pData[0] = decToBcd(second);
    pData[1] = decToBcd(minute);
    pData[2] = decToBcd(hour);
    pData[3] = decToBcd(weekDay);
    pData[4] = decToBcd(monthDay);
    pData[5] = decToBcd(month);
    pData[6] = decToBcd(year);
    pData[7] = rtc_config;

    write_ds1307(0, pData, 8);
}

/************************************
*      Dec & BCD Conversions        *
************************************/
/*
Synopsis: functions to convert to and from BCD
Author: Tony Cirineo
Date:  8/5/03
Revision History:
*/
uint8_t decToBcd(uint8_t val){
// Convert normal decimal numbers to binary coded decimal
  return ( (val/10*16) + (val%10) );
}

uint8_t bcdToDec(uint8_t val)  {
// Convert binary coded decimal to normal decimal numbers
  return ( (val/16*10) + (val%16) );
}

/************************************
*       write ds1307                *
************************************/
/*
Name: write ds1307
Synopsis: writes data to the DS1307 real time clock
Requires:
wrd_addrs:  word address or register pointer
*ptr: pointer to list of data
len: length of data list to send
pointer to data and number of bytes to write
Description:
Author: Tony Cirineo
Date:
Revision History:
*/
void write_ds1307(uint8_t wrd_addrs, uint8_t *ptr, uint8_t len)
{
uint8_t dev_addrs;
uint8_t i;

    // build device address
    dev_addrs = DS1307_ADDRESS << 1;    // leave R/W bit as a zero

    // write device address, word address, then len bytes of data
    i2c_start();
    i2c_write(dev_addrs);	// device address
    i2c_write(wrd_addrs);	// word address
    for(i = 0;i < len;i++)
        i2c_write(*ptr++);
    i2c_stop();	// create a stop condition
}

/************************************
*       read ds1307                 *
************************************/
/*
Name: data read ds1307
Synopsis:
Data Read (Write Pointer, Then Read)—Slave Receive and Transmit

Requires:
wrd_addrs:  word address or register pointer
*ptr: pointer to list of data
len: length of data list to send
pointer to data and number of bytes to write
Description:
Author: Tony Cirineo
Date:
Revision History:
*/
void read_ds1307(uint8_t wdr_addrs, uint8_t *ptr, uint8_t len)
{
uint8_t dev_addrs;
uint8_t i,j,input_data;

	// write device address, then word address followed by repeated start
	dev_addrs = DS1307_ADDRESS << 1;    //leave w/r set to 0
	i2c_start();
	i2c_write(dev_addrs);	// device address
	i2c_write(wdr_addrs);	// word address
	i2c_start();	// send start condition

    // read the data from the device
	dev_addrs |= 0x01;      //set the w/r bit to 1 for read
	i2c_write(dev_addrs);	// device address

    // read len-1 bytes of data followed by ACK
    SDA_SetDigitalInput();        	// set SDA pin as input
    delay_10us();
    for(i = 0;i < len-1;i++){
        input_data = 0x00;
        for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
            input_data <<= 1;   // Shift the byte by one bit
            SCL_SetHigh();         // Clock the data into the I2C Bus
            delay_10us();
            input_data |= SDA_GetValue();  // Input the data from the I2C Bus
            delay_10us();
            SCL_SetLow();
            delay_10us();
        }
        // send ACK
        SDA_SetLow();    	// send ACK valid
        SDA_SetDigitalOutput();   // Put port pin to output
        delay_10us();
        SCL_SetHigh();		// Clock the ACK from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
        SDA_SetDigitalInput(); //return SDA to Hi Z
        *ptr++ = input_data;        //save received data
    }

    // now read last byte of data followed by NACK
    input_data = 0x00;
    for(j = 0; j < 8; j++){	// read 8 bits from the I2C Bus
        input_data <<= 1;   // Shift the byte by one bit
        SCL_SetHigh();         // Clock the data into the I2C Bus
        delay_10us();
        input_data |= SDA_GetValue();  // Input the data from the I2C Bus
        delay_10us();
        SCL_SetLow();
        delay_10us();
    }
    // send NACK
    SDA_SetHigh();    	// send NACK valid
    SDA_SetDigitalOutput();   // Put port pin to output
    delay_10us();
    SCL_SetHigh();		// Clock the ACK from the I2C Bus
    delay_10us();
    SCL_SetLow();
    delay_10us();
    SDA_SetDigitalInput(); //return SDA to Hi Z

    *ptr = input_data;        //save last received data

	i2c_stop();	// create a stop condition
}

// end of file
